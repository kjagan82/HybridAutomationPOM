package com.qa.testcases.Logistics;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewMovementOrderPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewInternalMovementOrderPageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewMovementOrderPageFlow newMovementOrderPageFlow;
	
	@DataProvider
	public Object[][] getMoveAgainDropDownData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("MovementOrderData.xlsx", "MoveAgainstDropDown",
				"internal_MoveAgainstDropDown" );
		return data;
	}
	
	@DataProvider
	public Object[][] getcreate_modify_MovementOrderData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("MovementOrderData.xlsx", "CreateModifyMovementOrder",
				"internal_create_modify_MovementOrder" );
		return data;
	}
	
	@DataProvider
	public Object[][] getmatched_callOff_DetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("MovementOrderData.xlsx", "MatchedCallOffDetails",
				"internal_matched_callOff_Details" );
		return data;
	}

	
	@DataProvider
	public Object[][] getmovement_schedule_DetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("MovementOrderData.xlsx", "MovementScheduleDetails",
				"internal_movement_schedule_Details" );
		return data;
	}

	
	@DataProvider
	public Object[][] getaddAdditionDeductionData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("MovementOrderData.xlsx", "AddAdditionDeduction",
				"internal_addAdditionDeduction" );
		return data;
	}

	
	@DataProvider
	public Object[][] getcostEstimateData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("MovementOrderData.xlsx", "CostEstimate",
				"internal_costEstimate" );
		return data;
	}


	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newMovementOrderPageFlow=new NewMovementOrderPageFlow();
	}
	
	@Test(priority=1)
	public void loginandClickNewInternalMovementOrder(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newInternalMovementOrder();
	}

	@Test(priority=2,description="Verifying the internal Movement Order destination page title")
	public void verifyPageTitleTest(){
		newMovementOrderPageFlow.internalMovementTitle();
	}
	
	/*@Test(priority=3,dataProvider="getMoveAgainDropDownData",description="Selecting Discrete Stock in internal movement order Details")
	public void internal_dropDown_movAgainstTest(String InternalDiscreteDropDown,String InternalConcreteDropDown) throws Exception{
		newMovementOrderPageFlow.int__MoveAgainstDiscrete_Stock_DropDown(InternalDiscreteDropDown,InternalDiscreteDropDown);	
		Assert.assertTrue(true, "internal Drp Down selected successfully");
	} */
	
	@Test(priority=3,dataProvider="getMoveAgainDropDownData",description="Selecting Consolidated Stock in internal movement order Details")
	public void internal_dropDown_movAgainstTest(String InternalDiscreteDropDown,String InternalConcreteDropDown) throws Exception{
		newMovementOrderPageFlow.int__MoveAgainstConcrete_Stock_DropDown(InternalDiscreteDropDown,InternalConcreteDropDown);	
		Assert.assertTrue(true, "internal Drp Down selected successfully");
	}

	@Test(priority=4,dataProvider="getcreate_modify_MovementOrderData",description="internalCreate_modify_MovementOrder Details")
	public void internalCreate_modify_MovementOrderTest(String NewWinSearchSelect,String NewWinSearchEnter) throws Exception{
		newMovementOrderPageFlow.create_modify_MovementOrder(NewWinSearchSelect,NewWinSearchEnter);		
		Assert.assertTrue(true, "internalCreate_modify_MovementOrder filled successfully");
	} 
	
	@Test(priority=5,dataProvider="getmatched_callOff_DetailsData",description="matched_callOff Details")
	public void internalMatched_callOff_DetailsTest(String issueDate,String transportModeSelect) throws Exception{
		newMovementOrderPageFlow.matched_callOff_Details(issueDate,transportModeSelect);		
		Assert.assertTrue(true, "internal_matched_callOff_Details filled successfully");
	} 
	
	@Test(priority=6,dataProvider="getmovement_schedule_DetailsData",description="movement_schedule Details")
	public void internalMovement_schedule_DetailsTest(String fromLocationSelect,String toLocationSelect,String scheduleNoDays,
			String scheduleLoadsDays,String frequency) throws Exception{
		newMovementOrderPageFlow.movement_schedule_Details(fromLocationSelect,toLocationSelect,scheduleNoDays,
				scheduleLoadsDays,frequency);	
		Assert.assertTrue(true, "internal_movement_schedule_Details filled successfully");
	} 
	
	@Test(priority=7,dataProvider="getaddAdditionDeductionData",description="addAdditionDeduction Details")
	public void internalAddAdditionDeductionTest(String contractStorageItem,String addDeleteNameSelect,String addDelete,
			String rateType,String rateEnter,String rateSelect,String weightBasis,String addRemarks) throws Exception{
		newMovementOrderPageFlow.addAdditionDeduction(contractStorageItem,addDeleteNameSelect,addDelete,
				rateType,rateEnter,rateSelect,weightBasis,addRemarks);	
		Assert.assertTrue(true, "internal_addAdditionDeduction filled successfully");
	} 
	
	@Test(priority=8,dataProvider="getcostEstimateData",description="costEstimate Details")
	public void internalCostEstimateTest(String schNoarrowSelect,String getCostCompName,String incomeExpense,String rateType,
			String costValueEnter,String costValueSelect,String FXbase,String costApplicableOn,
			String costEstimateRemarks) throws Exception{
		newMovementOrderPageFlow.costEstimate(schNoarrowSelect,getCostCompName,incomeExpense,rateType,costValueEnter,
				costValueSelect,FXbase,costApplicableOn,costEstimateRemarks);
		Assert.assertTrue(true, "internal_costEstimate filled successfully");
	}  
	
	
	@Test(priority=9,dataProvider="getcostEstimateData",description="costEstimate Details")
	public void internalMovementOrderTest() throws Exception{
		newMovementOrderPageFlow.internalMovementOrderNo();
		Assert.assertTrue(true, "internal Movement Order No Stored successfully");
	}
	
	@Test(priority=10,description="verify MOvement order Details")
	public void verifyInternalMovementOrder() throws Exception{
		homePageFlow.allMovementsNew();
		String movementOrderNo=SeleniumLibs.getStoredResultsfromFile("internalMovementOrderNo");
		newMovementOrderPageFlow.verifyMovementOrderListAllPage(movementOrderNo);
		Assert.assertTrue(true, "PurchaseMovementOrder verified successfully");
	} 




}
