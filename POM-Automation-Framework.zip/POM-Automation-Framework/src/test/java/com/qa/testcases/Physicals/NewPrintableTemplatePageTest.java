package com.qa.testcases.Physicals;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Physicals.NewPrintableTemplatePageFlow;

public class NewPrintableTemplatePageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	NewPrintableTemplatePageFlow newPrintableTemplatePageFlow;

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newPrintableTemplatePageFlow=new NewPrintableTemplatePageFlow();
	}
	/*
	@Test(priority=1,description="Creating the Purchase printable Template")
	public void createPurchaseTemplateTest() throws Exception{
		homePageFlow.newPurchasePrintableTemplate();
		String templateType="Purchase";
		String getCustomFieldSelect="ACCEPTANCE";
		String saveToVariable="purchasePrintableRefNo";
		newPrintableTemplatePageFlow.createTemplate(saveToVariable,templateType,getCustomFieldSelect);
		Assert.assertTrue(true, "Succesfully created "+templateType+ "Printable Template!!!");
	}
	
	@Test(priority=2,description="Verifying the Created Purchase printable Template",dependsOnMethods="createPurchaseTemplateTest")
	public void verifyPurchasePrintableTemplateTest() throws Exception{
		homePageFlow.listAllPrintableTemplate();
		String templateType="Purchase";
		newPrintableTemplatePageFlow.verifyPrintableTemplate(templateType);
		Assert.assertTrue(true, "Succesfully verified presence of purchase Printable Template!!!");
	}*/
	
	@Test(priority=3,description="Creating the Sale printable Template")
	public void createSaleTemplateTest() throws Exception{
		homePageFlow.newsalePrintableTemplate();
		String templateType="Sales";
		String getCustomFieldSelect="ACCEPTANCE";
		String saveToVariable="salePrintableRefNo";
		newPrintableTemplatePageFlow.createTemplate(saveToVariable,templateType,getCustomFieldSelect);
		Assert.assertTrue(true, "Succesfully created "+templateType+ "Printable Template!!!");
	}
	
	@Test(priority=4,description="Verifying the Created Sale printable Template",dependsOnMethods="createSaleTemplateTest")
	public void verifySalePrintableTemplateTest() throws Exception{
		homePageFlow.listAllPrintableTemplate();
		String templateType="Sales";
		newPrintableTemplatePageFlow.verifyPrintableTemplate(templateType);
		Assert.assertTrue(true, "Succesfully verified presence of Sale Printable Template!!!");
	}
	


}
