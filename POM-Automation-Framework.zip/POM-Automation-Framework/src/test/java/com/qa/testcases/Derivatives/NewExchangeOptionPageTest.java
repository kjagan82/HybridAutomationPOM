package com.qa.testcases.Derivatives;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Derivatives.NewExchangeOptionPageFlow;
import com.qa.flows.Home.HomePageFlow;
import com.qa.util.TestDataUtil;

/**
 * @author jaganmohan.k
 *
 */
public class NewExchangeOptionPageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewExchangeOptionPageFlow newExchangeOptionPageFlow;

	@DataProvider
	public Object[][] getBuyExchangeOptionData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("TradesData.xlsx", "NewExchangeOption",
				"fillNewBuyExchangeOptionDetails" );
		return data;
	}


	@DataProvider
	public Object[][] getSellExchangeOptionData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("TradesData.xlsx", "NewExchangeOption",
				"fillNewSellExchangeOptionDetails" );
		return data;
	}

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newExchangeOptionPageFlow=new NewExchangeOptionPageFlow();
	}


	@Test(priority=1,dataProvider="getBuyExchangeOptionData")
	public void fillNewBuyExchangeOptionDetails(String tradeRefNo,String externalTradeRefNo,String trader,
			String exchangeInstrument,String promptDeliveryDetailsType,String getPromptDeliveryDetailsName,
			String tradeType,String lotSize,String quantity_Input,String settlementCurrency,String strikePrice,
			String strikePriceUnit,String premiumDiscount,String premiumDiscountPriceUnit,String clearerProfile,
			String clearerAccount,String broker,String brokerCommType,String profitCenter,String strategy,
			String purpose,String selectnominee) throws Exception{

		homePageFlow.clickOnNewExchangeOption();
		newExchangeOptionPageFlow.loginPageTitle();

		newExchangeOptionPageFlow.fillNewExchangeOptionDetails(tradeRefNo,externalTradeRefNo,trader,
				exchangeInstrument,promptDeliveryDetailsType,getPromptDeliveryDetailsName,
				tradeType,lotSize,quantity_Input,settlementCurrency,strikePrice,
				strikePriceUnit,premiumDiscount,premiumDiscountPriceUnit,clearerProfile,
				clearerAccount,broker,brokerCommType,profitCenter,strategy,
				purpose,selectnominee);
		Assert.assertTrue(true, "FX "+tradeType+"Trade Form filled successfully");
	} 

	@Test(priority=2,dataProvider="getSellExchangeOptionData")
	public void fillNewSellExhangeOptionDetails(String tradeRefNo,String externalTradeRefNo,String trader,
			String exchangeInstrument,String promptDeliveryDetailsType,String getPromptDeliveryDetailsName,
			String tradeType,String lotSize,String quantity_Input,String settlementCurrency,String strikePrice,
			String strikePriceUnit,String premiumDiscount,String premiumDiscountPriceUnit,String clearerProfile,
			String clearerAccount,String broker,String brokerCommType,String profitCenter,String strategy,
			String purpose,String selectnominee) throws Exception{

		homePageFlow.clickOnNewExchangeOption();
		newExchangeOptionPageFlow.loginPageTitle();

		newExchangeOptionPageFlow.fillNewExchangeOptionDetails(tradeRefNo,externalTradeRefNo,trader,
				exchangeInstrument,promptDeliveryDetailsType,getPromptDeliveryDetailsName,
				tradeType,lotSize,quantity_Input,settlementCurrency,strikePrice,
				strikePriceUnit,premiumDiscount,premiumDiscountPriceUnit,clearerProfile,
				clearerAccount,broker,brokerCommType,profitCenter,strategy,
				purpose,selectnominee);

		Assert.assertTrue(true, "FX "+tradeType+"Trade Form filled successfully");
	} 


}
