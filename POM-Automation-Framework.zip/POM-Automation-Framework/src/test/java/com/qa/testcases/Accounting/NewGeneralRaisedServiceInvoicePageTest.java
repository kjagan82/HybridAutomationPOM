package com.qa.testcases.Accounting;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewInvoicePageFlow;
import com.qa.util.TestDataUtil;

public class NewGeneralRaisedServiceInvoicePageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewInvoicePageFlow newInvoicePageFlow;
	
	
	@DataProvider
	public Object[][] getgeneral_Service_Inv_Raised_Data() throws Exception{
		Object data[][] = TestDataUtil.getTestData("InvoiceData.xlsx", "GeneralServiceInvoice",
				"general_Service_Inv_Raised_Details" );
		return data;
	}
	
	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newInvoicePageFlow=new NewInvoicePageFlow();
	}
	
	
	@Test(priority=1)
	public void loginandClickNewGeneralServiceInvoiceRaised(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newGeneralServiceInvoiceRaised();
	}

	@Test(priority=2,dataProvider="getgeneral_Service_Inv_Raised_Data",description=" General Service invoice Raised Details")
	public void create_Income_ExpenseTest(String CPInvoiceRefENter,String CpReceivedInvSelect,String invoiceCurrencySelect,String taxSchedAppCountryReceivedInv,
			String taxSchedReceivedInv,String productGeneralInvSelect,String originGeneralInvSelect,String cropYearGeneralInvSelect,
			String qualityGeneralInvSelect,String costReceivedInvSelect,String monthReceivedInvSelect,String yearReceivedInvEnter,
			String actualCostGeneralReceivedInvEnter,String profitCenterGeneralReceivedInvEnter,String bankNamePrePaymentSelect,
			String accountNamePrePaymentSelect) throws Exception{
		
			newInvoicePageFlow.general_Service_Inv_Raised(CPInvoiceRefENter,CpReceivedInvSelect,invoiceCurrencySelect,taxSchedAppCountryReceivedInv,
					taxSchedReceivedInv,productGeneralInvSelect,originGeneralInvSelect,cropYearGeneralInvSelect,qualityGeneralInvSelect,
					costReceivedInvSelect,monthReceivedInvSelect,yearReceivedInvEnter,actualCostGeneralReceivedInvEnter,profitCenterGeneralReceivedInvEnter,
					bankNamePrePaymentSelect,accountNamePrePaymentSelect);
			Assert.assertTrue(true, " successfully filled  and stored  General Raised invoice ref no");
		
	} 
	

	
	
	
}
