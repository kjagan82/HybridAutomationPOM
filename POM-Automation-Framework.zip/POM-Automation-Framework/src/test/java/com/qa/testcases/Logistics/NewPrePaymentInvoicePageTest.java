package com.qa.testcases.Logistics;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewInvoicePageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewPrePaymentInvoicePageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewInvoicePageFlow newInvoicePageFlow;
	
	@DataProvider
	public Object[][] getselect_PrePayment_Invoice_DetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("InvoiceData.xlsx", "SelectInvoice",
				"select_PrePayment_Invoice_Details" );
		return data;
	}
	
	@DataProvider
	public Object[][] getprePayment_Invoice_DetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("InvoiceData.xlsx", "PreInvoiceDetails",
				"prePayment_Invoice_Details" );
		return data;
	}
	
	@DataProvider
	public Object[][] getprePayment_PayMent_Instruction_DetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("InvoiceData.xlsx", "PreInstructionDetails",
				"prePayment_PayMent_Instruction_Details" );
		return data;
	}
	
	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newInvoicePageFlow=new NewInvoicePageFlow();
	}
	
	@Test(priority=1)
	public void loginandClickNewPrePaymentInvoice(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newPrePaymentInvoice();
	}

	
	@Test(priority=2,dataProvider="getselect_PrePayment_Invoice_DetailsData",description="select_PrePayment_Invoice Details")
	public void select_PrePayment_InvoiceTest(String filterSearchSelect) throws Exception{
		String purchaseContractRefNo = SeleniumLibs.getStoredResultsfromFile("purchaseContractRefNo");
		newInvoicePageFlow.select_PrePayment_Invoice(purchaseContractRefNo,filterSearchSelect);	
		Assert.assertTrue(true, "select_PrePayment_Invoice details filled successfully");
	} 
	
	@Test(priority=3,dataProvider="getprePayment_Invoice_DetailsData",description="prePayment_Invoice Details",dependsOnMethods="select_PrePayment_InvoiceTest")
	public void prePayment_InvoiceTest(String CPInvoiceRefENter,String dueDatePrePayment,
			String accountingDatePrePayment) throws Exception{
		newInvoicePageFlow.prePayment_Invoice(CPInvoiceRefENter,dueDatePrePayment,accountingDatePrePayment);		
		Assert.assertTrue(true, "prePayment_Invoice_Details filled successfully");
	} 
	

	@Test(priority=4,dataProvider="getprePayment_PayMent_Instruction_DetailsData",description="prePayment_PayMent_Instruction Details")
	public void prePayment_PayMent_InstructionTest(String bankNamePrePaymentSelect,String accountNamePrePaymentSelect) throws Exception{
		newInvoicePageFlow.prePayment_PayMent_Instruction(bankNamePrePaymentSelect,accountNamePrePaymentSelect);		
		Assert.assertTrue(true, "prePayment_PayMent_Instruction filled successfully");
	} 
	

	@Test(priority=5,description="getPrePaymentInvoiceNo storing Details")
	public void getPrePaymentInvoiceNoTest() throws Exception{
		newInvoicePageFlow.getPrePaymentInvoiceNo();		
		Assert.assertTrue(true, "getPrePaymentInvoiceNo stored successfully");
	} 
	
	


}
