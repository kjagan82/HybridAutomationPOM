package com.qa.testcases.Physicals;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Physicals.UnderfillAndOverfillPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class OverfillPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	UnderfillAndOverfillPageFlow underfillAndOverfillPageFlow;

	 @DataProvider
		public Object[][] getOverfillDetailsData() throws Exception{
			Object data[][] = TestDataUtil.getTestData("UnderfillOverfillData.xlsx","UnderfillOverfill",
					"Overfill_Details" );
			return data;
		}
	 
		
	 @BeforeSuite
		public void setUp() throws Exception {
			homePageFlow = new HomePageFlow();
			underfillAndOverfillPageFlow=new UnderfillAndOverfillPageFlow();
		}
		
	
	 @Test(priority=1,dataProvider="getOverfillDetailsData",description="overfillDetails")
		public void purchaseUnderfillOverfillTest(String overfillUnderfillReason,String overfillUnderfillShipment,
				String futuresmonth,String futurePrice,String basisPrice) throws Exception{
		 
		 homePageFlow.ContractItemListAll();//click on contractListItem
		 
		 String OverfillorUnderfillType="PurchaseOverfillrefno";
		 String contractRefNo=SeleniumLibs.getStoredResultsfromFile("purchaseContractRefNo");
		 underfillAndOverfillPageFlow.search_Contract(contractRefNo);
		 underfillAndOverfillPageFlow.linkOverfillUnderfill();
		 underfillAndOverfillPageFlow.underfillOverfill_Activity(overfillUnderfillReason,overfillUnderfillShipment,futuresmonth,
				 futurePrice,basisPrice,OverfillorUnderfillType,contractRefNo);
		 Assert.assertTrue(true, "Overfilldetails_DetailsTest filled successfully");
	 }
	 
	  
	 @Test(priority=2,dataProvider="getOverfillDetailsData",description="overfillDetails")
		public void saleUnderfillOverfillTest(String overfillUnderfillReason,String overfillUnderfillShipment,
				String futuresmonth,String futurePrice,String basisPrice) throws Exception{
		 
		 homePageFlow.ContractItemListAll();//click on contractListItem
		 
		 String OverfillorUnderfillType="saleOverfillrefno";
		 String contractRefNo=SeleniumLibs.getStoredResultsfromFile("saleContractRefNo");
		 underfillAndOverfillPageFlow.search_Contract(contractRefNo);
		 underfillAndOverfillPageFlow.linkOverfillUnderfill();
		 underfillAndOverfillPageFlow.underfillOverfill_Activity(overfillUnderfillReason,overfillUnderfillShipment,futuresmonth,
				 futurePrice,basisPrice,OverfillorUnderfillType,contractRefNo);
		 Assert.assertTrue(true, "Overfilldetails_DetailsTest filled successfully");
	 }
	 
	 @Test(priority=3,dataProvider="getOverfillDetailsData",description="overfillDetails")
		public void productionUnderfillOverfillTest(String overfillUnderfillReason,String overfillUnderfillShipment,
				String futuresmonth,String futurePrice,String basisPrice) throws Exception{
		 
		 homePageFlow.ContractItemListAll();//click on contractListItem
		 
		 String OverfillorUnderfillType="ProductionOverfillrefno";
		 String contractRefNo=SeleniumLibs.getStoredResultsfromFile("productionRefNO");
		 underfillAndOverfillPageFlow.search_Contract(contractRefNo);
		 underfillAndOverfillPageFlow.linkOverfillUnderfill();
		 underfillAndOverfillPageFlow.underfillOverfill_Activity(overfillUnderfillReason,overfillUnderfillShipment,futuresmonth,
				 futurePrice,basisPrice,OverfillorUnderfillType,contractRefNo);
		 Assert.assertTrue(true, "Overfilldetails_DetailsTest filled successfully");
	 }
	 
}
