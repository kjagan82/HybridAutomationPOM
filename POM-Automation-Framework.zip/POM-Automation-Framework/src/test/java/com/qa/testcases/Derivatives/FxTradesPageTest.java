package com.qa.testcases.Derivatives;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Derivatives.NewFxTradesFlow;
import com.qa.flows.Home.HomePageFlow;
import com.qa.util.TestDataUtil;

/**
 * @author jaganmohan.k
 *
 */
public class FxTradesPageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewFxTradesFlow newFxTradesFlow;

	@DataProvider
	public Object[][] getBuyFxTradeData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("TradesData.xlsx", "NewFxTrades",
				"NewBuyFxTradesDetailsTest" );
		return data;
	}
	
	@DataProvider
	public Object[][] getSellFxTradeData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("TradesData.xlsx", "NewFxTrades",
				"NewSellFxTradesDetailsTest" );
		return data;
	}

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newFxTradesFlow=new NewFxTradesFlow();
	}

	@Test(priority=1,dataProvider="getBuyFxTradeData")
	public void NewBuyFxTradesDetailsTest(String trader,String CurrencyInstrument,String CounterParty,
			String PaymentTerms,String TradeType,String Amount,String ExchangeRate,String BankName,
			String BankAccount,String BankCharges,String BankChargesType,String bankChargesCurrency,
			String ProfitCenter,String Strategy,String Purpose,String Nominee) throws Exception{

		homePageFlow.clickOnNewFxTrade();
		newFxTradesFlow.fillNewFxTradesDetails(trader, CurrencyInstrument,CounterParty,PaymentTerms,
				TradeType,Amount,ExchangeRate,BankName,BankAccount,BankCharges,BankChargesType,
				bankChargesCurrency,ProfitCenter,Strategy,Purpose,Nominee);
		Assert.assertTrue(true, "FX "+TradeType+"Trade Form filled successfully");
	} 
	
	@Test(priority=2,dataProvider="getSellFxTradeData")
	public void NewSellFxTradesDetailsTest(String trader,String CurrencyInstrument,String CounterParty,
			String PaymentTerms,String TradeType,String Amount,String ExchangeRate,String BankName,
			String BankAccount,String BankCharges,String BankChargesType,String bankChargesCurrency,
			String ProfitCenter,String Strategy,String Purpose,String Nominee) throws Exception{

		homePageFlow.clickOnNewFxTrade();
		newFxTradesFlow.fillNewFxTradesDetails(trader, CurrencyInstrument,CounterParty,PaymentTerms,
				TradeType,Amount,ExchangeRate,BankName,BankAccount,BankCharges,BankChargesType,
				bankChargesCurrency,ProfitCenter,Strategy,Purpose,Nominee);
		Assert.assertTrue(true, "FX "+TradeType+"Trade Form filled successfully");
	} 


}
