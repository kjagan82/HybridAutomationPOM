package com.qa.testcases.Home;

import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;

public class HomePageTest extends TestBaseListener {
	HomePageFlow homePageFlow;

	public HomePageTest() {
		super();
	}

	//test cases should be separated -- independent with each other
	//before each test case -- launch the browser and login
	//@test -- execute test case
	//after each test case -- close the browser
	
	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		
	}
	
	
	@Test(priority=1)
	public void verifyHomePageTitleTest(){
		homePageFlow.homePageTitle();
	}
	
	@Test(priority=2)
	public void verifyUserNameTest(){
		homePageFlow.verifyCorrectUserName("Eka Admin");
	}
	
	@Test(priority=3)
	public void NewFutureTest(){
		homePageFlow.clickOnNewFuture();
		
	}
	
	
	
	

}
