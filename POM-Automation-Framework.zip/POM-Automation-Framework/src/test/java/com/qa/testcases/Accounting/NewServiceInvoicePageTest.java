package com.qa.testcases.Accounting;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewInvoicePageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewServiceInvoicePageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewInvoicePageFlow newInvoicePageFlow;
	
	
	@DataProvider
	public Object[][] getselect_Service_Invoice_data() throws Exception{
		Object data[][] = TestDataUtil.getTestData("InvoiceData.xlsx", "SelectInvoice",
				"select_Service_Invoice_Details" );
		return data;
	}
	
	
	@DataProvider
	public Object[][] getcreate_Income_Expense_Data() throws Exception{
		Object data[][] = TestDataUtil.getTestData("InvoiceData.xlsx", "ServiceInvoice",
				"income_Expense_Details" );
		return data;
	}
	
	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newInvoicePageFlow=new NewInvoicePageFlow();
	}
	
	
	@Test(priority=1)
	public void loginandClickNewServiceInvoice(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newServiceInvoice();
	}

	
    @Test(priority=2,dataProvider="getselect_Service_Invoice_data",description="select_PrePayment_Invoice Details")
	public void select_PrePayment_InvoiceTest(String filterSearchSelect) throws Exception{
    	
		String purchaseContractRefNo = SeleniumLibs.getStoredResultsfromFile("GMRrefNo");
		
		newInvoicePageFlow.select_Service_Invoice(purchaseContractRefNo,filterSearchSelect);	
		Assert.assertTrue(true, "select_PrePayment_Invoice selected successfully");
	} 
	
	
	@Test(priority=3,dataProvider="getcreate_Income_Expense_Data",description="Service invoice received Details")
	public void create_Income_ExpenseTest(String CPInvoiceRefENter,String CpReceivedInvSelect,String CpRaisedInvSelect,
			String invoiceCurrencySelect,String taxSchedAppCountryReceivedInv,String taxSchedReceivedInv,String costReceivedInvSelect,
			String actualCostReceivedInvEnter,String bankNamePrePaymentSelect,String accountNamePrePaymentSelect) throws Exception{
		
			newInvoicePageFlow.create_Income_Expense(CPInvoiceRefENter,CpReceivedInvSelect,CpRaisedInvSelect,invoiceCurrencySelect,
					taxSchedAppCountryReceivedInv,taxSchedReceivedInv,costReceivedInvSelect,actualCostReceivedInvEnter,
					bankNamePrePaymentSelect,accountNamePrePaymentSelect);
			Assert.assertTrue(true, " successfully filled  and stored ref no");
		
	} 
	

	
	
	
}
