package com.qa.testcases.Logistics;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewVoyageCharterFlow;

public class NewVoyageCharterPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	NewVoyageCharterFlow newVoyageCharterFlow;

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newVoyageCharterFlow=new NewVoyageCharterFlow();
	}
	@Test(priority=1)
	public void loginandClickNewVoyageCharter(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newVoyageCharter();
	}
	@Test(priority=2,description="Verifying the destination page title")
	public void verifyPageTitleTest(){
		newVoyageCharterFlow.loginPageTitle();
	}

	@Test(priority=3,dataProvider="getVoyageCharterFormData")
	public void newVoyageCharterform(String ExternalTradeRefNo) throws Exception{
		newVoyageCharterFlow.newVoyageCharterform(ExternalTradeRefNo);
		Thread.sleep(2000);
		Assert.assertTrue(true, "VoyageCharter form filled successfully");
		Reporter.log("VoyageCharter form filled successfully", true);
	} 
}
