package com.qa.testcases.Physicals;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Physicals.NewContractPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewSaleContractPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	NewContractPageFlow newContractPageFlow;

	@DataProvider
	public Object[][] getSaleContract_ContractDetails() throws Exception{

		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", 
				"ContractDetails", "saleContract_ContractDetails");
		return data;
	}
	@DataProvider
	public Object[][] getSaleContract_ItemDetails() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "ItemDetails", 
				"saleContract_ItemDetails");
		return data;
	}

	@DataProvider
	public Object[][] getSaleContract_QuantityDetails() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "QuantityDetails",
				"saleContract_QuantityDetails");
		return data;
	}

	@DataProvider
	public Object[][] getSaleContract_BasisPrice() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "BasisPriceType",
				"saleContract_BasisPrice");
		return data;
	}

	@DataProvider
	public Object[][] getSaleContract_DeliveryDetails() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "DeliveryDetails",
				"saleContract_DeliveryDetails");
		return data;
	}

	@DataProvider
	public Object[][] getSaleContract_DeliveryPeriod() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "DeliveryPeriod",
				"saleContract_DeliveryPeriod");
		return data;
	}

	@DataProvider
	public Object[][] getSaleContract_PaymentTerms() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "PaymentTerms",
				"saleContract_PaymentTerms");
		return data;
	}

	@DataProvider
	public Object[][] getSaleContract_TermsandCondition() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "TermsCondition",
				"saleContract_TermsandCondition");
		return data;
	}

	@DataProvider
	public Object[][] getCostAccrualpage_Details() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "CostAccrual",
				"costAccrualPageForm" );
		return data;
	}

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newContractPageFlow=new NewContractPageFlow();
	}

	@Test(priority=1)
	public void loginandClickNewSaleContract(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newSaleContract();
	}

	@Test(priority=2,description="Verifying the Sale Contract destination page title")
	public void verifyPageTitleTest(){
		newContractPageFlow.saleloginPageTitle();
	}

	@Test(priority=3,dataProvider="getSaleContract_ContractDetails",description="Contract Details")
	public void saleContractDetailsTest(String traderName,String ConIsDate,String masterContract,String dealType,
			String cpName,String brokerName,String brokerIncha,String brokerRefNo,String cpConRefNo,String INCOTerm,
			String brokertext,String brokerComSel,String paymentTerms,String freightTerms,String contQuaUnit,
			String operator,String personIncha,String personSecInCha) throws Exception{

		newContractPageFlow.contractDetails(traderName,ConIsDate,masterContract,dealType,
				cpName,brokerName,brokerIncha,brokerRefNo,cpConRefNo,INCOTerm,brokertext,brokerComSel,paymentTerms,
				freightTerms,contQuaUnit,operator,personIncha,personSecInCha);
		Assert.assertTrue(true, "saleContract_ContractDetails filled successfully");
	} 

	@Test(priority=4,dataProvider="getSaleContract_ItemDetails",description="Item Details",
			dependsOnMethods={"saleContractDetailsTest"})
	public void saleContract_ItemDetailsTest(String product,String origin,String cropYear,String quality,
			String profitCenter,String strategy,String shortDesc,String longDesc) throws Exception{
		newContractPageFlow.itemDetails(product,origin,cropYear,quality,profitCenter,
				strategy,shortDesc,longDesc);
		Assert.assertTrue(true, "saleContract_ItemDetails filled successfully");
	} 

	@Test(priority=5,dataProvider="getSaleContract_QuantityDetails",description="Quantity Details",
			dependsOnMethods={"saleContract_ItemDetailsTest"})
	public void saleContract_QuantityDetailsTest(String conAreaInput,String conAreaSelect,String expectedYieldInput,
			String qualityInput,String itemQuaSel,String packType,String packSize,String minTol,String MaxTol,String tolType,
			String tolLevel,String tolremark) throws Exception{

		newContractPageFlow.quantityDetails(qualityInput,itemQuaSel,packType,
				packSize,minTol,MaxTol,tolType,tolLevel,tolremark);
		Assert.assertTrue(true, "saleContract_QuantityDetails filled successfully");
	} 

	@Test(priority=6,dataProvider="getSaleContract_BasisPrice",description="Basis Price Type",
			dependsOnMethods={"saleContract_QuantityDetailsTest"})
	public void saleContract_BasisPriceTest(String pdSechedule,String priceType,String futInstru,
			String priceMon,String basisEnter,String basisSel,String prFixOpt,String prFixMethod ) throws Exception{

		newContractPageFlow.basisPrice(pdSechedule,priceType,futInstru,priceMon,basisEnter,
				basisSel,prFixOpt,prFixMethod );
		Assert.assertTrue(true, "saleContract_BasisPrice filled successfully");
	} 

	@Test(priority=7,dataProvider="getSaleContract_DeliveryDetails",description="Delivery Details",
			dependsOnMethods={"saleContract_BasisPriceTest"})
	public void saleContract_DeliveryDetailsTest(String location,String country,String port) throws Exception{

		newContractPageFlow.deliveryDetails(location,country,port);
		Assert.assertTrue(true, "saleContract_DeliveryDetails filled successfully");
	} 

	@Test(priority=8,dataProvider="getSaleContract_DeliveryPeriod",description="Delivery Period",
			dependsOnMethods={"saleContract_DeliveryDetailsTest"})
	public void saleContract_DeliveryPeriodTest(String shipFrom,String shipTo) throws Exception{

		newContractPageFlow.deliveryPeriod(shipFrom,shipTo);
		Assert.assertTrue(true, "saleContract_DeliveryPeriod filled successfully");
	} 

	@Test(priority=9,dataProvider="getSaleContract_PaymentTerms",
			dependsOnMethods={"saleContract_DeliveryPeriodTest"})
	public void saleContract_PaymentTermsTest(String payDueDate,String invDocPrice,String taxScheduleApplicableCountry,String taxScheduleApplicableStates,String taxSchedule) throws Exception{

		newContractPageFlow.paymentTerms(payDueDate,invDocPrice,taxScheduleApplicableCountry,taxScheduleApplicableStates,taxSchedule);
		Assert.assertTrue(true, "saleContract_PaymentTerms filled successfully");
	} 

	@Test(priority=10,dataProvider="getSaleContract_TermsandCondition",
			dependsOnMethods={"saleContract_PaymentTermsTest"})
	public void saleContract_TermsandConditionTest(String lawContract,String arbitration,String quaFinalAt,
			String weighFinalAt) throws Exception{
		newContractPageFlow.termsandCondition(lawContract,arbitration,quaFinalAt,weighFinalAt);
		Assert.assertTrue(true, "saleContract_TermsandCondition filled successfully");
	} 

	
	@Test(priority=11,dataProvider="getCostAccrualpage_Details",description="Executing CostAccrual")
	public void costAccrualPageFormTest(String valuationIncoTerm,String valuationLocationTypeGroup,String valuationLocation,
			String valuationLocationType,String fXPricetoPosition,String expectedDeliveryLocation,String locationCountry,
			String locationCity,String itemRefNo,String costComponentName,String incomeExpence,String estimateFor,
			String cpName,String rateType,String costValue,String costValueUnit,String fxToBase,String costAmount,
			String comments) throws Exception{

		newContractPageFlow.costAccrualPageForm(valuationIncoTerm,valuationLocationTypeGroup,valuationLocation,
				valuationLocationType,fXPricetoPosition,expectedDeliveryLocation,locationCountry,locationCity,itemRefNo
				,costComponentName,incomeExpence,estimateFor,cpName,rateType,costValue,costValueUnit,fxToBase,costAmount,comments);
		Assert.assertTrue(true, "Cost Accrual Trade Form filled successfully");
	} 
	
	@Test(priority=12,description="Storing Sale Ref No in result file")
	public void store_saleContractNoTest() throws Exception{
		newContractPageFlow.store_saleContractNo();
		Assert.assertTrue(true, "store_Sale RefNO Stored successfully");
	}
	@Test(priority=13,dependsOnMethods="store_saleContractNoTest")
	public void verifyContract() {
		newContractPageFlow.verifyContract(SeleniumLibs.getStoredResultsfromFile("saleContractRefNo"));
		Assert.assertTrue(true, "Purchase sale Verified successfully");
	}


}
