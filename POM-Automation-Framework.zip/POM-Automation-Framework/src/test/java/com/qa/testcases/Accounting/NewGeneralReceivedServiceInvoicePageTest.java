package com.qa.testcases.Accounting;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewInvoicePageFlow;
import com.qa.util.TestDataUtil;

public class NewGeneralReceivedServiceInvoicePageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewInvoicePageFlow newInvoicePageFlow;
	
	
	@DataProvider
	public Object[][] getgeneral_Service_Inv_Received_Data() throws Exception{
		Object data[][] = TestDataUtil.getTestData("InvoiceData.xlsx", "GeneralServiceInvoice",
				"general_Service_Inv_Received_Details" );
		return data;
	}
	
	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newInvoicePageFlow=new NewInvoicePageFlow();
	}
	
	
	@Test(priority=1)
	public void loginandClickNewGeneralServiceInvoiceReceived(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newGeneralServiceInvoiceReceived();
	}

	@Test(priority=2,dataProvider="getgeneral_Service_Inv_Received_Data",description=" General Service invoice received Details")
	public void create_Income_ExpenseTest(String CPInvoiceRefENter,String CpReceivedInvSelect,String invoiceCurrencySelect,String taxSchedAppCountryReceivedInv,
			String taxSchedReceivedInv,String productGeneralInvSelect,String originGeneralInvSelect,String cropYearGeneralInvSelect,
			String qualityGeneralInvSelect,String costReceivedInvSelect,String monthReceivedInvSelect,String yearReceivedInvEnter,
			String actualCostGeneralReceivedInvEnter,String profitCenterGeneralReceivedInvEnter,String bankNamePrePaymentSelect,
			String accountNamePrePaymentSelect) throws Exception{
		
			newInvoicePageFlow.general_Service_Inv_Received(CPInvoiceRefENter,CpReceivedInvSelect,invoiceCurrencySelect,taxSchedAppCountryReceivedInv,
					taxSchedReceivedInv,productGeneralInvSelect,originGeneralInvSelect,cropYearGeneralInvSelect,qualityGeneralInvSelect,
					costReceivedInvSelect,monthReceivedInvSelect,yearReceivedInvEnter,actualCostGeneralReceivedInvEnter,profitCenterGeneralReceivedInvEnter,
					bankNamePrePaymentSelect,accountNamePrePaymentSelect);
			Assert.assertTrue(true, " successfully filled  and stored  General Received invoice ref no");
		
	} 
	

	
	
	
}
