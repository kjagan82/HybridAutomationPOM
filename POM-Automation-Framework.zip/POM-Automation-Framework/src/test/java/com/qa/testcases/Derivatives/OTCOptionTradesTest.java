package com.qa.testcases.Derivatives;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Derivatives.NewOTCOptionTradesFlow;
import com.qa.flows.Home.HomePageFlow;
import com.qa.util.TestDataUtil;

/**
 * @author jaganmohan.k
 *
 */
public class OTCOptionTradesTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewOTCOptionTradesFlow newOTCOptionTradesFlow;

	@DataProvider
	public Object[][] getBuyOTCOptionTradeData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("TradesData.xlsx", "OTCOptionTrades","NewBuyOTCOptionTradesDetailsTest" );
		return data;
	}
	
	@DataProvider
	public Object[][] getSellOTCOptionTradeData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("TradesData.xlsx", "OTCOptionTrades","NewSellOTCOptionTradesDetailsTest" );
		return data;
	}

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newOTCOptionTradesFlow=new NewOTCOptionTradesFlow();
	}

	@Test(priority=1)
	public void verifyPageTitleTest(){
		newOTCOptionTradesFlow.loginPageTitle();
	}
	
	@Test(priority=2,dataProvider="getBuyOTCOptionTradeData")
	public void NewBuyOTCOptionTradesDetailsTest(String trader,String CounterParty,String MarketLocationCountry,String MarketLocationState,String MarketLocationCity,
			String Product,String Quality,String ExchangeInstrument,String PromptDeliveryDetailsType,String PromptDeliveryDetailsName,String TradeType,
			String Quantity,String QuantityUnit,String SettlementCurrency,String StrikePrice,String StrikePriceUnit,String PremiumDiscount,String PremiumDiscountPriceUnit,
			String PaymentTerms,String Broker,String BrokerCommType,String ProfitCenter,String Strategy,String Purpose,String Nominee) throws Exception{

		homePageFlow.clickOnNewOTCOption();
		newOTCOptionTradesFlow.fillNewOTCOptionDetails( trader, CounterParty, MarketLocationCountry, MarketLocationState, MarketLocationCity, Product,
				 Quality, ExchangeInstrument, PromptDeliveryDetailsType, PromptDeliveryDetailsName, TradeType, Quantity,
				 QuantityUnit, SettlementCurrency, StrikePrice,StrikePriceUnit, PremiumDiscount, PremiumDiscountPriceUnit, PaymentTerms,
				 Broker, BrokerCommType, ProfitCenter, Strategy, Purpose, Nominee);
		Assert.assertTrue(true, "OTCOption "+TradeType+"Trade Form filled successfully");
	} 
	
	
	@Test(priority=3,dataProvider="getSellOTCOptionTradeData")
	public void NewSellOTCOptionTradesDetailsTest(String trader,String CounterParty,String MarketLocationCountry,String MarketLocationState,String MarketLocationCity,
			String Product,String Quality,String ExchangeInstrument,String PromptDeliveryDetailsType,String PromptDeliveryDetailsName,String TradeType,
			String Quantity,String QuantityUnit,String SettlementCurrency,String StrikePrice,String StrikePriceUnit,String PremiumDiscount,String PremiumDiscountPriceUnit,
			String PaymentTerms,String Broker,String BrokerCommType,String ProfitCenter,String Strategy,String Purpose,String Nominee) throws Exception{

		homePageFlow.clickOnNewOTCOption();
		newOTCOptionTradesFlow.fillNewOTCOptionDetails( trader, CounterParty, MarketLocationCountry, MarketLocationState, MarketLocationCity, Product,
				 Quality, ExchangeInstrument, PromptDeliveryDetailsType, PromptDeliveryDetailsName, TradeType, Quantity,
				 QuantityUnit, SettlementCurrency, StrikePrice,StrikePriceUnit, PremiumDiscount, PremiumDiscountPriceUnit, PaymentTerms,
				 Broker, BrokerCommType, ProfitCenter, Strategy, Purpose, Nominee);
		Assert.assertTrue(true, "OTCOption "+TradeType+"Trade Form filled successfully");
	} 


}
