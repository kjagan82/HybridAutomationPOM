package com.qa.testcases.Physicals;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Physicals.NewContractFixPricePageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewPurchaseBasisPriceFixationPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	NewContractFixPricePageFlow newContractFixPricePageFlow;

	@DataProvider
	public Object[][] getPurchase_Price_Fix_Data() throws Exception{

		Object data[][] = TestDataUtil.getTestData("PriceFixationData.xlsx", "PriceFixation",
				"purchase_Price_Fixation_Details");
		return data;
	}
	

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newContractFixPricePageFlow=new NewContractFixPricePageFlow();
	}

	@Test(priority=1)
	public void clickPhysicalContractItems(){
		homePageFlow.physicalContractItems();
		Assert.assertTrue(true, "SuccessFully Clicked and Landed in ContractItems Page!!!");
	}

	@Test(priority=2,description="Verifying the production Contract destination page title")
	public void search_ContractTest() throws Exception{
		String purchaseContractRefNO=SeleniumLibs.getStoredResultsfromFile("purchaseContractRefNo");
		newContractFixPricePageFlow.search_Contract(purchaseContractRefNO);
		Assert.assertTrue(true, "Purchase contract price fixation done successfully!!!");
	}
	
	@Test(priority=3,dataProvider="getPurchase_Price_Fix_Data",dependsOnMethods="search_ContractTest",description="Entering the production Contract Price fixation")
	public void purchaseContractPriceFixTest(String quantityFixedEnter,String futurePriceEnter,String FXBasisToPayInEnter,String futureMonth) throws Exception{
		newContractFixPricePageFlow.Purchase_Con_Basis_Price_Fixation(quantityFixedEnter,futurePriceEnter,FXBasisToPayInEnter,futureMonth);
		Assert.assertTrue(true, "purchase contract price fixation done successfully!!!");
	}

}
