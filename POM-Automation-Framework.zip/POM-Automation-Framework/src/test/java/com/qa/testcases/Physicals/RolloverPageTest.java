package com.qa.testcases.Physicals;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Physicals.UnderfillAndOverfillPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class RolloverPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	UnderfillAndOverfillPageFlow underfillAndOverfillPageFlow;

	 @DataProvider
		public Object[][] getRolloverPurchaseDetailsData() throws Exception{
			Object data[][] = TestDataUtil.getTestData("ContractItemOperations.xlsx","Rollover",
					"RolloverPurchase_Details" );
			return data;
		}
	 @DataProvider
		public Object[][] getRolloverSalesDetailsData() throws Exception{
			Object data[][] = TestDataUtil.getTestData("ContractItemOperations.xlsx","Rollover",
					"RolloverSale_Details" );
			return data;
		}
	 
	 @DataProvider
		public Object[][] getRolloverProductionDetailsData() throws Exception{
			Object data[][] = TestDataUtil.getTestData("ContractItemOperations.xlsx","Rollover",
					"RolloverProduction_Details" );
			return data;
		}
	 
		
	 @BeforeSuite
		public void setUp() throws Exception {
			homePageFlow = new HomePageFlow();
			underfillAndOverfillPageFlow=new UnderfillAndOverfillPageFlow();
		}
		
	
	 @Test(priority=1,dataProvider="RolloverPurchase_Details",description="FiltertheContract")
		public void purchaseRolloverTest(String RolloverFromMonth,String RolloverToMonth,
				String qtytoRollOver,String rolloverSpread,String personInCharge) throws Exception{
		 
		 homePageFlow.ContractItemListAll();//click on contractListItem
		 
		 String RolloverrefnoType="PurchaseOverfillrefno";
		 String contractRefNo=SeleniumLibs.getStoredResultsfromFile("purchaseContractRefNo");
		 underfillAndOverfillPageFlow.search_Contract(contractRefNo);
		 underfillAndOverfillPageFlow.linkRollOver();
		 underfillAndOverfillPageFlow.rolloverPriceMonth_activity(RolloverFromMonth,RolloverToMonth,qtytoRollOver,
				 rolloverSpread,personInCharge,contractRefNo,RolloverrefnoType);
		 Assert.assertTrue(true, "RolloverDetails_DetailsTest filled successfully");
	 }
	 
	 
	 
	 @Test(priority=2,dataProvider="getRolloverSalesDetailsData",description="SalesRollover")
		public void saleUnderfillOverfillTest(String RolloverFromMonth,String RolloverToMonth,
				String qtytoRollOver,String rolloverSpread,String personInCharge) throws Exception{
		 
		 homePageFlow.ContractItemListAll();//click on contractListItem
		 
		 String RolloverrefnoType="saleOverfillrefno";
		 String contractRefNo=SeleniumLibs.getStoredResultsfromFile("saleContractRefNo");
		 underfillAndOverfillPageFlow.search_Contract(contractRefNo);
		 underfillAndOverfillPageFlow.linkRollOver();
		 underfillAndOverfillPageFlow.rolloverPriceMonth_activity(RolloverFromMonth,RolloverToMonth,qtytoRollOver,
				 rolloverSpread,personInCharge,contractRefNo,RolloverrefnoType);
		 Assert.assertTrue(true, "RolloverDetails_DetailsTest filled successfully");
	 }
	 
	 @Test(priority=4,dataProvider="RolloverProduction_Details",description="ProductionRollover")
		public void productionUnderfillOverfillTest(String RolloverFromMonth,String RolloverToMonth,
				String qtytoRollOver,String rolloverSpread,String personInCharge) throws Exception{
		 
		 homePageFlow.ContractItemListAll();//click on contractListItem
		 
		 String RolloverrefnoType="ProductionOverfillrefno";
		 String contractRefNo=SeleniumLibs.getStoredResultsfromFile("productionRefNO");
		 underfillAndOverfillPageFlow.search_Contract(contractRefNo);
		 underfillAndOverfillPageFlow.linkRollOver();
		 underfillAndOverfillPageFlow.rolloverPriceMonth_activity(RolloverFromMonth,RolloverToMonth,qtytoRollOver,
				 rolloverSpread,personInCharge,contractRefNo,RolloverrefnoType);
		 Assert.assertTrue(true, "RolloverDetails_DetailsTest filled successfully");
	 }
	 
}
