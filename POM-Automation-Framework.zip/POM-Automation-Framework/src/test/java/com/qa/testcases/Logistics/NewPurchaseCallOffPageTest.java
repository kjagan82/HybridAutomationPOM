package com.qa.testcases.Logistics;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewCallOffPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewPurchaseCallOffPageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewCallOffPageFlow newCallOffPageFlow;
	
    @DataProvider
	public Object[][] getPurchaseDetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("NewCallOffData.xlsx","NewCalloff",
				"PurchaseCallOff_Details" );
		return data;
	}
	
	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newCallOffPageFlow=new NewCallOffPageFlow();
	}
	
	@Test(priority=1)
	public void loginandClickNewPrePaymentInvoice(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.OpenContractItems();
	}

	
	@Test(priority=2,description="filter the contract")
	public void selectPurchase_ContractTest() throws Exception{
		String contractRefNo=SeleniumLibs.getStoredResultsfromFile("purchaseContractRefNo");
		newCallOffPageFlow.search_Contract(contractRefNo);	
		Assert.assertTrue(true, "select_Contractref details");
	} 
	
	@Test(priority=3,description="Navigate to Purchase Calloff")
	public void newPurchaseCallOff() throws Exception{
		newCallOffPageFlow.purchaseCallofflink();	
		Assert.assertTrue(true, "NewPurchaseCallOff");
	} 
	

	@Test(priority=4,dataProvider="getPurchaseDetailsData",description="PurchaseDetails")
	public void allCalloff_DetailsTest(String ExternalcalloffRefNo,String CalloffType,String calloffBy,
			String personIncharge,String secondIncharge,String qualityProductDetailsSelect
			,String packingType,String calloffQty,String transportMode,String unloadrefno,String transportCompany,String transportAgent,
			String dropoffTime,String expectedPickUpLocationSelect,String locationSelect,String address,
			String remarks,String newQuantityEntry) throws Exception{
		String callOffType="PurchaseCallOffRefno";
		newCallOffPageFlow.allCalloff(ExternalcalloffRefNo,	CalloffType,calloffBy,personIncharge,secondIncharge
				,qualityProductDetailsSelect,packingType,calloffQty,transportMode,unloadrefno,
				transportCompany,transportAgent,dropoffTime,expectedPickUpLocationSelect,locationSelect,address,
				remarks,newQuantityEntry,callOffType);	
		Assert.assertTrue(true, "PurchaseCallOff_DetailsTest filled successfully");
	}
	
}
