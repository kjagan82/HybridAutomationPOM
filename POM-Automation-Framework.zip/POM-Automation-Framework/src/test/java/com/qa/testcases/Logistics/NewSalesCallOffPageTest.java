package com.qa.testcases.Logistics;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewCallOffPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewSalesCallOffPageTest extends TestBaseListener{
	HomePageFlow homePageFlow;
	NewCallOffPageFlow newCallOffPageFlow;
	
    @DataProvider
	public Object[][] getSalesDetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("NewCallOffData.xlsx","NewCalloff",
				"SalesCallOff_Details" );
		return data;
	}
	
	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newCallOffPageFlow=new NewCallOffPageFlow();
	}
	
	@Test(priority=1)
	public void loginandClickNewPrePaymentInvoice(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.OpenContractItems();
	}

	
	@Test(priority=2,description="filter the contract")
	public void selectSales_ContractTest() throws Exception{
		String contractRefNo=SeleniumLibs.getStoredResultsfromFile("saleContractRefNo");
		newCallOffPageFlow.search_Contract(contractRefNo);	
		Assert.assertTrue(true, "select_Contractref details");
	} 
	
	@Test(priority=3,description="Navigate to Sales Calloff")
	public void newSalesCallOff() throws Exception{
		newCallOffPageFlow.salesCallofflink();	
		Assert.assertTrue(true, "NewSalesCallOff");
	} 
	
	@Test(priority=4,dataProvider="getSalesDetailsData",description="SalesDetails")
	public void allCalloff_DetailsTest(String ExternalcalloffRefNo,String CalloffType,String calloffBy,
			String personIncharge,String secondIncharge,String qualityProductDetailsSelect
			,String packingType,String calloffQty,String transportMode,String unloadrefno,String transportCompany,String transportAgent,
			String dropoffTime,String expectedPickUpLocationSelect,String locationSelect,String address,
			String remarks,String newQuantityEntry) throws Exception{
		String callOffType="saleCallOffRefno";
		newCallOffPageFlow.allCalloff(ExternalcalloffRefNo,	CalloffType,calloffBy,personIncharge,secondIncharge
				,qualityProductDetailsSelect,packingType,calloffQty,transportMode,unloadrefno,
				transportCompany,transportAgent,dropoffTime,expectedPickUpLocationSelect,locationSelect,address,
				remarks,newQuantityEntry,callOffType);	
		Assert.assertTrue(true, "SalesCallOff_DetailsTest filled successfully");
	}

	@Test(priority=5,description="CalloffO/PDoc")
	public void OutputDocument_Test()throws Exception{
		String Calloffrefno=SeleniumLibs.getStoredResultsfromFile("saleCallOffRefno");
			newCallOffPageFlow.OutputDocument(Calloffrefno);	
			Assert.assertTrue(true, "Outputdocument details");
		}	
	
	
}
