package com.qa.testcases.Derivatives;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Derivatives.NewFutureTradesFlow;
import com.qa.flows.Home.HomePageFlow;
import com.qa.util.TestDataUtil;

public class FutureTradesPageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewFutureTradesFlow newFutureTradesFlow;
	
	@DataProvider
	public Object[][] getBuyFeatureTradeData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("TradesData.xlsx", "NewFutureTrades",
				"fillBuyFeatureTradeFormTest" );
		return data;
	}
	
	@DataProvider
	public Object[][] getSellFeatureTradeData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("TradesData.xlsx", "NewFutureTrades",
				"fillSellFeatureTradeFormTest" );
		return data;
	}

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newFutureTradesFlow=new NewFutureTradesFlow();
	}
	

	@Test(priority=2,dataProvider="getBuyFeatureTradeData")
	public void fillBuyFeatureTradeFormTest(String trader,String exchangeInstrument,String promptDeliveryDetailsType,
			String	promptDeliveryDetailsName,String tradePrice,String tradePriceTypeUnitId,String lotSize,String quantity_Input,
			String settlementCurrency,String clearerProfileId,String clearerAccountId,
			String profitCenterId,String strategyId,String purposeId,String	nominee) throws Exception{
		
		homePageFlow.clickOnNewFuture();
		newFutureTradesFlow.fillBuyNewFutureTradeDetails(trader,exchangeInstrument,promptDeliveryDetailsType,
				promptDeliveryDetailsName,tradePrice,tradePriceTypeUnitId,lotSize,quantity_Input,settlementCurrency,
				clearerProfileId,clearerAccountId,profitCenterId,strategyId,purposeId,nominee);
		Assert.assertTrue(true, "Trade Form filled successfully");
	} 
	
	@Test(priority=3,dataProvider="getSellFeatureTradeData")
	public void fillSellFeatureTradeFormTest(String trader,String exchangeInstrument,String promptDeliveryDetailsType,
			String	promptDeliveryDetailsName,String tradePrice,String tradePriceTypeUnitId,String lotSize,String quantity_Input,
			String settlementCurrency,String clearerProfileId,String clearerAccountId,
			String profitCenterId,String strategyId,String purposeId,String	nominee) throws Exception{
		
		homePageFlow.clickOnNewFuture();
		newFutureTradesFlow.fillSellNewFutureTradeDetails(trader,exchangeInstrument,promptDeliveryDetailsType,
				promptDeliveryDetailsName,tradePrice,tradePriceTypeUnitId,lotSize,quantity_Input,settlementCurrency,
				clearerProfileId,clearerAccountId,profitCenterId,strategyId,purposeId,nominee);
		Assert.assertTrue(true, "Trade Form filled successfully");
	} 



}
