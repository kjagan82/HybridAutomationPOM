package com.qa.testcases.Logistics;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.TicketImportFlow;

public class TicketImportPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	TicketImportFlow ticketImportFlow;

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		ticketImportFlow=new TicketImportFlow();
	}
	@Test(priority=1)
	public void loginandClickT(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newImportTicket();
	}
	@Test(priority=2,description="Verifying the destination page title")
	public void verifyPageTitleTest(){
		ticketImportFlow.ticketImportPageTitle();
	}

	@Test(priority=3)
	public void ticketImport() throws Exception{
		ticketImportFlow.ticketImport();
		Thread.sleep(2000);
		Assert.assertTrue(true, "Ticket Imported successfully");
		Reporter.log("Ticket Imported successfully", true);
	} 
}
