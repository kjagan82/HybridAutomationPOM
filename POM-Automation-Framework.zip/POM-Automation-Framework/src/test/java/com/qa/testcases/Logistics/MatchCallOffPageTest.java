package com.qa.testcases.Logistics;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewCallOffPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class MatchCallOffPageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewCallOffPageFlow newCallOffPageFlow;
	 
	@DataProvider
		public Object[][] getMatchCalloffDetailsData() throws Exception{
			Object data[][] = TestDataUtil.getTestData("ContractItemOperations.xlsx","MatchCallOff",
					"MatchCallOff_Details" );
			return data;
		}
  
	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newCallOffPageFlow=new NewCallOffPageFlow();
	}
	
	@Test(priority=1)
	public void login(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.ListOfCallOff();
	}

	
	@Test(priority=2,dataProvider="getMatchCalloffDetailsData",description="AllocateSales")
	public void matchCallOff_DetailsTest(String Purchasecalloffqty,String QtytoallocateT1) throws Exception{
		String SaleCallOff=SeleniumLibs.getStoredResultsfromFile("saleCallOffRefno");
		String Purchasecalloff=SeleniumLibs.getStoredResultsfromFile("PurchaseCallOffRefno");
	  newCallOffPageFlow.matchCallOff(Purchasecalloffqty,QtytoallocateT1,SaleCallOff,Purchasecalloff);
		Assert.assertTrue(true, "MatchCalloff_DetailsTest filled successfully");
		
	} 
	
	

	
	
}
