package com.qa.testcases.Accounting;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewInvoicePageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewProvisionalInvoicePageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewInvoicePageFlow newInvoicePageFlow;
	
	
	@DataProvider
	public Object[][] get_ProvisionalInvoice_Data() throws Exception{
		Object data[][] = TestDataUtil.getTestData("InvoiceData.xlsx", "ProvisionalInvoice",
				"provisional_Invoice_Details" );
		return data;
	}
	
	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newInvoicePageFlow=new NewInvoicePageFlow();
	}
	
	
	@Test(priority=1)
	public void loginandClickNewProvisionalInvoice(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newProvisionalInvoice();
	}

	@Test(priority=2,description="Selecting Provisional invoice Details")
	public void select_provisional_InvoiceTest() throws Exception{
		String GMRReffNo=SeleniumLibs.getStoredResultsfromFile("GMRrefNo");
			newInvoicePageFlow.select_provisional_Invoice(GMRReffNo);
			Assert.assertTrue(true, " successfully selected");
	} 
	
	@Test(priority=3,dataProvider="get_ProvisionalInvoice_Data",description="Selecting Provisional invoice Details")
	public void provisional_Invoice_DetailsTest(String CPInvRefNOENter,String CpProvisionalInvSelect,String amountToPayEnter
			,String roundAdjusEnter,String bankNameProvisionalSelect,String accountNameProvisionalSelect) throws Exception{
		
			newInvoicePageFlow.provisional_Invoice_Details(CPInvRefNOENter,CpProvisionalInvSelect,amountToPayEnter,
					roundAdjusEnter,bankNameProvisionalSelect,accountNameProvisionalSelect);
			Assert.assertTrue(true, " successfully filled  and stored ref no");
	} 
	
	
	
}
