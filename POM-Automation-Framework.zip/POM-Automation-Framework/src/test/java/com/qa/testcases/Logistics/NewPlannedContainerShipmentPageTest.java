package com.qa.testcases.Logistics;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Logistics.NewPlannedContainerShipmentPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewPlannedContainerShipmentPageTest extends TestBaseListener{

	HomePageFlow homePageFlow;
	NewPlannedContainerShipmentPageFlow newPlannedContainerShimentPageFlow;
	
	@DataProvider
	public Object[][] getplanned_Shipment_DetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("PlannedContainerShipmentData.xlsx", "PlannedShipment",
				"planned_Shipment_Details" );
		return data;
	}
	
	
	@DataProvider
	public Object[][] getvoyage_DetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("PlannedContainerShipmentData.xlsx", "VoyageDetails",
				"voyage_Details" );
		return data;
	}

	
	@DataProvider
	public Object[][] getsourceLoading_Manage_Allocations_DetailsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("PlannedContainerShipmentData.xlsx", "SourceLoadingManage",
				"sourceLoading_Manage_Allocations" );
		return data;
	}

	
	@DataProvider
	public Object[][] gettransLoading_Manage_AllocationsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("PlannedContainerShipmentData.xlsx", "TransLoadingManage",
				"transLoading_Manage_Allocations" );
		return data;
	}

	
	@DataProvider
	public Object[][] getcostEstimateData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("PlannedContainerShipmentData.xlsx", "CostEstimate",
				"cost_Estimate" );
		return data;
	}
	
	@DataProvider
	public Object[][] getadd_DeductionsData() throws Exception{
		Object data[][] = TestDataUtil.getTestData("PlannedContainerShipmentData.xlsx", "AddDeduction",
				"add_Deductions" );
		return data;
	}


	@BeforeSuite
	public void setUp() throws Exception {
		homePageFlow = new HomePageFlow();
		newPlannedContainerShimentPageFlow=new NewPlannedContainerShipmentPageFlow();
	}
	
	@Test(priority=1)
	public void loginandClickNewPlannedContainerShipment(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newPlannedContainerShipment();
	}

	
	@Test(priority=2,dataProvider="getplanned_Shipment_DetailsData",description="planned Shipment Details")
	public void planned_Shipment_DetailsTest(String activityDate,String productSelect,String originSelect,String cropYearSelect,
			String qualitySelect,String CpNameSelect,String plannedQtyEnter,String plannedQtySelect) throws Exception{
		newPlannedContainerShimentPageFlow.planned_Shipment_Details(activityDate,productSelect,originSelect,cropYearSelect,
				qualitySelect,CpNameSelect,plannedQtyEnter,plannedQtySelect);		
		Assert.assertTrue(true, "planned_Shipment_Details filled successfully");
	} 
	
	@Test(priority=3,dataProvider="getvoyage_DetailsData",description="voyage Details")
	public void voyage_DetailsTest(String shippingLineSelect,String noOfContainerEnter,
			String loadPortSelect,String dischargePortSelect) throws Exception{
		newPlannedContainerShimentPageFlow.voyage_Details(shippingLineSelect,noOfContainerEnter,loadPortSelect,dischargePortSelect);		
		Assert.assertTrue(true, "voyage_Details filled successfully");
	} 
	
	@Test(priority=4,dataProvider="getsourceLoading_Manage_Allocations_DetailsData",description="sourceLoading_Manage_Allocations Details")
	public void sourceLoading_Manage_AllocationsTest(String containerStufftype,String expectSourceLocSelect,
			String expDateOfPickUp,String saleCallOffNoSelect) throws Exception{
		String saleCallOffNo=SeleniumLibs.getStoredResultsfromFile("saleCallOffRefno");
		newPlannedContainerShimentPageFlow.sourceLoading_Manage_Allocations(containerStufftype,expectSourceLocSelect
				,expDateOfPickUp,saleCallOffNo);	
		Assert.assertTrue(true, "sourceLoading_Manage_Allocations filled successfully");
	} 
	
	/*@Test(priority=5,dataProvider="gettransLoading_Manage_AllocationsData",description="transLoading_Manage_Allocations Details")
	public void transLoading_Manage_AllocationsTest(String containerStufftype,String expectSourceLocSelect,
			String expDateOfPickUp,String saleCallOffNoSelect) throws Exception{
		newPlannedContainerShimentPageFlow.transLoading_Manage_Allocations(containerStufftype,expectSourceLocSelect
				,expDateOfPickUp,saleCallOffNoSelect);	
		Assert.assertTrue(true, "transLoading_Manage_Allocations filled successfully");
	} */
	
	@Test(priority=5,dataProvider="getcostEstimateData",description="costEstimate Details")
	public void cost_EstimateTest(String costCompName,String CpNameCostEstimateSelect,String rateType,
			String costValueEnter,String costValueUnitSelect,String FxToBase,String costApplicableSelect,String incomeExpence) throws Exception{
		newPlannedContainerShimentPageFlow.cost_Estimate(costCompName,CpNameCostEstimateSelect,rateType,costValueEnter,
				costValueUnitSelect,FxToBase,costApplicableSelect,incomeExpence);
		Assert.assertTrue(true, "cost_Estimate filled successfully");
	} 
	
	@Test(priority=6,dataProvider="getadd_DeductionsData",description="add_Deductions Details")
	public void add_DeductionsTest(String contractItemSelect,String addDeleteNameSelect,String rateType,
			String rateEnter,String rateSelect,String weightBasis,String addRemarks) throws Exception{
		newPlannedContainerShimentPageFlow.add_Deductions(contractItemSelect,addDeleteNameSelect,rateType,
				rateEnter,rateSelect,weightBasis,addRemarks);
		Assert.assertTrue(true, "add_Deductions filled successfully");
	} 




}
