package com.qa.testcases.Derivatives;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Derivatives.ImportDerivativeTradeFlow;
import com.qa.flows.Home.HomePageFlow;

public class ImportDerivativeTradeTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	ImportDerivativeTradeFlow importDerivativeTradeFlow;

	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		importDerivativeTradeFlow=new ImportDerivativeTradeFlow();
	}
	@Test(priority=1)
	public void loginandClickT(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.derivaticeImportTicket();
	}
	
	@Test(priority=2)
	public void ticketImport() throws Exception{
		importDerivativeTradeFlow.importDerivativeTicket();
		Thread.sleep(2000);
		Assert.assertTrue(true, "Derivatives Ticket Imported successfully");
		Reporter.log("Derivatives Ticket Imported successfully", true);
	} 
}
