package com.qa.testcases.Physicals;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Physicals.NewContractPageFlow;
import com.qa.util.SeleniumLibs;
import com.qa.util.TestDataUtil;

public class NewProductionContractPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	NewContractPageFlow newContractPageFlow;

	@DataProvider
	public Object[][] getProductionContract_ContractDetails() throws Exception{

		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", 
				"ContractDetails", "productionContract_ContractDetails");
		return data;
	}
	@DataProvider
	public Object[][] getProductionContract_ItemDetails() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "ItemDetails", 
				"productionContract_ItemDetails");
		return data;
	}

	
	@DataProvider
	public Object[][] getProductionContract_QuantityDetails() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "QuantityDetails",
				"productionContract_QuantityDetails");
		return data;
	}

	@DataProvider
	public Object[][] getProductionContract_BasisPrice() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "BasisPriceType",
				"productionContract_BasisPrice");
		return data;
	}

	@DataProvider
	public Object[][] getProductionContract_DeliveryDetails() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "DeliveryDetails",
				"productionContract_DeliveryDetails");
		return data;
	}

	@DataProvider
	public Object[][] getProductionContract_DeliveryPeriod() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "DeliveryPeriod",
				"productionContract_DeliveryPeriod");
		return data;
	}

	@DataProvider
	public Object[][] getProductionContract_PaymentTerms() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "PaymentTerms",
				"productionContract_PaymentTerms");
		return data;
	}

	@DataProvider
	public Object[][] getProductionContract_TermsandCondition() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "TermsCondition",
				"productionContract_TermsandCondition");
		return data;
	}

	@DataProvider
	public Object[][] getCostAccrualpage_Details() throws Exception{
		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", "CostAccrual",
				"costAccrualPageForm" );
		return data;
	}



	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newContractPageFlow=new NewContractPageFlow();
	}

	@Test(priority=1)
	public void loginandClickNewPurchaseContract(){
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.newPurchaseContract();
	}

	@Test(priority=2,description="Verifying the production Contract destination page title")
	public void verifyPageTitleTest(){
		newContractPageFlow.productionloginPageTitle();
	}

	@Test(priority=3,dataProvider="getProductionContract_ContractDetails",description="Contract Details")
	public void productionContractDetailsTest(String traderName,String ConIsDate,String masterContract,String dealType,
			String cpName,String brokerName,String brokerIncha,String brokerRefNo,String cpConRefNo,String INCOTerm,
			String brokertext,String brokerComSel,String paymentTerms,String freightTerms,String contQuaUnit,
			String operator,String personIncha,String personSecInCha) throws Exception{
       newContractPageFlow.production_contract_checKBox();
		newContractPageFlow.contractDetails(traderName,ConIsDate,masterContract,dealType,
				cpName,brokerName,brokerIncha,brokerRefNo,cpConRefNo,INCOTerm,brokertext,brokerComSel,paymentTerms,
				freightTerms,contQuaUnit,operator,personIncha,personSecInCha);
		Assert.assertTrue(true, "Production_Contract_ContractDetails filled successfully");
	} 

	@Test(priority=4,dataProvider="getProductionContract_ItemDetails",description="Item Details",
			dependsOnMethods={"productionContractDetailsTest"})
	public void productionContract_ItemDetailsTest(String product,String origin,String cropYear,String quality,
			String profitCenter,String strategy,String shortDesc,String longDesc) throws Exception{
		newContractPageFlow.itemDetails(product,origin,cropYear,quality,profitCenter,
				strategy,shortDesc,longDesc);
		Assert.assertTrue(true, "Production_Contract_ItemDetails filled successfully");
	} 

	@Test(priority=5,dataProvider="getProductionContract_QuantityDetails",description="Quantity Details",
			dependsOnMethods={"productionContract_ItemDetailsTest"})
	public void productionContract_QuantityDetailsTest(String conAreaInput,String conAreaSelect,String expectedYieldInput,
			String qualityInput,String itemQuaSel,String packType,
			String packSize,String minTol,String MaxTol,String tolType,String tolLevel,String tolremark) throws Exception{

		newContractPageFlow.production_quantityDetails(conAreaInput,conAreaSelect,expectedYieldInput,qualityInput,itemQuaSel,packType,
				packSize,minTol,MaxTol,tolType,tolLevel,tolremark);
		Assert.assertTrue(true, "Production_Contract_QuantityDetails filled successfully");
	} 

	@Test(priority=6,dataProvider="getProductionContract_BasisPrice",description="Basis Price Type",
			dependsOnMethods={"productionContract_QuantityDetailsTest"})
	public void productionContract_BasisPriceTest(String pdSechedule,String priceType,String futInstru,
			String priceMon,String basisEnter,String basisSel,String prFixOpt,String prFixMethod ) throws Exception{

		newContractPageFlow.basisPrice(pdSechedule,priceType,futInstru,priceMon,basisEnter,
				basisSel,prFixOpt,prFixMethod );
		Assert.assertTrue(true, "Production_Contract_BasisPrice filled successfully");
	} 

	@Test(priority=7,dataProvider="getProductionContract_DeliveryDetails",description="Delivery Details",
			dependsOnMethods={"productionContract_BasisPriceTest"})
	public void productionContract_DeliveryDetailsTest(String location,String country,String port) throws Exception{

		newContractPageFlow.deliveryDetails(location,country,port);
		Assert.assertTrue(true, "Production_Contract_DeliveryDetails filled successfully");
	} 

	@Test(priority=8,dataProvider="getProductionContract_DeliveryPeriod",description="Delivery Period",
			dependsOnMethods={"productionContract_DeliveryDetailsTest"})
	public void productionContract_DeliveryPeriodTest(String shipFrom,String shipTo) throws Exception{

		newContractPageFlow.deliveryPeriod(shipFrom,shipTo);
		Assert.assertTrue(true, "Production_Contract_DeliveryPeriod filled successfully");
	} 

	@Test(priority=9,dataProvider="getProductionContract_PaymentTerms",
			dependsOnMethods={"productionContract_DeliveryPeriodTest"})
	public void productionContract_PaymentTermsTest(String payDueDate,String invDocPrice,String taxScheduleApplicableCountry,String taxScheduleApplicableStates,String taxSchedule) throws Exception{

		newContractPageFlow.paymentTerms(payDueDate,invDocPrice,taxScheduleApplicableCountry,taxScheduleApplicableStates,taxSchedule);
		Assert.assertTrue(true, "Production_Contract_PaymentTerms filled successfully");
	} 

	@Test(priority=10,dataProvider="getProductionContract_TermsandCondition",
			dependsOnMethods={"productionContract_PaymentTermsTest"})
	public void productionContract_TermsandConditionTest(String lawContract,String arbitration,String quaFinalAt,
			String weighFinalAt) throws Exception{
		newContractPageFlow.termsandCondition(lawContract,arbitration,quaFinalAt,weighFinalAt);
		Assert.assertTrue(true, "Production_Contract_TermsandCondition filled successfully");
	} 

	@Test(priority=11,dataProvider="getCostAccrualpage_Details",description="Executing CostAccrual")
	public void costAccrualPageFormTest(String valuationIncoTerm,String valuationLocationTypeGroup,String valuationLocation,
			String valuationLocationType,String fXPricetoPosition,String expectedDeliveryLocation,String locationCountry,
			String locationCity,String itemRefNo,String costComponentName,String incomeExpence,String estimateFor,
			String cpName,String rateType,String costValue,String costValueUnit,String fxToBase,String costAmount,
			String comments) throws Exception{

		newContractPageFlow.costAccrualPageForm(valuationIncoTerm,valuationLocationTypeGroup,valuationLocation,
				valuationLocationType,fXPricetoPosition,expectedDeliveryLocation,locationCountry,locationCity,itemRefNo
				,costComponentName,incomeExpence,estimateFor,cpName,rateType,costValue,costValueUnit,fxToBase,costAmount,comments);
		Assert.assertTrue(true, "Cost Accrual Trade Form filled successfully");
	} 
	
	@Test(priority=12,description="Storing Production Ref No in result file")
	public void store_ProductionRefNOTest() throws Exception{
		newContractPageFlow.store_ProductionRefNO();
		Assert.assertTrue(true, "store_ProductionRefNO Stored successfully");
	} 
	
	
	@Test(priority=12)
	public void verifyContract() {
		newContractPageFlow.verifyContract(SeleniumLibs.getStoredResultsfromFile("productionRefNO"));
		Assert.assertTrue(true, "production Contract Verified successfully");
	}


}
