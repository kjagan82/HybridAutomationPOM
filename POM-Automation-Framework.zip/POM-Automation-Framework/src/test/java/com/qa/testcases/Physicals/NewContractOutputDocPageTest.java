package com.qa.testcases.Physicals;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Physicals.NewContractPageFlow;
import com.qa.util.SeleniumLibs;

public class NewContractOutputDocPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	NewContractPageFlow newContractPageFlow;
	

	
	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newContractPageFlow=new NewContractPageFlow();
	}

	@Test(priority=1,description="Creating purchase Output Document")
	public void purchaseOutputDocument() throws Exception{
		
		homePageFlow.ContractsListAll();
		String contractNO= SeleniumLibs.getStoredResultsfromFile("purchaseContractRefNo");
		String templateType="Purchase";
		String filtertemplateName=SeleniumLibs.getStoredResultsfromFile("purchasePrintableRefNo");
		newContractPageFlow.createOutputDocument(contractNO, templateType, filtertemplateName);
		Assert.assertTrue(true, "Succesfully created Purchase Output Document!!!");
	}
	
	@Test(priority=2,description="Creating Sales Output Document")
	public void saleOutputDocument() throws Exception{
		Assert.assertTrue(true, "Login success !!!");
		homePageFlow.ContractsListAll();
		String contractNO= SeleniumLibs.getStoredResultsfromFile("saleContractRefNo");
		String templateType="Sales";
		String filtertemplateName=SeleniumLibs.getStoredResultsfromFile("salePrintableRefNo");
		newContractPageFlow.createOutputDocument(contractNO, templateType, filtertemplateName);
		Assert.assertTrue(true, "Succesfully created Sales Output Document!!!");
	}
	

}
