package com.qa.testcases.Physicals;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import com.qa.base.TestBaseListener;
import com.qa.flows.Home.HomePageFlow;
import com.qa.flows.Physicals.NewContractPageFlow;
import com.qa.util.SeleniumLibs;

public class NewContractUtilityPageTest extends TestBaseListener {
	HomePageFlow homePageFlow;
	NewContractPageFlow newContractPageFlow;
/*
	@DataProvider
	public Object[][] getProductionContract_ContractDetails() throws Exception{

		Object data[][] = TestDataUtil.getTestData("ContractData.xlsx", 
				"ContractDetails", "productionContract_ContractDetails");
		return data;
	}*/
	
	@BeforeSuite
	public void setUp() {
		homePageFlow = new HomePageFlow();
		newContractPageFlow=new NewContractPageFlow();
	}

	
	@Test(priority=1,description="Cloning Purchase contract")
	public void clonePurchaseContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("purchaseContractRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		String ContractType="New Purchase";
		//purchase Clone
		newContractPageFlow.cloneContract(ContractType,"clonePurchaseConRefNo");
		Assert.assertTrue(true, "Successfully Clone Purchase Contract and Saved");
	}
	
	@Test(priority=2,description="Cloning Sale contract")
	public void cloneSaleContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("saleContractRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		String ContractType="New Sale";
		//sale Clone
		newContractPageFlow.cloneContract(ContractType,"cloneSaleConRefNo");
		Assert.assertTrue(true, "Successfully Clone Sale Contract and Saved");
	}
	
	@Test(priority=3,description="Cloning Production contract")
	public void cloneProductionContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("productionRefNO");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		String ContractType="New Production";
		//production Clone
		newContractPageFlow.cloneContract(ContractType,"cloneProductionConRefNo");
		Assert.assertTrue(true, "Successfully Clone Production Contract and Saved");
	}
	
	@Test(priority=4,description="Amending Purchase contract and copying item",dependsOnMethods="clonePurchaseContractTest")
	public void amendPurchaseContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("clonePurchaseConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		//production Clone
		newContractPageFlow.contractAmend();
		Assert.assertTrue(true, "Successfully amended Purchase Contract and Saved");
	}
	
	@Test(priority=5,description="Amending Sale contract and copying item",dependsOnMethods="cloneSaleContractTest")
	public void amendSaleContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("cloneSaleConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		//production Clone
		newContractPageFlow.contractAmend();
		Assert.assertTrue(true, "Successfully amended Sale Contract and Saved");
	}
	
	@Test(priority=6,description="Amending Production contract and copying item",dependsOnMethods="cloneProductionContractTest")
	public void amendProductionContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("cloneProductionConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		//production Clone
		newContractPageFlow.contractAmend();
		Assert.assertTrue(true, "Successfully amended Production Contract and Saved");
	}
	
	@Test(priority=7,description="Removing added Item and modifying Purchase contract",dependsOnMethods="amendPurchaseContractTest")
	public void purchaseRemoveItemModifyContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("clonePurchaseConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.removeItemModifyContract();
		Assert.assertTrue(true, "Successfully removed and Modified Purchase Contract and Saved");
	}
	
	@Test(priority=8,description="Removing added Item and modifying sale contract",dependsOnMethods="amendSaleContractTest")
	public void saleRemoveItemModifyContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("cloneSaleConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.removeItemModifyContract();
		Assert.assertTrue(true, "Successfully removed and Modified sale Contract and Saved");
	}
	
	@Test(priority=9,description="Removing added Item and modifying Production contract",dependsOnMethods="amendProductionContractTest")
	public void productionRemoveItemModifyContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("cloneProductionConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.removeItemModifyContract();
		Assert.assertTrue(true, "Successfully removed and Modified Production Contract and Saved");
	}
	
	@Test(priority=10,description="MOdifying Item and saving Purchase contract",dependsOnMethods="purchaseRemoveItemModifyContractTest")
	public void purchaseContractModifyItemTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("clonePurchaseConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.contractModifyItem();
		Assert.assertTrue(true, "Successfully modified item and saved purchase Contract !!!");
	}
	
	@Test(priority=11,description="MOdifying Item and saving sale contract",dependsOnMethods="saleRemoveItemModifyContractTest")
	public void saleContractModifyItemTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("cloneSaleConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.contractModifyItem();
		Assert.assertTrue(true, "Successfully modified item and saved sale Contract !!!");
	}
	
	@Test(priority=12,description="MOdifying Item and saving Production contract",dependsOnMethods="productionRemoveItemModifyContractTest")
	public void productionContractModifyItemTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("cloneProductionConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.contractModifyItem();
		Assert.assertTrue(true, "Successfully modified item and saved Production Contract !!!");
	}
	
	@Test(priority=13,description="Cloning purchase contract and saving in drafts")
	public void purchaseDraftContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("purchaseContractRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		String ContractType="New Purchase";
		String saveVariableName="purchaseDraftRefNo";
		newContractPageFlow.contractDraft(ContractType,saveVariableName);
		//Navigating to LOD
		homePageFlow.ContractsDrafts();
		//verify Draft Presence in draft page
		String draftType="Purchase";//to select in filter
		String draftNo=SeleniumLibs.getStoredResultsfromFile("purchaseDraftRefNo");
		newContractPageFlow.verifyDraft(draftType, draftNo);
		Assert.assertTrue(true, "Successfully created and verified Purchase Draft Contract !!!");
	}
	
	@Test(priority=14,description="Cloning sale contract and saving in drafts")
	public void saleDraftContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("saleContractRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		String ContractType="New Sale";
		String saveVariableName="saleDraftRefNo";
		newContractPageFlow.contractDraft(ContractType,saveVariableName);
		//Navigating to LOD
		homePageFlow.ContractsDrafts();
		//verify Draft Presence in draft page
		String draftType="Sales";//to select in filter
		String draftNo=SeleniumLibs.getStoredResultsfromFile("saleDraftRefNo");
		newContractPageFlow.verifyDraft(draftType, draftNo);
		Assert.assertTrue(true, "Successfully created and verified sale Draft Contract !!!");
	}
	
	@Test(priority=15,description="Cloning Production contract and saving in drafts")
	public void productionDraftContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("productionRefNO");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		String ContractType="New Purchase";
		String saveVariableName="productionDraftRefNo";
		newContractPageFlow.contractDraft(ContractType,saveVariableName);
		//Navigating to LOD
		homePageFlow.ContractsDrafts();
		//verify Draft Presence in draft page
		String draftType="Purchase";//to select in filter
		String draftNo=SeleniumLibs.getStoredResultsfromFile("productionDraftRefNo");
		newContractPageFlow.verifyDraft(draftType, draftNo);
		Assert.assertTrue(true, "Successfully created and verified sale Draft Contract !!!");
	}
	
	@Test(priority=16,description="Cancelling Purchase contract and verifying the status",dependsOnMethods="clonePurchaseContractTest")
	public void cancelPurchaseContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("clonePurchaseConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.cancelContract();//cancelling contract
		homePageFlow.ContractsListAll();
		newContractPageFlow.verifyCancelContract(contractNO);
		Assert.assertTrue(true, "Successfully cancelled and verified the purchase Contract status as pending!!!");
	}
	
	@Test(priority=17,description="Cancelling sale contract and verifying the status",dependsOnMethods="cloneSaleContractTest")
	public void cancelSaleContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("cloneSaleConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.cancelContract();//cancelling contract
		homePageFlow.ContractsListAll();
		newContractPageFlow.verifyCancelContract(contractNO);
		Assert.assertTrue(true, "Successfully cancelled and verified the sale Contract status as pending!!!");
	}
	
	@Test(priority=18,description="Cancelling Production contract and verifying the status",dependsOnMethods="cloneProductionContractTest")
	public void cancelProductionContractTest() throws Exception{
		homePageFlow.ContractsListAll();
		String contractNO=SeleniumLibs.getStoredResultsfromFile("cloneProductionConRefNo");
		//search contract
		newContractPageFlow.searchContract(contractNO);
		newContractPageFlow.cancelContract();//cancelling contract
		homePageFlow.ContractsListAll();
		newContractPageFlow.verifyCancelContract(contractNO);
		Assert.assertTrue(true, "Successfully cancelled and verified the production Contract status as pending!!!");
	}
	
	
	
}
