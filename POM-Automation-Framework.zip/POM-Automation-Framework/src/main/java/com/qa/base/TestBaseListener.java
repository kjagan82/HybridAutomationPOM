package com.qa.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.google.common.collect.Lists;
import com.qa.util.SeleniumLibs;
import com.qa.util.WebEventListener;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

/**
 * @author jaganmohan.k
 *
 */
public class TestBaseListener implements ISuiteListener,ITestListener{

	private static WebDriver driver;
	public static String url;
	private static String userName;
	private static String Password;
	
	public static String browserName;
	public  static EventFiringWebDriver e_driver;
	public static WebEventListener eventListener;
	protected static ExtentReports reports;
	protected static ExtentTest test;
	// WAITING TIME RELATED
	public static final int PAGE_LOAD_TIMEOUT = 300;
	public static final byte IMPLICIT_WAIT = 60;
	public static final byte WAIT_TIME_OUT_SEC = 30;
	public static final int AJAX_WAIT = 200;

	private List<ISuiteListener> suiteListeners = new ArrayList<>();
	private List<ITestListener> testListeners = new ArrayList<>();
	public static WebDriverWait wait;
	public static Logger suite_logs;
	public static Actions actions;
	private String currentDir;
	private static Properties prop;
	private String currentTestSuite;

	public void onStart(ISuite suite) {

		prop = new Properties();
		FileInputStream ip;
		currentDir = System.getProperty("user.dir");
		synchronized(suiteListeners) {
			for (ISuiteListener suiteListener : Lists.reverse(suiteListeners)) {
				suiteListener.onStart(suite);
			}
		}
		suite_logs = Logger.getLogger(TestBaseListener.class.getName());
		try {
			ip = new FileInputStream(currentDir+ "\\\\src\\\\main\\\\java\\\\com\\\\qa\\\\config\\\\Config.properties");
			prop.load(ip);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logs(suite,prop);
		url=suite.getParameter("Environment");
		userName=suite.getParameter("userName");
		Password=suite.getParameter("Password");
		browserName=suite.getParameter("browser");
		currentDir = System.getProperty("user.dir");

		suite_logs.info("Suite Configuration started.......");
		//add appender to any Logger (here is root)
		if(browserName.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", currentDir
					+ "\\Library\\Selenium\\chromedriver.exe");	
			driver = new ChromeDriver(); 
		}
		else if(browserName.equals("FF")){
			System.setProperty("webdriver.gecko.driver", currentDir
					+ "\\Library\\Selenium\\geckodriver.exe");	
			driver = new FirefoxDriver(); 
		}
		e_driver = new EventFiringWebDriver(driver);
		// Now create object of EventListerHandler to register it with EventFiringWebDriver
		eventListener = new WebEventListener();
		e_driver.register(eventListener);
		driver = e_driver;
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().pageLoadTimeout(PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(IMPLICIT_WAIT, TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, WAIT_TIME_OUT_SEC);
		wait = new WebDriverWait(TestBaseListener.getDriver(), 10);
		wait = new WebDriverWait(driver, WAIT_TIME_OUT_SEC);
		actions = new Actions(driver);
		suite_logs.info("Suite Execution started....");
		try {
			driver.get(url);
			suite_logs.info("---------------"+url+"----------------");
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@name='username']")).sendKeys(userName);
			driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Password);
			Thread.sleep(1500);
			driver.findElement(By.xpath("//input[@type='submit' and @value='Login']")).click();
			Thread.sleep(1500);
			SeleniumLibs.waitForAjax();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error(e);
		}

	}

	private void logs(ISuite suite,Properties prop) {
		RollingFileAppender fa = null;
		ConsoleAppender ca = null;
		currentTestSuite = suite.getName();
		fa = new RollingFileAppender();
		ca = new ConsoleAppender();
		PatternLayout layout = new PatternLayout("%d{dd-MM-yyyy HH:mm:ss}-%t- %-5p %C :%L - %m%n");
		fa.setName("File: "+currentTestSuite+"_Logs");
		fa.setLayout(layout);
		fa.setThreshold(Level.toLevel(prop.getProperty("fileLoggingLevel")));
		fa.activateOptions();

		ca.setName("Console: "+currentTestSuite);
		ca.setLayout(layout);
		ca.setThreshold(Level.toLevel(prop.getProperty("consoleLoggingLevel")));
		ca.activateOptions();
		try {
			fa.setFile(currentDir+"\\logs\\"+currentTestSuite+".log",false,true,80);
		} catch (IOException e) {
			TestBaseListener.suite_logs.error(e);
		}
		//add appender to any Logger (here is root)
		try {
			TestBaseListener.suite_logs = Logger.getLogger(currentTestSuite);
			TestBaseListener.suite_logs.addAppender(fa);
			if(prop.getProperty("consoleLogs").equalsIgnoreCase("Y")) {
				suite_logs.addAppender(ca);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			suite_logs.error(e);
		}
	} 

	@Override
	public void onFinish(ISuite suite) {
		// TODO Auto-generated method stub
		//driver.close();
		//driver.quit();
		reports.endTest(test);
		reports.flush();
		synchronized(suiteListeners) {
			for (ISuiteListener suiteListener : suiteListeners) {
				suiteListener.onFinish(suite);
			}
		}
		/*Runtime rt = Runtime.getRuntime();
		try {
			Process proc = rt.exec("taskkill /im chrome.exe /f /t");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}

	public void onTestStart(ITestResult result) {
		//System.out.println("on test start");
		synchronized(testListeners) {
			for (ITestListener testListener : Lists.reverse(testListeners)) {
				testListener.onTestStart(result);
			}
		}
		test = reports.startTest(result.getMethod().getMethodName());
		test.log(LogStatus.INFO, result.getMethod().getMethodName() + " test is started");
	}
	public void onTestSuccess(ITestResult result) {
		//System.out.println("on test success");
		synchronized (testListeners) {
			for (ITestListener testListener : testListeners) {
				testListener.onTestFailure(result);
			}
		}
		test.log(LogStatus.PASS, result.getMethod().getMethodName() + " test is passed");
	}
	public void onTestFailure(ITestResult result) {
		//System.out.println("on test failure");
		synchronized (testListeners) {
			for (ITestListener testListener : testListeners) {
				testListener.onTestSuccess(result);
			}
		}
		test.log(LogStatus.FAIL, result.getMethod().getMethodName() + " test is failed");
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		try {

			FileUtils.copyFile(src, new File(currentDir+"\\test-output\\images\\" + result.getMethod().getMethodName() + ".png"));
			String file = test.addScreenCapture(currentDir+"\\test-output\\images\\" + result.getMethod().getMethodName() + ".png");
			test.log(LogStatus.FAIL, result.getMethod().getMethodName() + " test is failed", file);
			test.log(LogStatus.FAIL, result.getMethod().getMethodName() + " test is failed", result.getThrowable().getMessage());
		} catch (IOException e) {
			suite_logs.error(e);
		}
	}

	public void onTestSkipped(ITestResult result) {
		//System.out.println("on test skipped");
		synchronized (testListeners) {
			for (ITestListener testListener : testListeners) {
				testListener.onTestSkipped(result);
			}
		}
		test.log(LogStatus.SKIP, result.getMethod().getMethodName() + " test is skipped");
	}
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		synchronized (testListeners) {
			for (ITestListener testListener : testListeners) {
				testListener.onTestFailedButWithinSuccessPercentage(result);
			}
		}
		//System.out.println("on test sucess within percentage");
	}
	public void onStart(ITestContext context) {

		synchronized (testListeners) {
			for (ITestListener testListener : Lists.reverse(testListeners)) {
				testListener.onStart(context);
			}
		}
		reports = new ExtentReports(currentDir+"\\\\test-output\\"+new SimpleDateFormat("MMM-dd-yyyy hh-mm-ss").format(new Date()) + "\\\\Report.html");
	}
	public void onFinish(ITestContext context) {
		reports.endTest(test);
		reports.flush();
		synchronized (testListeners) {
			for (ITestListener testListener : testListeners) {
				testListener.onFinish(context);
			}
		}
	}
	public static WebDriver getDriver() {
		return driver;
	}



	public static void setDriver(WebDriver driver) {
		TestBaseListener.driver = driver;
	}

	/**
	 * @return the userName
	 */
	public static String getUserName() {
		return userName;
	}

	/**
	 * @return the password
	 */
	public static String getPassword() {
		return Password;
	}

	/**
	 * @return the suite_logs
	 */
	public static Logger getSuite_logs() {
		return suite_logs;
	}

	/**
	 * @param suite_logs the suite_logs to set
	 */
	public static void setSuite_logs(Logger suite_logs) {
		TestBaseListener.suite_logs = suite_logs;
	}


}
