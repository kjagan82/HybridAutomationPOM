package com.qa.pages.Physicals;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;
public class UnderfillAndOverfillPage {
	
	//Filtercontract//
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement ContractMainFilter;
	
	@FindBy(xpath = "//span[text()='Reset']")
	WebElement filterReset;
	
	@FindBy(xpath = "//select[contains(@id,'contractItemsearchCriteria' )]")
	WebElement filterSearchSelect;

	@FindBy(xpath = "//input[contains(@id,'contractItemcontractRefNo')]")
	WebElement filterSearchInput;
	
	@FindBy(xpath = "//span[text()='Go']")
	WebElement filterGo;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]")
	WebElement contractItemsCheckBox;
	
	@FindBy(xpath = "//span[text()='Contract Operations']")
	WebElement linkContractOperations;
	
	@FindBy(xpath = "//span[text()='Identify Overfill Underfill items']")
	WebElement linkOverfillUnderfillLabel;
	
	@FindBy(xpath = "//span[text()='Roll Over Price Month']")
	WebElement linkRollOverPriceMonthLabel;
	
	//RolloverPriceMonth//
	
    @FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement RolloverIssueDate;
	
	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[2]")
	@CacheLookup
	WebElement RolloverDate;
	
	@FindBy(xpath = "(//select[contains(@id,'priceMonthToRollOver']")
	@CacheLookup
	WebElement RolloverFromMonth;
	
	@FindBy(xpath = "(//select[contains(@id,'rollOverTo']")
	@CacheLookup
	WebElement RolloverToMonth;
	
	@FindBy(xpath = "//input[contains(@id,'rollOverQuan')]")
	WebElement qtytoRollOver;
	
	@FindBy(xpath = "//input[contains(@id,'spread')]")
	WebElement rolloverSpread;
	
	@FindBy(xpath = "//input[contains(@id,'personInChargeId')]")
	WebElement personInCharge;
	
	@FindBy(xpath = "//input[contains(@id,'saveButton')]")
	WebElement btnRolloverSave;
	
	@FindBy(xpath = "//input[contains(@value,'Cancel')]")
	WebElement btnRolloverCancel;

	
	//PricefixforOverfillUnderfill//
	
	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement contractIssueDate;
	
	@FindBy(xpath = "//textarea[contains(@id,'reasonForUnderfillOverfill')]")
	WebElement overfillUnderfillReason;
	
	@FindBy(xpath = "//select[contains(@id,'undrfilOvrfilShipment')]")
	WebElement overfillUnderfillShipment;

	@FindBy(xpath = "//select[contains(@id,'futuresMonth')]")
	WebElement futuresmonth;
	
	@FindBy(xpath = "//input[contains(@id,'futuresPricePriceDetails')]")
	WebElement futurePrice;
	
	@FindBy(xpath = "//input[contains(@id,'basisPricePriceDetails')]")
	WebElement basisPrice;
	
	@FindBy(xpath = "//input[contains(@name,'saveButton')]")
	WebElement savebutton;

	@FindBy(xpath = "//input[contains(@name,'cancelButton')]")
	WebElement cancelbutton;
	
	//ListofOverfill/UnderfillandCaptureRefno//
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement overfillUnderfillFilter;
	
	@FindBy(xpath = "//span[text()='Reset']")
	WebElement overfillUnderfillReset;
	
	@FindBy(xpath = "//input[contains(@id,'contractRefNo') or contains(@id,'searchTextBox') or contains(@name,'referenceNo')]")
	WebElement overfillUnderfillSearchInput;
	
	@FindBy(xpath = "//span[text()='Go']")
	WebElement overfillUnderfillGo;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[3]")
	WebElement underfillOverfillrefno;
	
	//FilterRollover//
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement RolloverFilter;
	
	@FindBy(xpath = "//span[text()='Reset']")
	WebElement RolloverReset;
	
	@FindBy(xpath = "//select[contains(@id,'searchType')]")
	WebElement RolloverselectSearch;
	
	@FindBy(xpath = "//input[contains(@id,'searchValue')]")
	WebElement rolloverSearchInput;
	
	@FindBy(xpath = "//span[text()='Go']")
	WebElement rolloverGo;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[3]")
	WebElement Rolloverrefno;
	
	
	// Initializing the Page Objects:
	public UnderfillAndOverfillPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	/*Utilizations*/
	
	public WebElement getContractMainFilter() {
		return ContractMainFilter;
	}

	public WebElement getFilterReset() {
		return filterReset;
	}

	public WebElement getFilterSearchSelect() {
		return filterSearchSelect;
	}
	

	public WebElement getFilterSearchInput() {
		return filterSearchInput;
	}

	public WebElement getFilterGo() {
		return filterGo;
	}

	public WebElement getContractItemsCheckBox() {
		return contractItemsCheckBox;
	}

	public WebElement getLinkOverfillUnderfillLabel() {
		return linkOverfillUnderfillLabel;
	}

	public WebElement getContractIssueDate() {
		return contractIssueDate;
	}

	public WebElement getOverfillUnderfillReason() {
		return overfillUnderfillReason;
	}

	public WebElement getOverfillUnderfillShipment() {
		return overfillUnderfillShipment;
	}

	public WebElement getFuturesmonth() {
		return futuresmonth;
	}

	public WebElement getFuturePrice() {
		return futurePrice;
	}

	public WebElement getBasisPrice() {
		return basisPrice;
	}

	public WebElement getSavebutton() {
		return savebutton;
	}

	public WebElement getCancelbutton() {
		return cancelbutton;
	}

	public WebElement getOverfillUnderfillFilter() {
		return overfillUnderfillFilter;
	}

	public WebElement getOverfillUnderfillReset() {
		return overfillUnderfillReset;
	}

	public WebElement getOverfillUnderfillSearchInput() {
		return overfillUnderfillSearchInput;
	}

	public WebElement getOverfillUnderfillGo() {
		return overfillUnderfillGo;
	}

	public WebElement getUnderfillOverfillrefno() {
		return underfillOverfillrefno;
	}

	public WebElement getLinkContractOperations() {
		return linkContractOperations;
	}

	public WebElement getLinkRollOverPriceMonthLabel() {
		return linkRollOverPriceMonthLabel;
	}

	public WebElement getRolloverIssueDate() {
		return RolloverIssueDate;
	}

	public WebElement getRolloverDate() {
		return RolloverDate;
	}

	public WebElement getRolloverFromMonth() {
		return RolloverFromMonth;
	}

	public WebElement getRolloverToMonth() {
		return RolloverToMonth;
	}

	public WebElement getQtytoRollOver() {
		return qtytoRollOver;
	}

	public WebElement getRolloverSpread() {
		return rolloverSpread;
	}

	public WebElement getPersonInCharge() {
		return personInCharge;
	}

	public WebElement getBtnRolloverSave() {
		return btnRolloverSave;
	}

	public WebElement getBtnRolloverCancel() {
		return btnRolloverCancel;
	}

	public WebElement getRolloverFilter() {
		return RolloverFilter;
	}

	public WebElement getRolloverReset() {
		return RolloverReset;
	}

	public WebElement getRolloverselectSearch() {
		return RolloverselectSearch;
	}

	public WebElement getRolloverSearchInput() {
		return rolloverSearchInput;
	}

	public WebElement getRolloverGo() {
		return rolloverGo;
	}

	public WebElement getRolloverrefno() {
		return Rolloverrefno;
	}


	

	
	

	
}
