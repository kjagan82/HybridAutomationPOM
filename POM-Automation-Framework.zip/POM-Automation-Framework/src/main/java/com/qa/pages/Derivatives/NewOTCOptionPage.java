/**
 * 
 */
package com.qa.pages.Derivatives;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;

/**
 * @author jaganmohan.k
 *
 */
public class NewOTCOptionPage {

	/*Option Contract Details*/
	@FindBy(xpath = "//input[contains(@id,'derivativeTradeDO_derivativeRefNo')]")
	@CacheLookup
	WebElement  tradeRefNo;
	
	@FindBy(xpath = "//input[contains(@name,'externalTradeRefNo')]")
	@CacheLookup
	WebElement externalTradeRefNo;

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement tradeDate; 
	
	@FindBy(id = "traderId")
	WebElement trader;
	
	@FindBy(xpath = "//div[contains(@class,'trigger x-form-arrow-trigger x-form-trigger-first')]")
	WebElement counterPartyArrow;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	WebElement counterPartyUL;
	
	@FindBy(xpath = "//*[@id='masterContractId']")
	WebElement masterContractId;
	
	@FindBy(id = "marketLocationCountry")
	WebElement marketLocationCountry;
	
	@FindBy(id = "marketLocationState")
	WebElement marketLocationState;
	
	@FindBy(id = "marketLocationCity")
	WebElement marketLocationCity;
	
	@FindBy(id = "productId")
	WebElement productId;
	
	@FindBy(id = "qualityId")
	WebElement qualityId;
	
	@FindBy(id = "exchangeInstrument")
	WebElement exchangeInstrument;
	
	@FindBy(id ="deliveryAutoPerType")
	WebElement promptDeliveryDetailsType;

	@FindBy(id = "deliveryManualPerName")
	WebElement promptDeliveryDetailsName;

	@FindBy(id = "tradeType")
	WebElement tradeType;
	
	@FindBy(xpath = "//input[contains(@type,'text') and contains(@name,'derivativeTradeDO.quantity')]")
	WebElement quantity;
	
	@FindBy(id = "quantityUnitId")
	WebElement quantityUnitId;
	
	@FindBy(id = "settlementCurrUnitId")
	WebElement settlementCurrency;
	
	@FindBy(xpath = "//input[contains(@type,'text') and contains(@name,'derivativeTradeDO.strikePrice')]")
	WebElement strikePrice;
	
	@FindBy(id = "strikePriceUnitId")
	WebElement strikePriceUnitId;
	
	@FindBy(id = "derivativeTradeDO.premiumDiscount")
	WebElement premiumDiscount;
	
	@FindBy(id = "premiumDiscountPriceUnitId")
	WebElement premiumDiscountPriceUnit;
	
	
	
	@FindBy(xpath = "//td[contains(text(),'Premium Due Date')]/following-sibling::td/div[contains(@id,'premiumDueDateDIVID')]/..//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement premiumDueDate; 

	@FindBy(xpath = "//td[contains(text(),'Expiry Date')]/following-sibling::td/div[contains(@id,'optionExpiryDateDIVID')]/..//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement expiryDate; 
	
	@FindBy(id = "paymentTerm")
	WebElement paymentTerms;
	
	@FindBy(xpath = "//td[contains(text(),'Payment Due Date')]/following-sibling::td/div[contains(@id,'paymentDueDateDIVID')]/..//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement paymentDueDate; 
	
	@FindBy(id = "brokerProfileId")
	WebElement broker;
	
	@FindBy(id = "brokerCommTypeId")
	WebElement brokerCommType;
	

	/*Internal Module*/
	@FindBy(id = "profitCenterId")
	WebElement profitCenterId;

	@FindBy(id = "strategyId")
	WebElement strategyId;
	
	@FindBy(id = "purposeId")
	WebElement purposeId;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	@CacheLookup
	WebElement selectnomineeUL; 
	
	@FindBy(xpath = "//td[contains(text(),' Nominee')]/following-sibling::td/div[contains(@id,'NomineeIdDiv')]/..//div[contains(@class,'x-form-arrow-trigger-over')]")
	WebElement nomineearrow;
	
	@FindBy(id = "create")
	WebElement createButton;

	@FindBy(xpath = "(//td[contains(text(),'Trade Ref. No.')]/following::td)[1]")
	WebElement createdTradeRefNo;

	@FindBy(xpath = "//input[@value='Ok' and @type='button']")
	WebElement ok_button;

	// Initializing the Page Objects:
	public NewOTCOptionPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	public String validateLoginPageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}

	/**
	 * @return the tradeRefNo
	 */
	public WebElement getTradeRefNo() {
		return tradeRefNo;
	}

	/**
	 * @return the externalTradeRefNo
	 */
	public WebElement getExternalTradeRefNo() {
		return externalTradeRefNo;
	}

	/**
	 * @return the tradeDate
	 */
	public WebElement getTradeDate() {
		return tradeDate;
	}

	/**
	 * @return the trader
	 */
	public WebElement getTrader() {
		return trader;
	}

	/**
	 * @return the counterPartyArrow
	 */
	public WebElement getCounterPartyArrow() {
		return counterPartyArrow;
	}

	/**
	 * @return the counterPartyUL
	 */
	public WebElement getCounterPartyUL() {
		return counterPartyUL;
	}

	/**
	 * @return the masterContractId
	 */
	public WebElement getMasterContractId() {
		return masterContractId;
	}

	/**
	 * @return the marketLocationCountry
	 */
	public WebElement getMarketLocationCountry() {
		return marketLocationCountry;
	}

	/**
	 * @return the marketLocationState
	 */
	public WebElement getMarketLocationState() {
		return marketLocationState;
	}

	/**
	 * @return the marketLocationCity
	 */
	public WebElement getMarketLocationCity() {
		return marketLocationCity;
	}

	/**
	 * @return the productId
	 */
	public WebElement getProductId() {
		return productId;
	}

	/**
	 * @return the qualityId
	 */
	public WebElement getQualityId() {
		return qualityId;
	}

	/**
	 * @return the exchangeInstrument
	 */
	public WebElement getExchangeInstrument() {
		return exchangeInstrument;
	}

	/**
	 * @return the promptDeliveryDetailsType
	 */
	public WebElement getPromptDeliveryDetailsType() {
		return promptDeliveryDetailsType;
	}

	/**
	 * @return the promptDeliveryDetailsName
	 */
	public WebElement getPromptDeliveryDetailsName() {
		return promptDeliveryDetailsName;
	}

	/**
	 * @return the tradeType
	 */
	public WebElement getTradeType() {
		return tradeType;
	}

	/**
	 * @return the quantity
	 */
	public WebElement getQuantity() {
		return quantity;
	}

	/**
	 * @return the quantityUnitId
	 */
	public WebElement getQuantityUnitId() {
		return quantityUnitId;
	}

	/**
	 * @return the settlementCurrency
	 */
	public WebElement getSettlementCurrency() {
		return settlementCurrency;
	}

	/**
	 * @return the strikePrice
	 */
	public WebElement getStrikePrice() {
		return strikePrice;
	}

	/**
	 * @return the strikePriceUnitId
	 */
	public WebElement getStrikePriceUnitId() {
		return strikePriceUnitId;
	}

	/**
	 * @return the premiumDiscount
	 */
	public WebElement getPremiumDiscount() {
		return premiumDiscount;
	}

	/**
	 * @return the premiumDiscountPriceUnit
	 */
	public WebElement getPremiumDiscountPriceUnit() {
		return premiumDiscountPriceUnit;
	}

	/**
	 * @return the premiumDueDate
	 */
	public WebElement getPremiumDueDate() {
		return premiumDueDate;
	}

	/**
	 * @return the expiryDate
	 */
	public WebElement getExpiryDate() {
		return expiryDate;
	}

	/**
	 * @return the paymentTerms
	 */
	public WebElement getPaymentTerms() {
		return paymentTerms;
	}

	/**
	 * @return the paymentDueDate
	 */
	public WebElement getPaymentDueDate() {
		return paymentDueDate;
	}

	/**
	 * @return the broker
	 */
	public WebElement getBroker() {
		return broker;
	}

	/**
	 * @return the brokerCommType
	 */
	public WebElement getBrokerCommType() {
		return brokerCommType;
	}

	/**
	 * @return the profitCenterId
	 */
	public WebElement getProfitCenterId() {
		return profitCenterId;
	}

	/**
	 * @return the strategyId
	 */
	public WebElement getStrategyId() {
		return strategyId;
	}

	/**
	 * @return the purposeId
	 */
	public WebElement getPurposeId() {
		return purposeId;
	}

	/**
	 * @return the selectnominee
	 */
	public WebElement getSelectnomineeUL() {
		return selectnomineeUL;
	}

	/**
	 * @return the nomineearrow
	 */
	public WebElement getNomineearrow() {
		return nomineearrow;
	}

	/**
	 * @return the createButton
	 */
	public WebElement getCreateButton() {
		return createButton;
	}

	/**
	 * @return the createdTradeRefNo
	 */
	public WebElement getCreatedTradeRefNo() {
		return createdTradeRefNo;
	}

	/**
	 * @return the ok_button
	 */
	public WebElement getOk_button() {
		return ok_button;
	}


}
