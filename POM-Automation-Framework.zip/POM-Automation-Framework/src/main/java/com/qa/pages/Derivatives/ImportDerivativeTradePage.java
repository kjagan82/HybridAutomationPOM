package com.qa.pages.Derivatives;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.qa.base.TestBaseListener;

public class ImportDerivativeTradePage {

	/*Under Derivatives-> Trades -> Futures -> List All*/

	
	@FindBy(xpath = "//span[text()='Operations']")
	@CacheLookup
	WebElement operations;

	@FindBy(xpath = "//span[text()='Import Derivative Trade']")
	@CacheLookup
	WebElement importDerivaticeTrade;
	
	
	@FindBy(xpath = "//input[@value='Get File Info']")
	@CacheLookup
	WebElement getFileInfo;

	@FindBy(xpath = "//input[@value='Generate Sample File']")
	WebElement generateSampleFile;

	@FindBy(xpath = "//input[contains(@id,'File')]")
	WebElement chooseFile;
	
	@FindBy(xpath = "//input[@value='Read File']")
	WebElement readFile;
	
	@FindBy(xpath = "//input[@value='Cancel']")
	WebElement cancel;
	
	@FindBy(xpath = "//input[contains(@type,'button') and contains(@value,'Ok')]")
	WebElement okBtn;
	
	@FindBy(xpath = "//input[@value='Import Valid Records']")
	WebElement importValidRecords;
	
	@FindBy(xpath = "//td[contains(text(),'Trade Ref. No')]/following::td[1]")
	WebElement tradeRefNo;
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement filter;
	
	@FindBy(xpath = "//span[text()='Reset']")
	WebElement reset;
	
	@FindBy(id = "futuretradeRefNo")
	WebElement searchTradeRefNo;
	
	@FindBy(xpath = "//span[text()='Go']")
	@CacheLookup
	WebElement go;
	
	
	



	public ImportDerivativeTradePage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	public String validateLoginPageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}

	public WebElement operations() {
		return operations;
	}
	
	public WebElement importDerivaticeTrade(){
		return importDerivaticeTrade;
	} 
	
	public WebElement getFileInfo(){
		return getFileInfo;
	} 
	
	public WebElement generateSampleFile(){
		return generateSampleFile;
	} 
	
	public WebElement chooseFile(){
		return chooseFile;
	} 

	public WebElement readFile(){
		return readFile;
	} 
	
	public WebElement cancel(){
		return cancel;
	} 
	
	public WebElement ok(){
		return okBtn;
	} 
	
	public WebElement importValidRecords(){
		return importValidRecords;
	}
	
	public WebElement tradeRefNo(){
			return tradeRefNo;
	}
	
	public WebElement filter(){
		return filter;
	}

	public WebElement reset(){
		return reset;	
	}
	
	public WebElement searchTradeRefNo(){
		return searchTradeRefNo;	
	}
	
	public WebElement go(){
		return go;	
	}
	
	
	
}

	