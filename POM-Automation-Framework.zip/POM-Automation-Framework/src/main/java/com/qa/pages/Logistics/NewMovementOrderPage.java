package com.qa.pages.Logistics;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;

public class NewMovementOrderPage {
	
    //new movement order page
	
	@FindBy(xpath = "//td[contains(text(),'Movement Against')]/following::td/div/img[contains(@id,'searchId')]")
	@CacheLookup
	WebElement movAgainstSearch;
	
	@FindBy(xpath = "//select[contains(@id,'movementAgainstdropdown')]")
	@CacheLookup
	WebElement movAgainstDropDown;
	
	
	//new window objects required to search callOff
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	@CacheLookup
	WebElement filter;
	
	
	@FindBy(xpath = "//select[contains(@id,'searchType')]")
	@CacheLookup
	WebElement newWinSearchSelect;
	
	@FindBy(xpath = "//input[contains(@name,'searchValue')]")
	@CacheLookup
	WebElement newWinSearchEnter;
	
	@FindBy(xpath = "//span[text()='Go']")
	@CacheLookup
	WebElement newWindowGo;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]")
	@CacheLookup
	WebElement newWindowCallOffCheckBox;
	
	@FindBy(xpath = "//input[contains(@value,'Ok')]")
	@CacheLookup
	WebElement newWindowCallOffOk;
	
	//new movement order page continue
	
	@FindBy(xpath = "//input[contains(@name,'salesCallOffRefNO')]/preceding-sibling::a")
	@CacheLookup
	WebElement calOffConfirmation;
	
	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement issueDate; 
	
	@FindBy(xpath = "//select[contains(@id,'transportModeId')]")
	@CacheLookup
	WebElement transportModeSelect; 
	
	//MOvement Schedule Details
	
	@FindBy(xpath = "(//td[contains(@id,'fromCityCombo')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement fromLocation; 
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	@CacheLookup
	WebElement fromLocationSelect; 
	

	@FindBy(xpath = "(//td[contains(@id,'toCityCombo')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement toLocation; 
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	@CacheLookup
	WebElement toLocationSelect; 
	
	@FindBy(xpath = "//input[contains(@id,'generateSchedule')]")
	@CacheLookup
	WebElement generateSchedule;
	
	@FindBy(xpath = "//input[contains(@name,'noOfDays')]")
	@CacheLookup
	WebElement scheduleNoDays;
	
	@FindBy(xpath = "//input[contains(@name,'noOfLoadsPerDay')]")
	@CacheLookup
	WebElement scheduleLoadsDays;
	
	@FindBy(xpath = "//select[contains(@id,'frequency')]")
	@CacheLookup
	WebElement frequency;
	
	@FindBy(xpath = "//span[contains(text(),'OK')]")
	@CacheLookup
	WebElement scheduleOK;
	
	@FindBy(xpath = "//input[@value='Save']")  
	@CacheLookup
	WebElement save;
	
	@FindBy(xpath = "//td[@class='footer']/input[@value='Save']")  
	@CacheLookup
	WebElement footerSave;
	
	
	// Add addition deductions //
	
	@FindBy(xpath = "//select[@id='contractItemId']")  
	@CacheLookup
	WebElement contractStorageItem;
	
	@FindBy(xpath = "(//td[contains(text(),'Add/Ded Name')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement addDeleteName;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	@CacheLookup
	WebElement addDeleteNameSelect;
	
	@FindBy(xpath = "//select[contains(@name,'addDedDTO.addDedType')]")
	@CacheLookup
	WebElement addDelete;
	
	@FindBy(xpath = "//select[contains(@name,'addDedDTO.rateType')]")
	@CacheLookup
	WebElement rateType;
	
	@FindBy(xpath = "(//td[contains(text(),'Rate')]/following::td/input[@name='addDedDTO.costValue'])")
	@CacheLookup
	WebElement rateEnter;
	
	@FindBy(xpath = "//select[contains(@name,'addDedDTO.costValueUnit')]")
	@CacheLookup
	WebElement rateSelect;
	
	@FindBy(xpath = "//select[contains(@id,'wtBasisTypeId')]")
	@CacheLookup
	WebElement weightBasis;
	
	@FindBy(xpath = "//textarea[contains(@name,'remarksId')]")
	@CacheLookup
	WebElement addRemarks;
	
	@FindBy(id = "addDedRow")
	@CacheLookup
	WebElement addDedRowButton;
	
	
	//Cost Estimate
	
	@FindBy(xpath = "(//td[contains(@id,'schecomboId~Cost_Estimate')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement schNoarrow;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	@CacheLookup
	WebElement schNoarrowSelect;
	
	@FindBy(xpath = "//select[contains(@id,'costComponentId~Cost_Estimate')]")
	@CacheLookup
	WebElement costCompName;
	
	@FindBy(xpath = "//select[contains(@id,'costIncExpId~Cost_Estimate')]")
	@CacheLookup
	WebElement incomeExpense;
	
	@FindBy(xpath = "//select[contains(@id,'rateTypeId~Cost_Estimate')]")
	@CacheLookup
	WebElement rateTypeCostEstimate;
	
	@FindBy(xpath = "(//td[contains(text(),'Cost Value')]/following::td/input[contains(@name,'costValue')])[1]")
	@CacheLookup
	WebElement costValueEnter;
	
	@FindBy(xpath = "(//td[contains(text(),'Cost Value')]/following::td/select[contains(@name,'costValue')])[1]")
	@CacheLookup
	WebElement costValueSelect;
	
	@FindBy(xpath = "//input[contains(@name,'fxToBase')]")
	@CacheLookup
	WebElement FXbase;
	
	@FindBy(xpath = "//td[contains(text(),'Cost Value')]/following::td/select[contains(@name,'weightBasis')]")
	@CacheLookup
	WebElement costApplicableOn;
	
	
	@FindBy(xpath = "//textarea[contains(@name,'comments')]")
	@CacheLookup
	WebElement costEstimateRemarks;
	
	@FindBy(xpath = "//input[contains(@id,'AddOnId')]")
	@CacheLookup
	WebElement addCostEstimate;
	
	@FindBy(xpath = "(//input[@value='Save'])[1]")
	@CacheLookup
	WebElement saveCostEstimate;
	
	@FindBy(xpath = "(//td[contains(text(),'Movement Order No')]/following::td)[1]")
	@CacheLookup
	WebElement movementOrderNo;
	
	@FindBy(xpath = "//input[contains(@value,'Ok')]")
	@CacheLookup
	WebElement movementOrderOk;
	
	@FindBy(xpath = "//select[contains(@id,'searchCriteria')or contains(@id,'gmrSearchCriteria')]")
	@CacheLookup
	WebElement listPafeFilterSearch;
	
	@FindBy(xpath = "//input[@name='searchTextBox']")
	@CacheLookup
	WebElement listPafeFilterSearchEnter;
	   
	@FindBy(xpath = "//span[text()='Go']")
	@CacheLookup
	WebElement moveOrderNoSearchGo;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[3]")
	@CacheLookup
	WebElement verifyMovOrderListAll;
	
	// Initializing the Page Objects:
	public NewMovementOrderPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}
	
	//Utilization
	public String validateLoginPageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}
	
	public WebElement movAgainstDropDown() {
		return movAgainstDropDown;
	}
	
	
	public WebElement getMovAgainstSearch() {
		return movAgainstSearch;
	}

	public WebElement getFilter() {
		return filter;
	}

	public WebElement getNewWinSearchSelect() {
		return newWinSearchSelect;
	}

	public WebElement getNewWinSearchEnter() {
		return newWinSearchEnter;
	}

	public WebElement getNewWindowGo() {
		return newWindowGo;
	}

	public WebElement getNewWindowCallOffCheckBox() {
		return newWindowCallOffCheckBox;
	}

	public WebElement getNewWindowCallOffOk() {
		return newWindowCallOffOk;
	}

	public WebElement getCalOffConfirmation() {
		return calOffConfirmation;
	}

	public WebElement getIssueDate() {
		return issueDate;
	}

	public WebElement getTransportModeSelect() {
		return transportModeSelect;
	}

	public WebElement getFromLocation() {
		return fromLocation;
	}

	public WebElement getFromLocationSelect() {
		return fromLocationSelect;
	}

	public WebElement getToLocation() {
		return toLocation;
	}

	public WebElement getToLocationSelect() {
		return toLocationSelect;
	}

	public WebElement getGenerateSchedule() {
		return generateSchedule;
	}

	public WebElement getScheduleNoDays() {
		return scheduleNoDays;
	}

	public WebElement getScheduleLoadsDays() {
		return scheduleLoadsDays;
	}

	public WebElement getFrequency() {
		return frequency;
	}

	public WebElement getScheduleOK() {
		return scheduleOK;
	}

	public WebElement getSave() {
		return save;
	}

	public WebElement getContractStorageItem() {
		return contractStorageItem;
	}

	public WebElement getAddDeleteName() {
		return addDeleteName;
	}

	public WebElement getAddDeleteNameSelect() {
		return addDeleteNameSelect;
	}

	public WebElement getAddDelete() {
		return addDelete;
	}

	public WebElement getRateType() {
		return rateType;
	}

	public WebElement getRateEnter() {
		return rateEnter;
	}

	public WebElement getRateSelect() {
		return rateSelect;
	}

	public WebElement getWeightBasis() {
		return weightBasis;
	}

	public WebElement getAddRemarks() {
		return addRemarks;
	}

	public WebElement getAddDedRowButton() {
		return addDedRowButton;
	}

	public WebElement getSchNoarrow() {
		return schNoarrow;
	}

	public WebElement getSchNoarrowSelect() {
		return schNoarrowSelect;
	}

	public WebElement getCostCompName() {
		return costCompName;
	}

	public WebElement getIncomeExpense() {
		return incomeExpense;
	}

	public WebElement getRateTypeCostEstimate() {
		return rateTypeCostEstimate;
	}

	public WebElement getCostValueEnter() {
		return costValueEnter;
	}

	public WebElement getCostValueSelect() {
		return costValueSelect;
	}

	public WebElement getFXbase() {
		return FXbase;
	}

	public WebElement getCostApplicableOn() {
		return costApplicableOn;
	}

	public WebElement getCostEstimateRemarks() {
		return costEstimateRemarks;
	}

	public WebElement getAddCostEstimate() {
		return addCostEstimate;
	}

	public WebElement getSaveCostEstimate() {
		return saveCostEstimate;
	}

	public WebElement getMovementOrderNo() {
		return movementOrderNo;
	} 
	
	public WebElement footerSave() {
		return footerSave;
	} 
	
	public WebElement movementOrderOk() {
		return movementOrderOk;
	} 
	
	public WebElement listPafeFilterSearch() {
		return listPafeFilterSearch;
	} 
	
	public WebElement listPafeFilterSearchEnter() {
		return listPafeFilterSearchEnter;
	} 
	
	public WebElement moveOrderNoSearchGo() {
		return moveOrderNoSearchGo;
	}

	public WebElement getVerifyMovOrderListAll() {
		return verifyMovOrderListAll;
	} 
	
	
	
	

}
