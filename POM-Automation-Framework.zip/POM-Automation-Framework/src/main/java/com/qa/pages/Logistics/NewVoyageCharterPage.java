package com.qa.pages.Logistics;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.qa.base.TestBaseListener;

public class NewVoyageCharterPage {

	/*Under Logistics button*/

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement activityDate;

	@FindBy(id = "voyageQtyUnitIdBulkVoyage")
	WebElement voyageQuantityUnit;

	@FindBy(id = "capacityBulkVoyage")
	WebElement capacityBookedTextField;

	@FindBy(name = "capacityQtyUnitId")
	WebElement capacityBookedSelect;

	@FindBy(xpath = "(//div[contains(@class,'trigger x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement loadingPort;

	@FindBy(xpath = "(//li[text()='Ama, United States Of America, Port'])[1]")
	WebElement loadingPortSelect;

	@FindBy(xpath = "(//div[contains(@class,'trigger x-form-arrow-trigger x-form-trigger-first')])[2]")
	WebElement dischargePort;

	@FindBy(xpath = "(//li[text()='Baltimore, United States Of America, Port'])[2]")
	WebElement dischargeSelect;

	@FindBy(xpath = "(//input[@value='Save'])")
	WebElement save;

	public NewVoyageCharterPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}


	public String validateLoginPageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}

	public WebElement voyageQuantityUnit(){
		//to perform Scroll on application using��Selenium
		((JavascriptExecutor)TestBaseListener.getDriver()).executeScript("arguments[0].scrollIntoView();", voyageQuantityUnit); 
		//JavascriptExecutor js = (JavascriptExecutor)TestBase.getDriver();
		//js.executeScript("window.scrollBy(0,document.body.scrollHeight)"); 
		return voyageQuantityUnit;
	} 
	public WebElement get(){
		return capacityBookedSelect;
	} 
	public void  capacityBookedTextField(String capacityInput){
		capacityBookedTextField.sendKeys(capacityInput);
	} 

	public WebElement capacityBookedSelect(){
		return capacityBookedSelect;
	} 

	public void loadingPort(){
		loadingPort.click();
	} 

	public void loadingPortSelect(){
		loadingPortSelect.click();
	} 

	public void dischargePort(){
		((JavascriptExecutor)TestBaseListener.getDriver()).executeScript("arguments[0].scrollIntoView();", dischargePort);
		//((JavascriptExecutor)TestBase.getDriver()).executeScript("arguments[0].click();", dischargePort); 
		dischargePort.click();
	} 

	public void dischargeSelect(){
		dischargeSelect.click();
	} 

	public void save(){
		save.click();
	} 

	public void selectDropDownByIndex(WebElement element,Integer index){
		Select dropdown= new Select(element);
		dropdown.selectByIndex(index);
	} 
	public void selectDropDownByText(WebElement element,String text){
		Select dropdown= new Select(element);
		dropdown.selectByVisibleText(text);
	} 



	public void selectDateFromDatePicker(String text){
		activityDate.click();
		List<WebElement> allDates=TestBaseListener.getDriver().findElements(By.xpath("//table[@class='x-datepicker-inner']//td"));
		for(WebElement ele:allDates){
			String date=ele.getText();
			if(date.equalsIgnoreCase(text))	{
				ele.click();
				break;
			}
		}
		activityDate.click();
	} 
}
