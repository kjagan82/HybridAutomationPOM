package com.qa.pages.Logistics;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.qa.base.TestBaseListener;

public class TicketImportPage {

	/*Under Logistics-> Tickets -> Inbound/ Outbound -> Ticket Import button*/

	@FindBy(xpath = "//input[@value='Get File Info']")
	@CacheLookup
	WebElement getFileInfo;

	@FindBy(xpath = "//input[@value='Generate Sample File']")
	WebElement generateSampleFile;

	@FindBy(xpath = "//input[contains(@id,'File')]")
	WebElement chooseFile;
	
	@FindBy(xpath = "//input[@value='Read File']")
	WebElement readFile;
	
	@FindBy(xpath = "//input[@value='Cancel']")
	WebElement cancel;
	
	@FindBy(xpath = "//input[contains(@type,'button') and contains(@value,'Ok')]")
	WebElement ok;
	
	@FindBy(xpath = "//input[@value='Import Valid Records']")
	WebElement importValidRecords;



	public TicketImportPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	public String validateLoginPageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}

	public void getFileInfo(){
		getFileInfo.click();
	} 
	
	public void generateSampleFile(){
		generateSampleFile.click();
	} 
	
	public WebElement chooseFile(){
		return chooseFile;
	} 

	public void readFile(){
		readFile.click();
	} 
	
	public void cancel(){
		cancel.click();
	} 
	
	public void ok(){
		ok.click();
	} 
	
	public void importValidRecords(){
		importValidRecords.click();
	} 
}

	