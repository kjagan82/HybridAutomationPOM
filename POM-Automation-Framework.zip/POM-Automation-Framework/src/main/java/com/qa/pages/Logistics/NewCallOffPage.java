package com.qa.pages.Logistics;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;
public class NewCallOffPage {

	//Search_Contract//

	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement searchFilter;
 
	@FindBy(xpath = "//select[contains(@id,'searchCriteria')]")
	 
	WebElement searchCriteria;

	@FindBy(xpath = "//input[contains(@id,'contractRefNo')]")
	 
	WebElement searchText;

	@FindBy(xpath = "//span[contains(text(),'Go')]")
	WebElement buttonGo;

	@FindBy(xpath = "//span[contains(text(),'Reset')]")
	WebElement buttonReset;

	@FindBy(xpath = "(//span[contains(@class,'x-column-header-text')])[1]")
	WebElement checkAll;

	//PurchaseCalloff//

	@FindBy(xpath = "//span[contains(text(),'Purchase Operations')]")
	WebElement buttonPurchaseOperation;

	@FindBy(xpath = "(//span[contains(text(),'Call Off')])[1]")
	WebElement linkPurchaseCallOff;

	//SalesCalloff//

	@FindBy(xpath = "//span[contains(text(),'Sales Operations')]")
	WebElement buttonSalesOperation;

	@FindBy(xpath = "(//span[contains(text(),'Call Off')])[1]")
	WebElement linkSalesCallOff;


	//Details//

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	WebElement contractIssueDate;

	@FindBy(xpath = "//input[contains(@id,'externalRefNo')]")
	WebElement externalcalloffRefNo;	

	@FindBy(xpath = "//select[contains(@id,'callOffType_ID')]")
	WebElement calloffType;

	@FindBy(xpath = "//select[contains(@id,'calledOffBy')]")
	WebElement calloffBy;

	@FindBy(xpath = "//select[contains(@id,'personInCharge')]")
	WebElement personIncharge;

	@FindBy(xpath = "//select[contains(@id,'secondInCharge')]")
	WebElement secondIncharge;

	//Product Details//

	@FindBy(xpath = "(//td[contains(@id,'qualityComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement qualityProductDetails;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	WebElement qualityProductDetailsSelect;

	@FindBy(xpath = "//select[contains(@id,'brandId')]")
	WebElement brand;

	@FindBy(xpath = "(//td[contains(@role,'presentation')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[6]")
	WebElement productionFacility;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	 
	WebElement productionFacilitySelect;

	@FindBy(xpath = "//select[contains(@id,'packingTypeId')]")
	WebElement packingType;

	@FindBy(xpath = "//select[contains(@id,'packingSizeId')]")
	WebElement packingSize;

	@FindBy(xpath = "//input[contains(@id,'callOffQuantity')]")
	WebElement calloffQty;

	//Transport Details//

	@FindBy(xpath = "//select[contains(@id,'transportMode')]")
	WebElement transportMode;

	@FindBy(xpath = "//input[contains(@id,'loadRefNo')]")
	WebElement unloadrefno;

	@FindBy(xpath = "//select[contains(@id,'transportCompany')]")
	WebElement transportCompany;

	@FindBy(xpath = "//select[contains(@id,'transportAgentId')]")
	 
	WebElement transportAgent;

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[2]")
	WebElement dropOffDateFrom;

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[3]")
	WebElement dropOffDateTo;

	@FindBy(xpath = "//input[contains(@id,'pickDropTime')]")
	WebElement dropoffTime;

	@FindBy(xpath = "(//td[contains(@role,'presentation')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[7]")
	WebElement expectedPickUpLocation;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	WebElement expectedPickUpLocationSelect;

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[4]")
	WebElement expectedPickUpDate;

	@FindBy(xpath = "(//td[contains(@role,'presentation')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[8]")
	WebElement location;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[3])")
	WebElement locationSelect;

	@FindBy(xpath = "//textarea[contains(@name,'address')]")
	WebElement address;

	@FindBy(xpath = "//textarea[contains(@name,'remarks')]")
	WebElement remarks;

	@FindBy(xpath = "//input[@id='saveButton']")
	WebElement saveButton;

	@FindBy(xpath = "//input[@value='Cancel']")
	WebElement cancelButton;

	//contract application//


	@FindBy(xpath = "(//th[contains(text(),'Ref No')]/../following::tr//td)[1]")  
	WebElement callOffRefNo;

	@FindBy(xpath = "(//tbody/tr//td/div[contains(@unselectable,'on')])[14]")
	WebElement newQuantity;

	@FindBy(xpath = "//input[contains(@name,'newQuantity')]")
	WebElement newQuantityEntry;

	@FindBy(xpath = "//input[@id='saveConApp']")
	WebElement saveConApp;

	@FindBy(xpath = "//input[@value='Cancel']")
	WebElement cancelConApp;

	//View//

	@FindBy(xpath = "//input[@id='viewBackButtonId']")
	WebElement backview;
	
	//Filtercontractinlistofcalloff//
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement searchFilterLOCO;
	
	@FindBy(xpath = "//select[contains(@id,'searchType')]")
	WebElement searchTypeLOCO;

	@FindBy(xpath = "//input[contains(@id,'searchValue')]")
	WebElement searchTextLOCO;

	@FindBy(xpath = "//span[contains(text(),'Go')]")
	WebElement buttonGoLOCO;

	@FindBy(xpath = "//span[contains(text(),'Reset')]")
	WebElement buttonResetLOCO;

	@FindBy(xpath = "(//span[contains(@class,'x-column-header-text')])[1]")
	WebElement CheckAllLOCO;
	
	@FindBy(xpath = "//span[contains(text(),'Operations')]")
	WebElement OperationsLOCO;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[4]")
	WebElement celllinkCalloffrefno;
	
	@FindBy(xpath = "//span[contains(text(),'Schedule')]")
	WebElement Schedule;
	
	@FindBy(xpath = "//input[@id='matchCallOffbtn']")
	WebElement matchCallOffbtn;
	
	//MatchCallOff//
	
	@FindBy(xpath = "//input[@id='activityDate']")
	WebElement allocationDate;
	

	@FindBy(xpath = "//input[@name='salesCallOffRefNo']")
	WebElement typeSalesCalloff;
	
	@FindBy(xpath = "(//img[@id='searchId'])[2]")
	WebElement SalesCalloffGo;
	
	@FindBy(xpath = "//select[@name='sourceTypeId']")
	 
	WebElement selectSource;
	
	@FindBy(xpath = "//input[@name='sourceTypeValue']")
	WebElement typeSource;
	
	@FindBy(xpath = "(//img[@id='searchId'])[4]")
	WebElement SourceGo;
	
	@FindBy(xpath = "//input[@name='quanityToAllocate']")
	WebElement quanityToAllocate;

	@FindBy(xpath = "//input[@value='Add']")
	WebElement addAllocation;
	
	@FindBy(xpath = "//input[@value='Remove']")
	WebElement removeAllocation;
	
	@FindBy(xpath = "(//input[contains(@id,'inputStockQty')])[1]")
	 WebElement qtyToAllocate1InTable;
	
	@FindBy(xpath = "(//input[contains(@id,'inputStockQty')])[2]")
	 WebElement qtyToAllocate2InTable;
	
	@FindBy(xpath = "(//input[contains(@id,'inputStockQty')])[3]")
	 WebElement qtyToAllocate3InTable;
	
	@FindBy(xpath = "//input[contains(@value,'Save')]")
	 WebElement allocationBtnSave;
	
	@FindBy(xpath = "//input[contains(@value,'Cancel')]")
	 WebElement allocationBtnCancel;
	
	@FindBy(xpath = "//input[contains(@value,'Ok')]")
	 WebElement allocationBtnOk;
	
	//ListofMatchcalloff//
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement searchFilterLOMC;
	
	@FindBy(xpath = "//select[contains(@id,'searchType')]")
	 WebElement searchTypeLOMC;

	@FindBy(xpath = "//input[contains(@id,'searchValue')]")
	 WebElement searchTextLOMC;

	@FindBy(xpath = "//span[contains(text(),'Go')]")
	WebElement buttonGoLOMC;

	@FindBy(xpath = "//span[contains(text(),'Reset')]")
	WebElement buttonResetLOMC;

	@FindBy(xpath = "(//span[contains(@class,'x-column-header-text')])[1]")
	WebElement checkAllLOMC;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[1]")
	WebElement allocationrefno;
	
	//CallOffOutputDoc//
	
	@FindBy(xpath = "//span[contains(text(),'Documents')]")
	WebElement linkDocument;
	
	@FindBy(xpath = "//input[contains(@value,'Generate & Print')]")
	WebElement btnGenerateandPrint;	
	
	// Initializing the Page Objects:

	public NewCallOffPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}


	public WebElement getSearchFilter() {
		return searchFilter;
	}


	public WebElement getSearchCriteria() {
		return searchCriteria;
	}


	public WebElement getSearchText() {
		return searchText;
	}


	public WebElement getButtonGo() {
		return buttonGo;
	}


	public WebElement getButtonReset() {
		return buttonReset;
	}


	public WebElement getCheckAll() {
		return checkAll;
	}


	public WebElement getButtonPurchaseOperation() {
		return buttonPurchaseOperation;
	}


	public WebElement getLinkPurchaseCallOff() {
		return linkPurchaseCallOff;
	}


	public WebElement getButtonSalesOperation() {
		return buttonSalesOperation;
	}


	public WebElement getLinkSalesCallOff() {
		return linkSalesCallOff;
	}


	public WebElement getContractIssueDate() {
		return contractIssueDate;
	}


	public WebElement getExternalcalloffRefNo() {
		return externalcalloffRefNo;
	}


	public WebElement getCalloffType() {
		return calloffType;
	}


	public WebElement getCalloffBy() {
		return calloffBy;
	}


	public WebElement getPersonIncharge() {
		return personIncharge;
	}


	public WebElement getSecondIncharge() {
		return secondIncharge;
	}


	public WebElement getQualityProductDetails() {
		return qualityProductDetails;
	}


	public WebElement getQualityProductDetailsSelect() {
		return qualityProductDetailsSelect;
	}


	public WebElement getBrand() {
		return brand;
	}


	public WebElement getProductionFacility() {
		return productionFacility;
	}


	public WebElement getProductionFacilitySelect() {
		return productionFacilitySelect;
	}


	public WebElement getPackingType() {
		return packingType;
	}


	public WebElement getPackingSize() {
		return packingSize;
	}


	public WebElement getCalloffQty() {
		return calloffQty;
	}


	public WebElement getTransportMode() {
		return transportMode;
	}


	public WebElement getUnloadrefno() {
		return unloadrefno;
	}


	public WebElement getTransportCompany() {
		return transportCompany;
	}


	public WebElement getTransportAgent() {
		return transportAgent;
	}


	public WebElement getDropOffDateFrom() {
		return dropOffDateFrom;
	}


	public WebElement getDropOffDateTo() {
		return dropOffDateTo;
	}


	public WebElement getDropoffTime() {
		return dropoffTime;
	}


	public WebElement getExpectedPickUpLocation() {
		return expectedPickUpLocation;
	}


	public WebElement getExpectedPickUpLocationSelect() {
		return expectedPickUpLocationSelect;
	}


	public WebElement getExpectedPickUpDate() {
		return expectedPickUpDate;
	}


	public WebElement getLocation() {
		return location;
	}


	public WebElement getLocationSelect() {
		return locationSelect;
	}


	public WebElement getAddress() {
		return address;
	}


	public WebElement getRemarks() {
		return remarks;
	}


	public WebElement getSaveButton() {
		return saveButton;
	}


	public WebElement getCancelButton() {
		return cancelButton;
	}


	public WebElement getCallOffRefNo() {
		return callOffRefNo;
	}


	public WebElement getNewQuantity() {
		return newQuantity;
	}


	public WebElement getNewQuantityEntry() {
		return newQuantityEntry;
	}


	public WebElement getSaveConApp() {
		return saveConApp;
	}


	public WebElement getCancelConApp() {
		return cancelConApp;
	}


	public WebElement getBackview() {
		return backview;
	}


	public WebElement getCelllinkCalloffrefno() {
		return celllinkCalloffrefno;
	}


	public WebElement getSchedule() {
		return Schedule;
	}


	public WebElement getMatchCallOffbtn() {
		return matchCallOffbtn;
	}


	public WebElement getAllocationDate() {
		return allocationDate;
	}


	public WebElement getTypeSalesCalloff() {
		return typeSalesCalloff;
	}


	public WebElement getSelectSource() {
		return selectSource;
	}


	public WebElement getTypeSource() {
		return typeSource;
	}


	public WebElement getQuanityToAllocate() {
		return quanityToAllocate;
	}


	public WebElement getAddAllocation() {
		return addAllocation;
	}


	public WebElement getRemoveAllocation() {
		return removeAllocation;
	}

	public WebElement getAllocationBtnSave() {
		return allocationBtnSave;
	}


	public WebElement getAllocationBtnCancel() {
		return allocationBtnCancel;
	}


	public WebElement getAllocationBtnOk() {
		return allocationBtnOk;
	}


	public WebElement getSearchFilterLOMC() {
		return searchFilterLOMC;
	}


	public WebElement getSearchTypeLOMC() {
		return searchTypeLOMC;
	}


	public WebElement getSearchTextLOMC() {
		return searchTextLOMC;
	}


	public WebElement getButtonGoLOMC() {
		return buttonGoLOMC;
	}


	public WebElement getButtonResetLOMC() {
		return buttonResetLOMC;
	}


	public WebElement getCheckAllLOMC() {
		return checkAllLOMC;
	}


	public WebElement getallocationrefno() {
		return allocationrefno;
	}


	public WebElement getSalesCalloffGo() {
		return SalesCalloffGo;
	}


	public WebElement getSourceGo() {
		return SourceGo;
	}


	public WebElement getQtyToAllocate1InTable() {
		return qtyToAllocate1InTable;
	}


	public WebElement getQtyToAllocate2InTable() {
		return qtyToAllocate2InTable;
	}


	public WebElement getQtyToAllocate3InTable() {
		return qtyToAllocate3InTable;
	} 


	public WebElement getSearchFilterLOCO() {
		return searchFilterLOCO;
	}


	public WebElement getSearchTypeLOCO() {
		return searchTypeLOCO;
	}


	public WebElement getSearchTextLOCO() {
		return searchTextLOCO;
	}


	public WebElement getButtonGoLOCO() {
		return buttonGoLOCO;
	}


	public WebElement getButtonResetLOCO() {
		return buttonResetLOCO;
	}


	public WebElement getCheckAllLOCO() {
		return CheckAllLOCO;
	}


	public WebElement getOperationsLOCO() {
		return OperationsLOCO;
	}


	public WebElement getAllocationrefno() {
		return allocationrefno;
	}


	public WebElement getLinkDocument() {
		return linkDocument;
	}


	public WebElement getBtnGenerateandPrint() {
		return btnGenerateandPrint;
	}




}










