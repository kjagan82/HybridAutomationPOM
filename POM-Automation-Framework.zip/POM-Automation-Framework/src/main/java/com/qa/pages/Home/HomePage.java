package com.qa.pages.Home;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;


public class HomePage  {


	@FindBy(xpath = "//span[contains(text(),'Eka Admin')]")
	@CacheLookup
	WebElement userNameLabel;

	@FindBy(xpath = "//span[contains(@class,'etup-menu-icons homeIcon')]")
	@CacheLookup
	WebElement homeButton;

	//Derivatives
	@FindBy(xpath = "//span[contains(text(),'Derivatives')]/following::span[1]")
	WebElement derivativesLabel;

	@FindBy(xpath = "//span[contains(text(),'Trades')]")
	WebElement tradesLabel;

	@FindBy(xpath = "//span[(text()='Settlements')]")
	WebElement settlementsLabel;

	@FindBy(xpath = "//span[contains(text(),'FX Trades')]")
	WebElement fxTradesLabel;

	@FindBy(xpath = "//span[(text()='Pricing Process')]")
	WebElement pricingProcessLabel;

	@FindBy(xpath = "//span[(text()='Pricing Process List')]")
	WebElement pricingProcessListLabel;

	@FindBy(xpath = "//span[contains(text(),'Futures')]")
	WebElement futuresLabel;

	@FindBy(xpath = "//span[contains(text(),'New Future')]")
	WebElement newFutureLabel;

	@FindBy(xpath = "//span[contains(text(),'FX Forward')]")
	WebElement fxForwardLabel;

	@FindBy(xpath = "//span[contains(text(),'New FX Trade')]")
	WebElement newFxTradesLabel;

	@FindBy(xpath = "//span[(text()='OTC Options')]")
	WebElement OtcOptionsLabel;

	@FindBy(xpath = "//span[contains(text(),'New OTC Option')]")
	WebElement newOtcOptionLabel;

	@FindBy(xpath = "//span[(text()='Exchange Options')]")
	WebElement exchangeOptionsLabel;

	@FindBy(xpath = "//span[(text()='New Exchange Option')]")
	WebElement newExchangeLabel;

	@FindBy(xpath = "//span[contains(text(),'List All')]")
	WebElement listAll;

	//Logistics
	@FindBy(xpath = "//span[contains(text(),'Logistics')]/following::span[1]")
	WebElement logisticsLabel;

	@FindBy(xpath = "//span[contains(text(),'Accounting')]/following::span[1]")
	WebElement accountingLabel;

	@FindBy(xpath = "//span[contains(text(),'Planning')]")
	WebElement planningLabel;

	@FindBy(xpath = "//span[contains(text(),'Ocean Transport Booking')]")
	WebElement oceanTransportBookingLabel;

	@FindBy(xpath = "//span[contains(text(),'Voyage Booking')]")
	WebElement voyageBookingLabel;

	@FindBy(xpath = "//span[contains(text(),' New Voyage Charter')]")
	WebElement newVoyageCharterLabel;

	@FindBy(xpath = "//span[contains(text(),'Physicals')]/following::span[1]")
	WebElement physicalsLabel;

	@FindBy(xpath = "//span[contains(text(),'Contracts')]")
	WebElement contractLabel;
	
	@FindBy(xpath = "//span[contains(text(),'Contract Drafts')]")
	WebElement contractDraftsLabel;
	
	@FindBy(xpath = "//span[contains(text(),'Contract Templates')]")
	WebElement contractTemplatesLabel;
	
	@FindBy(xpath = "//span[contains(text(),'All Movements')]")
	WebElement allMovementsLabel;
	
	@FindBy(xpath = "//span[contains(text(),'Printable Templates')]")
	WebElement printableTemplateLabel;
	
	@FindBy(xpath = "(//span[(text()='Contract Templates')]/ancestor::div/following::div//span[(text()='New')])[1]")
	WebElement NewcontractTemplatesLabel;
	
	@FindBy(xpath = "(//span[(text()='Printable Templates')]/ancestor::div/following::div//span[text()='New Purchase'])[1]")
	WebElement NewPurchasePrintTemplatesLabel;
	
	@FindBy(xpath = "(//span[(text()='Printable Templates')]/ancestor::div/following::div//span[text()='New Sales'])[1]")
	WebElement NewSalePrintTemplatesLabel;
	
	@FindBy(xpath = "(//span[(text()='All Movements')]/ancestor::div/following::div//span[(text()='List All')])[1]")
	WebElement listAllMovements;
	
	@FindBy(xpath = "(//span[(text()='Printable Templates')]/ancestor::div/following::div//span[(text()='List All')])[1]")
	WebElement listAllPrintableTemplates;
	
	@FindBy(xpath = "//span[contains(text(),'Contracts')][1]")
	WebElement logisticContractLabel;

	@FindBy(xpath = "//span[contains(text(),'New Purchase')]")
	WebElement newPurchaseLabel;

	@FindBy(xpath = "//span[contains(text(),'New Sales')]")
	WebElement newSaleLabel;

	@FindBy(xpath = "//span[contains(text(),'Land Transport Booking')]")
	WebElement landTransportBookingLabel;

	@FindBy(xpath = "//span[contains(text(),'Create Sales Movement Order')]")
	WebElement createSalesMovementOrderLabel;

	@FindBy(xpath = "//span[contains(text(),'Create Purchase Movement Order')]")
	WebElement createPurchaseMovementOrderLabel;

	@FindBy(xpath = "//span[contains(text(),'Create Internal Movement Order')]")
	WebElement createInternalMovementOrderLabel;

	@FindBy(xpath = "//span[contains(text(),'Planned Container Shipment')]")
	WebElement plannedContainerShipmentLabel;

	@FindBy(xpath = "(//div//span[contains(text(),'Planned Container Shipment')]/following::div//span[contains(text(),'New')])[1]")
	WebElement newPlannedContainerShipmentLabel;

	@FindBy(xpath = "//span[contains(text(),'Tickets')]")
	WebElement tickets;

	@FindBy(xpath = "//span[contains(text(),'Inbound/Outbound')]")
	WebElement inboundOutbound;

	@FindBy(xpath = "//span[contains(text(),'Ticket Import')]")
	WebElement ticketImport;

	@FindBy(xpath = "//span[contains(text(),'Open Contract Items')]")
	WebElement openContractItemLabel;

	@FindBy(xpath = "//span[contains(text(),'Secondary Costs')]")
	WebElement secondaryCostsLabel;

	@FindBy(xpath = "//span[contains(text(),'Accrual vs actual')]")
	WebElement accrualsecondaryCostsLabel;

	@FindBy(xpath = "//span[contains(text(),'Monthly Costs')]")
	WebElement monthlyCostsLabel;

	@FindBy(xpath = "//span[contains(text(),'Service Invoice General - Received')]")
	WebElement serviceInvReceivedLabel;

	@FindBy(xpath = "//span[contains(text(),'Service Invoice General - Raised')]")
	WebElement serviceInvRaisedLabel;

	@FindBy(xpath = "//span[contains(text(),'Invoicable Items')]")
	WebElement InvoicableItemsLabel;

	@FindBy(xpath = "//span[contains(text(),'Contract Items')]")
	WebElement contractItemsLabel;

	@FindBy(xpath = "//span[(text()='Call Off')]")
	WebElement callOffLabel;

	// Initializing the Page Objects:
	public HomePage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	public String verifyHomePageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}


	public boolean verifyCorrectUserName(String UserName){
		return userNameLabel.getText().contains(UserName);
	}

	public void clickOnDerivatives(){
		//clickUsingJavascript(derivativesLabel);
		derivativesLabel.click();

	}


	/**
	 * @return the userNameLabel
	 */
	public WebElement getUserNameLabel() {
		return userNameLabel;
	}

	/**
	 * @return the derivativesLabel
	 */
	public WebElement getDerivativesLabel() {
		return derivativesLabel;
	}

	/**
	 * @return the tradesLabel
	 */
	public WebElement getTradesLabel() {
		return tradesLabel;
	}

	/**
	 * @return the settlementsLabel
	 */
	public WebElement getSettlementsLabel() {
		return settlementsLabel;
	}

	/**
	 * @return the fxTradesLabel
	 */
	public WebElement getFxTradesLabel() {
		return fxTradesLabel;
	}

	/**
	 * @return the pricingProcessLabel
	 */
	public WebElement getPricingProcessLabel() {
		return pricingProcessLabel;
	}

	/**
	 * @return the pricingProcessListLabel
	 */
	public WebElement getPricingProcessListLabel() {
		return pricingProcessListLabel;
	}

	/**
	 * @return the futuresLabel
	 */
	public WebElement getFuturesLabel() {
		return futuresLabel;
	}

	/**
	 * @return the newFutureLabel
	 */
	public WebElement getNewFutureLabel() {
		return newFutureLabel;
	}

	/**
	 * @return the fxForwardLabel
	 */
	public WebElement getFxForwardLabel() {
		return fxForwardLabel;
	}

	/**
	 * @return the newFxTradesLabel
	 */
	public WebElement getNewFxTradesLabel() {
		return newFxTradesLabel;
	}

	/**
	 * @return the otcOptionsLabel
	 */
	public WebElement getOtcOptionsLabel() {
		return OtcOptionsLabel;
	}

	/**
	 * @return the newOtcOptionLabel
	 */
	public WebElement getNewOtcOptionLabel() {
		return newOtcOptionLabel;
	}

	/**
	 * @return the exchangeOptionsLabel
	 */
	public WebElement getExchangeOptionsLabel() {
		return exchangeOptionsLabel;
	}

	/**
	 * @return the newExchangeLabel
	 */
	public WebElement getNewExchangeLabel() {
		return newExchangeLabel;
	}

	/**
	 * @return the listAll
	 */
	public WebElement getListAll() {
		return listAll;
	}

	/**
	 * @return the logisticsLabel
	 */
	public WebElement getLogisticsLabel() {
		return logisticsLabel;
	}

	/**
	 * @return the accountingLabel
	 */
	public WebElement getAccountingLabel() {
		return accountingLabel;
	}

	/**
	 * @return the planningLabel
	 */
	public WebElement getPlanningLabel() {
		return planningLabel;
	}

	/**
	 * @return the oceanTransportBookingLabel
	 */
	public WebElement getOceanTransportBookingLabel() {
		return oceanTransportBookingLabel;
	}

	/**
	 * @return the voyageBookingLabel
	 */
	public WebElement getVoyageBookingLabel() {
		return voyageBookingLabel;
	}

	/**
	 * @return the newVoyageCharterLabel
	 */
	public WebElement getNewVoyageCharterLabel() {
		return newVoyageCharterLabel;
	}

	/**
	 * @return the physicalsLabel
	 */
	public WebElement getPhysicalsLabel() {
		return physicalsLabel;
	}

	/**
	 * @return the contractLabel
	 */
	public WebElement getContractLabel() {
		return contractLabel;
	}

	/**
	 * @return the logisticContractLabel
	 */
	public WebElement getLogisticContractLabel() {
		return logisticContractLabel;
	}

	/**
	 * @return the newPurchaseLabel
	 */
	public WebElement getNewPurchaseLabel() {
		return newPurchaseLabel;
	}

	/**
	 * @return the newSaleLabel
	 */
	public WebElement getNewSaleLabel() {
		return newSaleLabel;
	}

	/**
	 * @return the landTransportBookingLabel
	 */
	public WebElement getLandTransportBookingLabel() {
		return landTransportBookingLabel;
	}

	/**
	 * @return the createSalesMovementOrderLabel
	 */
	public WebElement getCreateSalesMovementOrderLabel() {
		return createSalesMovementOrderLabel;
	}

	/**
	 * @return the createPurchaseMovementOrderLabel
	 */
	public WebElement getCreatePurchaseMovementOrderLabel() {
		return createPurchaseMovementOrderLabel;
	}

	/**
	 * @return the createInternalMovementOrderLabel
	 */
	public WebElement getCreateInternalMovementOrderLabel() {
		return createInternalMovementOrderLabel;
	}

	/**
	 * @return the plannedContainerShipmentLabel
	 */
	public WebElement getPlannedContainerShipmentLabel() {
		return plannedContainerShipmentLabel;
	}

	/**
	 * @return the newPlannedContainerShipmentLabel
	 */
	public WebElement getNewPlannedContainerShipmentLabel() {
		return newPlannedContainerShipmentLabel;
	}

	/**
	 * @return the tickets
	 */
	public WebElement getTickets() {
		return tickets;
	}

	/**
	 * @return the inboundOutbound
	 */
	public WebElement getInboundOutbound() {
		return inboundOutbound;
	}

	/**
	 * @return the ticketImport
	 */
	public WebElement getTicketImport() {
		return ticketImport;
	}

	/**
	 * @return the openContractItemLabel
	 */
	public WebElement getOpenContractItemLabel() {
		return openContractItemLabel;
	}

	/**
	 * @return the secondaryCostsLabel
	 */
	public WebElement getSecondaryCostsLabel() {
		return secondaryCostsLabel;
	}

	/**
	 * @return the accrualsecondaryCostsLabel
	 */
	public WebElement getAccrualsecondaryCostsLabel() {
		return accrualsecondaryCostsLabel;
	}

	/**
	 * @return the monthlyCostsLabel
	 */
	public WebElement getMonthlyCostsLabel() {
		return monthlyCostsLabel;
	}

	/**
	 * @return the serviceInvReceivedLabel
	 */
	public WebElement getServiceInvReceivedLabel() {
		return serviceInvReceivedLabel;
	}

	/**
	 * @return the serviceInvRaisedLabel
	 */
	public WebElement getServiceInvRaisedLabel() {
		return serviceInvRaisedLabel;
	}

	/**
	 * @return the invoicableItemsLabel
	 */
	public WebElement getInvoicableItemsLabel() {
		return InvoicableItemsLabel;
	}

	/**
	 * @return the contractItemsLabel
	 */
	public WebElement getContractItemsLabel() {
		return contractItemsLabel;
	}

	/**
	 * @return the homeButton
	 */
	public WebElement getHomeButton() {
		return homeButton;
	}

	public WebElement getContractDraftsLabel() {
		return contractDraftsLabel;
	}

	public WebElement getCallOffLabel() {
		return callOffLabel;
	}

	public WebElement getContractTemplatesLabel() {
		return contractTemplatesLabel;
	}

	public WebElement getNewcontractTemplatesLabel() {
		return NewcontractTemplatesLabel;
	}

	public WebElement getAllMovementsLabel() {
		return allMovementsLabel;
	}

	public WebElement getListAllMovements() {
		return listAllMovements;
	}

	public WebElement getPrintableTemplateLabel() {
		return printableTemplateLabel;
	}

	public WebElement getNewPurchasePrintTemplatesLabel() {
		return NewPurchasePrintTemplatesLabel;
	}

	public WebElement getListAllPrintableTemplates() {
		return listAllPrintableTemplates;
	}

	public WebElement getNewSalePrintTemplatesLabel() {
		return NewSalePrintTemplatesLabel;
	}
	

}
