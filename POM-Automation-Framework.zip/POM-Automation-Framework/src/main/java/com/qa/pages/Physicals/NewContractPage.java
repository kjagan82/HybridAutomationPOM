package com.qa.pages.Physicals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;
public class NewContractPage {
	/*Under purchase contract button*/

	//COntract Details//
	
	@FindBy(xpath = "//input[contains(@name,'templateName')]")
	WebElement templateName;

	@FindBy(xpath = "//select[contains(@id,'templateIntContractRefNO')]")
	WebElement selectTemplate;

	@FindBy(xpath = "(//tr//td[contains(text(),'Production Contract')]/following::td/input[@name='isProductionContract'])[1]")
	WebElement proContractCheckBox ; 

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	WebElement contractIssueDate ; 

	@FindBy(xpath = "//select[contains(@id,'traderUserId')]")
	WebElement traderName;

	@FindBy(xpath = "//select[contains(@id,'masterContractInternalContractRefNo')]")
	WebElement masterContract;

	@FindBy(xpath = "//select[contains(@id,'dealType')]")
	WebElement dealType;

	@FindBy(xpath = "(//td[contains(text(),'CP Name')]/following-sibling::td//span//table//td//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement cpName;

	@FindBy(xpath = "(//div[contains(@class,'x-boundlist x-boundlist-floating x-layer x-boundlist-default x-border-box')]//div//ul)[1]")
	WebElement cpNameSelect;

	@FindBy(xpath = "//select[contains(@id,'cpPersonInCharge')]")
	WebElement cpIncharge;

	@FindBy(xpath = "//select[contains(@id,'agentProfileId')]")
	WebElement brokerName;

	@FindBy(xpath = "//select[contains(@id,'agentPersonInCharge')]")
	WebElement brokerIncharge;

	@FindBy(xpath = "//input[contains(@id,'agentRefNo')]")
	WebElement brokerRefNo;

	@FindBy(xpath = "//input[contains(@id,'cpRefNo')]")
	WebElement cpContractRefNo;

	@FindBy(xpath = "//select[contains(@id,'termsConditionForm.incotermId')]")
	WebElement incoTerm;

	@FindBy(xpath = "//input[contains(@id,'agentCommValue')]")
	WebElement brokerComTextbox;

	@FindBy(xpath = "//select[contains(@id,'agentCommPriceUnitId')]")
	WebElement brokerComSelect;

	@FindBy(xpath = "//select[contains(@id,'termsConditionForm.paymentTermId')]")
	WebElement paymentTerms;

	@FindBy(xpath = "//select[contains(@id,'termsConditionForm.freightTermId')]")
	WebElement freightTerms;

	@FindBy(xpath = "//select[contains(@id,'contractQtyUnitId')]")
	WebElement contractqtyUnit;

	@FindBy(xpath = "//select[contains(@id,'ourPicGabId')]")
	WebElement operator;

	@FindBy(xpath = "//select[contains(@id,'personInchargeId')]")
	WebElement personInCharge;

	@FindBy(xpath = "//select[contains(@id,'secondPersonInchargeId')]")
	WebElement personSecondCharge;

	// Item Details //

	@FindBy(xpath = "(//td[contains(@id,'productComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement productDetailsProduct;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	WebElement productDetailsProductSelect;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	WebElement originSelect;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	WebElement cropYearSelect;

	@FindBy(xpath = "(//td[contains(@id,'originComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement originProductDetails;

	@FindBy(xpath = "(//td[contains(@id,'cropyearComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement cropYearProductDetails;

	@FindBy(xpath = "(//td[contains(@id,'qualityComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement qualityProductDetails;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[3])")
	WebElement qualityProductDetailsSelect;


	@FindBy(xpath = "//select[contains(@id,'profitCenterId')]")
	WebElement profitCenter;

	@FindBy(xpath = "//select[contains(@id,'strategyAccId')]")
	WebElement strategy;

	@FindBy(xpath = "//textarea[contains(@name,'qualityShortDesc')]")
	WebElement shortDescArea;

	@FindBy(xpath = "//textarea[contains(@name,'qualityLongDesc')]")
	WebElement longDescArea;

	// Quantity Details//

	@FindBy(xpath = "//td[contains(text(),'Item Quantity')]/following-sibling::td/input[contains(@name,'itemQty')]")
	WebElement itemQtyinput;

	@FindBy(xpath = "//td[contains(text(),'Contracted Area')]/following-sibling::td/input[contains(@name,'productSpecForm.areaQty')]")
	WebElement conAreainput;

	@FindBy(xpath = "//select[contains(@id,'areaQtyUnitId')]")
	WebElement conAreaSelect;

	@FindBy(xpath = "//td[contains(text(),'Expected Yield')]/following-sibling::td/input[contains(@name,'productSpecForm.expectedYield')]")
	WebElement expectedYieldInput;

	@FindBy(xpath = "//select[contains(@id,'itemQtyUnitId')]")
	WebElement itemQtySelect;

	@FindBy(xpath = "//select[contains(@id,'productSpecForm.packingSizeId')]/preceding::select[contains(@id,'packingTypeId')]")
	WebElement packingType;

	@FindBy(xpath = "//select[contains(@id,'productSpecForm.packingSizeId')]")
	WebElement packingSizeId;

	@FindBy(xpath = "//input[contains(@name,'toleranceMin')]")
	WebElement toleranceMinenter;

	@FindBy(xpath = "//input[contains(@name,'toleranceMax')]")
	WebElement toleranceMaxenter;

	@FindBy(xpath = "//select[contains(@id,'toleranceType')]")
	WebElement toleranceType;

	@FindBy(xpath = "//select[contains(@id,'toleranceLevel')]")
	WebElement toleranceLevel;

	@FindBy(xpath = "//textarea[contains(@name,'toleranceRemarks')]")
	WebElement toleranceRemarks;

	// Price Details //

	@FindBy(xpath = "//select[contains(@name,'payInCurId')]")
	WebElement qualityPDSchedule;

	@FindBy(xpath = "//select[contains(@name,'priceTypeId')]")
	WebElement priceType;

	@FindBy(xpath = "(//select[contains(@name,'productSpecForm.priceContractDefId')])[1]")
	WebElement futureInstrument;

	@FindBy(xpath = "(//input[contains(@name,'productSpecForm.futurePrice')])[1]")
	WebElement futurePrice;

	@FindBy(xpath = "(//input[contains(@name,'productSpecForm.fxInstToBasis')])")
	WebElement fxInstoBasis;

	@FindBy(xpath = "(//input[contains(@name,'productSpecForm.fxBasisToPayin')])")
	WebElement fxBasistoPay;


	@FindBy(xpath = "//select[contains(@name,'productSpecForm.multiPriceFutureContractId')]")
	WebElement priceMonth;

	@FindBy(xpath = "//select[contains(@name,'productSpecForm.multiPriceUnitId')]")
	WebElement basisSelect;

	@FindBy(xpath = "//input[contains(@name,'productSpecForm.multiPriceDf')]")
	WebElement basisEnter;

	@FindBy(xpath = "(//select[contains(@name,'productSpecForm.optionsToFix')])[1]")
	WebElement priceFixOption;

	@FindBy(xpath = "(//select[contains(@name,'productSpecForm.fixationMethod')])[1]")
	WebElement priceFixMethod;

	@FindBy(xpath = "(//div[contains(text(),'Contract Price')]/following::td/div/input[@id='productSpecForm.price'])")
	WebElement contractPriceEnter;

	@FindBy(xpath = "(//div[contains(text(),'Contract Price')]/following::td/div/select[contains(@id,'productSpecForm.priceUnitId')])[2]")
	WebElement contractPriceSelect;

	@FindBy(xpath = "(//div[contains(text(),'Contract Price')]/following::td/input[@id='productSpecForm.benchmarkPrice'])")
	WebElement benchPriceEnter;

	@FindBy(xpath = "//select[contains(@name,'benchmarkPriceUnitId')]")
	WebElement benchPriceSelect;

	@FindBy(xpath = "//textarea[contains(@name,'priceRemarksNew')]")
	WebElement priceRemarks;

	// Add addition deductions //

	@FindBy(xpath = "//select[contains(@name,'addDedDTO.addDedType')]")
	WebElement addDelete;

	@FindBy(xpath = "(//td[contains(text(),'Add/Ded Name')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement addDeleteName;

	@FindBy(xpath = "//select[contains(@name,'productSpecForm.addDedDTO.rateType')]")
	WebElement rateType;

	@FindBy(xpath = "(//td[contains(text(),'Rate')]/following::td/input[@name='productSpecForm.addDedDTO.costValue'])")
	WebElement rateEnter;

	@FindBy(xpath = "//select[contains(@name,'productSpecForm.addDedDTO.costValueUnit')]")
	WebElement rateSelect;

	@FindBy(xpath = "//select[contains(@name,'productSpecForm.addDedDTO.weightBasisId')]")
	WebElement weightBasis;

	@FindBy(xpath = "//textarea[contains(@name,'productSpecForm.remarksId')]")
	WebElement addRemarks;

	@FindBy(id = "addDedRow")
	WebElement addDedRowButton;

	//Delivery Period
	@FindBy(xpath = "(//td[contains(text(),'Shipment Period From')]/following-sibling::td//table//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	WebElement shippingPeriodFrom;

	@FindBy(xpath = "(//td[contains(text(),'Shipment Period To')]/following-sibling::td//table//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	WebElement shippingPeriodTo;

	// Payment Terms
	@FindBy(xpath = "(//td[contains(text(),'Payment Due Date')]/following-sibling::td//table//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	WebElement paymentDueDate;

	@FindBy(xpath = "//select[contains(@name,'productSpecForm.invDocPriceUnitId')]")
	WebElement invoiceDocPrice;

	@FindBy(xpath = "//input[@id='productSpecForm.unweighedPiPctValue']")
	WebElement proinvPercentageEnter;

	@FindBy(xpath = "//select[contains(@name,'productSpecForm.interestRateType')]")
	WebElement latePaymentInterestType;

	@FindBy(xpath = "//input[@id='productSpecForm.interestRate']")
	WebElement latePaymentInterestRate;

	@FindBy(xpath = "(//td[contains(text(),'Tax Schedule Applicable Country')]/following-sibling::td/select[contains(@name,'productSpecForm.taxScheduleCountryId')])[2]")
	WebElement taxScheduleApplicableCountry;

	@FindBy(xpath = "(//td[contains(text(),'Tax Schedule')]/following-sibling::td/select[contains(@name,'productSpecForm.taxScheduleId')])")
	WebElement taxSchedule;

	@FindBy(xpath = "(//td[contains(text(),'Tax Schedule Applicable States')]/following-sibling::td/select[contains(@name,'taxScheduleStateId')])")
	WebElement taxScheduleApplicableStates;



	// Item List

	@FindBy(xpath = "//input[@id='productSpecForm.addItem']")
	WebElement addItemButton;

	@FindBy(xpath = "//input[@id='productSpecForm.updateItem']")
	WebElement updateItemButton;

	//Terms & Conditions
	@FindBy(xpath = "//select[contains(@name,'termsConditionForm.applicableLawId')]")
	WebElement applicableLawContract;

	@FindBy(xpath = "//select[contains(@name,'termsConditionForm.arbitrationId')]")
	WebElement arbitration;

	@FindBy(xpath = "//select[contains(@name,'termsConditionForm.qualityFinalAt')]")
	WebElement qualityFinalAt;

	@FindBy(xpath = "//select[contains(@name,'termsConditionForm.weightFinalAt')]")
	WebElement weightFinaliziedAt;

	@FindBy(xpath = "//input[@value='Next' and contains(@name,'next') and @type='button']")
	WebElement nextButtonContract;

	@FindBy(xpath = "//input[@value='Create Template' and contains(@name,'next') and @type='button']")
	WebElement createTemplate;
	
	@FindBy(xpath = "//input[@value='Save As Draft' and contains(@name,'saveAsDraft') and @type='button']")
	WebElement saveDraftButtonContract;
	
	//delivery Details

	@FindBy(xpath = "//select[contains(@name,'productSpecForm.destinationLocationGroupTypeId')]")
	WebElement destLocationType;


	@FindBy(xpath = "(//td[contains(@id,'loadCountryComboIddestinationCountryIdHidden')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement dischargeCountry;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[4])")
	WebElement dischargeCountrySelect;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul))[5]")
	WebElement dischargePortSelect;

	@FindBy(xpath = "//input[contains(@id,'loadPortComboIddestinationPortIdHidden')]")
	WebElement dischargePortinput;

	@FindBy(xpath = "(//td[contains(@id,'loadPortComboIddestinationPortIdHidden')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement dischargePort;

	@FindBy(xpath = "//td[contains(text(),'Origin ')]")
	WebElement originLabelClick;

	@FindBy(xpath = "(//td[contains(text(),'Packing Type')])[1]")
	WebElement packingLabelClick;

	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement filter;

	@FindBy(xpath = "//td[text()='Contract Ref. No.']/following::td/input[@name='contractRefNo']")
	WebElement conRefNoSearch;
	
	@FindBy(xpath = "//td/input[@name='templateName']")
	WebElement templateSearchEnter;

	@FindBy(xpath = "//span[text()='Go']")
	WebElement conRefNoSearchGo;

	/////////////////////Cost Accrual --Gaurav/////////////


	@FindBy(xpath = "//select[contains(@id,'valuationIncoterm')]")
	WebElement valuationIncoTerm;

	@FindBy(xpath = "//select[contains(@id,'locGroup')]")
	WebElement valuationLocationTypeGroup;

	@FindBy(xpath = "(//td[contains(@id,'loadCountryComboIdvaluationCountryIdHidden')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement valuationLocationArrow;


	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	WebElement valuationLocationSelect;

	@FindBy(xpath = "//input[contains(@id,'loadPortComboIdvaluationPortIdHidden')]")
	WebElement valuationLocationCityEnter;


	@FindBy(xpath = "(//td[contains(@id,'loadPortComboIdvaluationPortIdHidden')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement valuationLocationCityArrow;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	WebElement valuationLocationCitySelect;

	@FindBy(xpath = "//select[contains(@id,'positionCurrency')]")
	WebElement positionCurrency;

	@FindBy(xpath = "//input[contains(@name,'listCost') and contains(@id,'fxPrice')]")
	WebElement fxPricetoPosition;

	@FindBy(xpath = "//select[@id='expectedLocGroupTypeID']")
	WebElement expectedDeliveryLocation;

	@FindBy(xpath = "//input[contains(@id,'loadCountryComboIdexpected')]")
	WebElement locationCountry;

	@FindBy(xpath = "//input[contains(@id,'loadPortComboIdexpected')]")
	WebElement locationCity;

	@FindBy(xpath = "//select[contains(@id,'contractItemGMRRef')]")
	WebElement itemRefNo;

	@FindBy(xpath = "//select[@id='costComponentId']")
	WebElement costComponentName;

	@FindBy(xpath = "//select[contains(@id,'costIncExp')]")
	WebElement incomeExpence;

	@FindBy(xpath = "//select[contains(@id,'estimateFor')]")
	WebElement estimateFor;

	@FindBy(xpath = "(//select[contains(@id,'rateType')])[1]")
	WebElement rateTypeValuation;

	@FindBy(xpath = "//input[contains(@id,'costValue')]")
	WebElement costValue;

	@FindBy(xpath = "//select[contains(@id,'costValueUnit')]")
	WebElement costValueUnit;

	@FindBy(xpath = "//input[contains(@name,'fxToBase')]")
	WebElement fxToBase;

	@FindBy(xpath = "//input[contains(@name,'costAmtInAccrCurr')]")
	WebElement costAmount;

	@FindBy(id = "fxPriceToPositionId")
	WebElement fxToPosition;

	@FindBy(xpath = "//textarea[@id='comments']") 
	WebElement comments;

	@FindBy(xpath = "//input[@value='Add']") 
	WebElement add;

	@FindBy(xpath = "//input[@value='Next' and @type='button']") 
	WebElement next;

	@FindBy(xpath = "//input[@value='Previous']") 
	WebElement previous;

	@FindBy(xpath = "//input[@value='Cancel' and @type='button'] ") 
	WebElement cancel;

	@FindBy(xpath = "//input[@id='saveDraftButton']") 
	WebElement saveAsDraft;

	@FindBy(xpath = "//select[contains(@name,'productSpecForm.expectedLocGroupTypeId')]")
	WebElement expectedDestLocationType;

	@FindBy(xpath = "(//td[contains(@id,'loadCountryComboIdexpectedCountryIdHidden')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement expectedDischargeCountry;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[3])")
	WebElement expectedDischargeCountrySelect;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[4])")
	WebElement expectedDischargePortSelect;

	@FindBy(xpath = "(//td[contains(@id,'loadPortComboIdexpectedLocCityIdHidden')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	WebElement expectedDischargePort;

	@FindBy(xpath = "//input[contains(@value,'OK')]")
	WebElement ok;

	@FindBy(xpath = "//input[contains(@value,'Create')]")
	WebElement create;

	@FindBy(xpath = "//input[@value='Save']")  
	WebElement save;

	@FindBy(xpath = "(//th[contains(text(),'Contract Ref. No.')]/../following::tr//td)[2]")  
	WebElement refNo;

	@FindBy(xpath = "(//th[contains(text(),'Draft Ref. No.')]/../following::tr//td)[2]")  
	WebElement DraftRefNo;
	
	@FindBy(xpath = "(//th[contains(text(),'Template Ref. No.')]/../following::tr//td)[1]")  
	WebElement TemplateRefNo;
	
	@FindBy(xpath = "//input[contains(@name,'approvalManagementDO')and @type='checkbox']")  
	WebElement approver;

	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[2]")  
	WebElement verifyContract;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[124]")  
	WebElement cancelContractStatus;
	

	/*Search COntracts*/
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement mainFilter;

	@FindBy(xpath = "//span[contains(text(),'Default')]")
	WebElement mainDefault;


	@FindBy(xpath = "//input[contains(@id,'contractRefNo') or contains(@id,'searchTextBox') or contains(@name,'referenceNo')]")
	WebElement filterSearchInput;

	@FindBy(xpath = "//select[contains(@id,'templateType')]")
	WebElement templateTypeSelect;
	
	@FindBy(xpath = "//span[text()='Go']")
	WebElement filterGo;

	@FindBy(xpath = "//span[text()='Reset']")
	WebElement filterReset;

	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]")
	WebElement contractCheckBox;

	/*Contract Listing Screens*/

	@FindBy(xpath = "//span[contains(text(),'Contract Operations')]")
	WebElement contractOperationsHeader;

	@FindBy(xpath = "//span[contains(text(),'New Purchase')]")
	WebElement newPurchaseContractOperations;

	@FindBy(xpath = "//span[contains(text(),'New Sales')]")
	WebElement newSaleContractOperations;
	
	@FindBy(xpath = "//span[contains(text(),'Cancel Contract')]")
	WebElement cancelContractOperations;
	
	@FindBy(xpath = "//textarea[contains(@name,'reasonToCancel')]")
	WebElement cancelReasonContract;
	
	@FindBy(xpath = "//input[contains(@value,'OK')]")
	WebElement OKcancelContract;
	

	/*Amend Contract*/

	@FindBy(xpath = "//span[contains(text(),'Amend Contract')]")
	WebElement amendContractContractOperations;

	@FindBy(xpath = "//textarea[contains(@name,'reasonForAmendment')]")
	WebElement reasonForAmend;

	@FindBy(xpath = "//input[contains(@name,'selectedItems') and @type='checkbox']")
	WebElement firstRowCheckboxAddItem;

	@FindBy(xpath = "//input[contains(@value,'Copy Item') and @type='button']")
	WebElement copyItem;

	@FindBy(xpath = "//input[contains(@name,'modify') and @type='button']")
	WebElement modifyItem;

	@FindBy(xpath = "//input[contains(@value,'Copy Item') and @type='button']/following::input[1][contains(@name,'remove')]")
	WebElement removeItem;

	@FindBy(xpath = "//input[contains(@name,'ModifyContract') and contains(@value,'Amend & Approve Contract')]")
	WebElement amendCreateContract;

	@FindBy(xpath = "//input[contains(@name,'ModifyContract') and contains(@value,'Modify')]")
	WebElement modifyContractButton;

	/*Modify Contract*/

	@FindBy(xpath = "//span[contains(text(),'Modify Contract')]")
	WebElement modifyContractOperations;
	
	/*Draft filter*/
	
	@FindBy(xpath = "//select[@id='draftcontractType' and contains(@name,'contractType')]")
	WebElement draftFilterSelect;
	
	@FindBy(xpath = "//input[contains(@name,'filterDraftTemplateNo')]")
	WebElement draftFilterEnter;
	
	/*COntract Output Document*/
	
	@FindBy(xpath = "//span[contains(text(),'Activity')]")
	WebElement activityTabOutputDoc;
	
	@FindBy(xpath = "//a[contains(text(),'Generate Document')]")
	WebElement generateDocumentLink;
	
	@FindBy(xpath = "//td[contains(text(),'Generate contract from an existing')]/preceding::td/input[contains(@name,'selectType')]")
	WebElement generateDocExistingRadioBtn;
		
	@FindBy(xpath = "//input[contains(@name,'nextButton')]")
	WebElement newWinOutputNextBtn;
	
	@FindBy(xpath = "//span[contains(text(),'Default')]")
	WebElement defaultHeader;
	
	@FindBy(xpath = "//select[@id='templateType']")
	WebElement templateType;
	
	@FindBy(xpath = "//input[contains(@name,'templateName')]")
	WebElement templateTypeEnter;
	
	@FindBy(xpath = "//input[contains(@value,'Expand All')]")
	WebElement expandAll;
	
	@FindBy(xpath = "//input[@name='internalActionRefNo'and @type='radio']")
	WebElement outputDocParentWinRadioBtn;
	
	@FindBy(xpath = "(//select[@name='documentLanguageId']/../following::td//img)[1]")
	WebElement outputDocDownloadImg;
	
	// Initializing the Page Objects:
	public NewContractPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	} 
	//COntract Details//	
	public String validateLoginPageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}

	public WebElement selectTemplate(){
		return selectTemplate;
	} 

	public WebElement proContractCheckBox(){
		return proContractCheckBox;
	} 


	public WebElement traderNameDropDown(){
		return traderName;
	} 

	public WebElement masterContract(){
		return masterContract;
	} 

	public WebElement contractIssueDate(){
		return contractIssueDate;
	} 

	public WebElement dealTypeDropDown(){
		return dealType;
	} 

	public WebElement cpName(){
		return cpName;
	} 

	public WebElement cpNameSelect(){
		return cpNameSelect;
	} 


	public WebElement cpIncharge(){
		return cpIncharge;
	} 

	public WebElement brokerName(){
		return brokerName;
	} 

	public WebElement brokerIncharge(){
		return brokerIncharge;
	} 

	public WebElement brokerRefNo(){
		return brokerRefNo;
	} 

	public WebElement cpContractRefNo(){
		return cpContractRefNo;
	} 

	public WebElement incoTerm(){
		return incoTerm;
	} 

	public WebElement brokerComTextbox(){
		return brokerComTextbox;
	} 

	public WebElement brokerComSelect(){
		return brokerComSelect;
	} 

	public WebElement paymentTerms(){
		return paymentTerms;
	} 

	public WebElement freightTerms(){
		return freightTerms;
	} 

	public WebElement contractqtyUnit(){
		return contractqtyUnit;
	} 

	public WebElement operator(){
		return operator;
	} 

	public WebElement personInCharge(){
		return personInCharge;
	} 

	public WebElement personSecondCharge(){
		return personSecondCharge;
	} 
	// Item Details //			
	public WebElement productDetailsProduct(){
		return productDetailsProduct;
	} 

	public WebElement productDetailsProductSelect(){
		return productDetailsProductSelect;
	} 

	public WebElement originSelect(){
		return originSelect;
	} 


	public WebElement originProductDetails(){
		return originProductDetails;
	} 


	public WebElement cropYearProductDetails(){
		return cropYearProductDetails;
	} 

	public WebElement cropYearSelect(){
		return cropYearSelect;
	} 


	public WebElement qualityProductDetails(){
		return qualityProductDetails;
	} 

	public WebElement qualityProductDetailsSelect(){
		return qualityProductDetailsSelect;
	} 

	public WebElement profitCenter(){
		return profitCenter;
	} 

	public WebElement strategy(){
		return strategy;
	} 

	public WebElement shortDescArea(){
		return shortDescArea;
	} 

	public WebElement longDescArea(){
		return longDescArea;
	} 
	// Quantity Details//
	public WebElement itemQtyinput(){
		return itemQtyinput;
	} 

	public WebElement conAreainput(){
		return conAreainput;
	} 

	public WebElement conAreaSelect(){
		return conAreaSelect;
	} 

	public WebElement expectedYieldInput(){
		return expectedYieldInput;
	} 

	public WebElement itemQtySelect(){
		return itemQtySelect;
	} 

	public WebElement packingType(){
		return packingType;
	} 

	public WebElement packingSizeId(){
		return packingSizeId;
	} 

	public WebElement toleranceMinenter(){
		return toleranceMinenter;
	} 

	public WebElement toleranceMaxenter(){
		return toleranceMaxenter;
	} 

	public WebElement toleranceType(){
		return toleranceType;
	} 

	public WebElement toleranceLevel(){
		return toleranceLevel;
	} 

	public WebElement toleranceRemarks(){
		return toleranceRemarks;
	} 
	// Price Details //	
	public WebElement qualityPDSchedule(){
		return qualityPDSchedule;
	} 

	public WebElement priceType(){
		return priceType;
	} 

	public WebElement futureInstrument(){
		return futureInstrument;
	} 

	public WebElement futurePrice(){
		return futurePrice;
	} 

	public WebElement fxInstoBasis(){
		return fxInstoBasis;
	} 

	public WebElement fxBasistoPay(){
		return fxBasistoPay;
	} 

	public WebElement priceMonth(){
		return priceMonth;
	} 

	public WebElement basisSelect(){
		return basisSelect;
	} 

	public WebElement basisEnter(){
		return basisEnter;
	} 

	public WebElement priceFixOption(){
		return priceFixOption;
	} 

	public WebElement priceFixMethod(){
		return priceFixMethod;
	} 

	public WebElement contractPriceEnter(){
		return contractPriceEnter;
	} 

	public WebElement contractPriceSelect(){
		return contractPriceSelect;
	} 

	public WebElement benchPriceEnter(){
		return benchPriceEnter;
	} 

	public WebElement benchPriceSelect(){
		return benchPriceSelect;
	} 

	public WebElement priceRemarks(){
		return priceRemarks;
	} 
	// Add addition deductions //
	public WebElement addDelete(){
		return addDelete;
	} 

	public WebElement addDeleteName(){
		return addDeleteName;
	} 

	public WebElement rateType(){
		return rateType;
	} 

	public WebElement rateEnter(){
		return rateEnter;
	} 

	public WebElement rateSelect(){
		return rateSelect;
	} 

	public WebElement weightBasis(){
		return weightBasis;
	} 

	public WebElement addRemarks(){
		return addRemarks;
	} 

	public WebElement addDedRowButton(){
		return addDedRowButton;
	} 
	//Delivery Period
	public WebElement shippingPeriodFrom(){
		return shippingPeriodFrom;
	} 

	public WebElement shippingPeriodTo(){
		return shippingPeriodTo;
	} 
	// Payment Terms
	public WebElement paymentDueDate(){
		return paymentDueDate;
	} 

	public WebElement invoiceDocPrice(){
		return invoiceDocPrice;
	} 

	public WebElement proinvPercentageEnter(){
		return proinvPercentageEnter;
	} 

	public WebElement latePaymentInterest(){
		return latePaymentInterestType;
	} 

	public WebElement latePaymentInterestRate(){
		return latePaymentInterestRate;
	} 

	public WebElement taxScheduleApplicableCountry(){
		return taxScheduleApplicableCountry;
	} 

	public WebElement taxScheduleApplicableStates(){
		return taxScheduleApplicableStates;
	} 

	public WebElement taxSchedule(){
		return taxSchedule;
	} 

	// Item List		
	public WebElement addItemButton(){
		return addItemButton;
	} 
	//Terms & Conditions
	public WebElement applicableLawContract(){
		return applicableLawContract;
	} 

	public WebElement arbitration(){
		return arbitration;
	} 

	public WebElement qualityFinalAt(){
		return qualityFinalAt;
	} 

	public WebElement weightFinaliziedAt(){
		return weightFinaliziedAt;
	} 

	public WebElement nextButtonContract(){
		return nextButtonContract;
	} 
	//delivery Details
	public WebElement destLocationType(){
		return destLocationType;
	} 

	public WebElement dischargeCountry(){
		return dischargeCountry;
	} 

	public WebElement dischargeCountrySelect(){
		return dischargeCountrySelect;
	} 

	public WebElement dischargePort(){
		return dischargePort;
	} 

	public WebElement dischargePortinput(){
		return dischargePortinput;
	} 



	public WebElement dischargePortSelect(){
		return dischargePortSelect;
	} 

	public WebElement originLabelClick(){
		return originLabelClick;
	} 

	public WebElement packingLabelClick(){
		return packingLabelClick;
	} 

	// Valuation details and cost estimates entry



	public WebElement valuationIncoTerm(){
		return valuationIncoTerm;
	}

	public WebElement valuationLocationTypeGroup(){
		return valuationLocationTypeGroup;
	} 

	public WebElement valuationLocationArrow(){
		return valuationLocationArrow;
	} 

	public WebElement valuationLocationSelect(){
		return valuationLocationSelect;
	} 

	public WebElement valuationLocationCityEnter(){
		return valuationLocationCityEnter;
	} 

	public WebElement valuationLocationCityArrow(){
		return valuationLocationCityArrow;
	} 

	public WebElement valuationLocationCitySelect(){
		return valuationLocationCitySelect;
	} 

	public WebElement positionCurrency(){
		return positionCurrency;
	}

	public WebElement fXPricetoPosition(){
		return fxPricetoPosition;
	}

	public WebElement expectedDeliveryLocation(){
		return expectedDeliveryLocation;
	} 

	public WebElement locationCountry(){
		return locationCountry;
	} 

	public WebElement locationCity(){
		return locationCity;
	}

	public WebElement itemRefNo(){
		return itemRefNo;
	}

	public WebElement costComponentName(){
		return costComponentName;
	}

	public WebElement incomeExpence(){
		return incomeExpence;
	} 

	public WebElement estimateFor(){
		return estimateFor;
	} 



	public WebElement rateTypeValuation(){
		return rateTypeValuation;
	}

	public WebElement costValueUnit(){
		return costValueUnit;
	}

	public WebElement costValue(){
		return costValue;
	} 

	public WebElement fxToBase(){
		return fxToBase;
	} 

	public WebElement costAmount(){
		return costAmount;
	} 

	public WebElement fxToPosition(){
		return fxToPosition;
	} 

	public WebElement comments(){
		return comments;
	}

	public WebElement add(){
		return add;
	} 

	public WebElement next(){
		return next;
	} 

	public WebElement previous(){
		return previous;
	} 

	public WebElement cancel(){
		return cancel;
	} 

	public WebElement saveAsDraft(){
		return saveAsDraft;
	}

	public WebElement expectedDestLocationType(){
		return expectedDestLocationType;
	} 

	public WebElement expectedDischargeCountry(){
		return expectedDischargeCountry;
	} 


	public WebElement expectedDischargeCountrySelect(){
		return expectedDischargeCountrySelect;
	} 


	public WebElement expectedDischargePortSelect(){
		return expectedDischargePortSelect;
	} 


	public WebElement expectedDischargePort(){
		return expectedDischargePort;
	} 

	public WebElement ok(){
		return ok;
	}

	public WebElement create(){
		return create;
	}

	public WebElement save(){
		return save;
	}

	public WebElement refNo(){
		return refNo;
	}

	public WebElement Filter() {
		return filter;
	}

	public WebElement conRefNoSearch() {
		return conRefNoSearch;
	}

	public WebElement conRefNoSearchGo() {
		return conRefNoSearchGo;
	}
	public WebElement getSelectTemplate() {
		return selectTemplate;
	}
	public WebElement getProContractCheckBox() {
		return proContractCheckBox;
	}
	public WebElement getContractIssueDate() {
		return contractIssueDate;
	}
	public WebElement getTraderName() {
		return traderName;
	}
	public WebElement getMasterContract() {
		return masterContract;
	}
	public WebElement getDealType() {
		return dealType;
	}
	public WebElement getCpName() {
		return cpName;
	}
	public WebElement getCpNameSelect() {
		return cpNameSelect;
	}
	public WebElement getCpIncharge() {
		return cpIncharge;
	}
	public WebElement getBrokerName() {
		return brokerName;
	}
	public WebElement getBrokerIncharge() {
		return brokerIncharge;
	}
	public WebElement getBrokerRefNo() {
		return brokerRefNo;
	}
	public WebElement getCpContractRefNo() {
		return cpContractRefNo;
	}
	public WebElement getIncoTerm() {
		return incoTerm;
	}
	public WebElement getBrokerComTextbox() {
		return brokerComTextbox;
	}
	public WebElement getBrokerComSelect() {
		return brokerComSelect;
	}
	public WebElement getPaymentTerms() {
		return paymentTerms;
	}
	public WebElement getFreightTerms() {
		return freightTerms;
	}
	public WebElement getContractqtyUnit() {
		return contractqtyUnit;
	}
	public WebElement getOperator() {
		return operator;
	}
	public WebElement getPersonInCharge() {
		return personInCharge;
	}
	public WebElement getPersonSecondCharge() {
		return personSecondCharge;
	}
	public WebElement getProductDetailsProduct() {
		return productDetailsProduct;
	}
	public WebElement getProductDetailsProductSelect() {
		return productDetailsProductSelect;
	}
	public WebElement getOriginSelect() {
		return originSelect;
	}
	public WebElement getCropYearSelect() {
		return cropYearSelect;
	}
	public WebElement getOriginProductDetails() {
		return originProductDetails;
	}
	public WebElement getCropYearProductDetails() {
		return cropYearProductDetails;
	}
	public WebElement getQualityProductDetails() {
		return qualityProductDetails;
	}
	public WebElement getQualityProductDetailsSelect() {
		return qualityProductDetailsSelect;
	}
	public WebElement getProfitCenter() {
		return profitCenter;
	}
	public WebElement getStrategy() {
		return strategy;
	}
	public WebElement getShortDescArea() {
		return shortDescArea;
	}
	public WebElement getLongDescArea() {
		return longDescArea;
	}
	public WebElement getItemQtyinput() {
		return itemQtyinput;
	}
	public WebElement getConAreainput() {
		return conAreainput;
	}
	public WebElement getConAreaSelect() {
		return conAreaSelect;
	}
	public WebElement getExpectedYieldInput() {
		return expectedYieldInput;
	}
	public WebElement getItemQtySelect() {
		return itemQtySelect;
	}
	public WebElement getPackingType() {
		return packingType;
	}
	public WebElement getPackingSizeId() {
		return packingSizeId;
	}
	public WebElement getToleranceMinenter() {
		return toleranceMinenter;
	}
	public WebElement getToleranceMaxenter() {
		return toleranceMaxenter;
	}
	public WebElement getToleranceType() {
		return toleranceType;
	}
	public WebElement getToleranceLevel() {
		return toleranceLevel;
	}
	public WebElement getToleranceRemarks() {
		return toleranceRemarks;
	}
	public WebElement getQualityPDSchedule() {
		return qualityPDSchedule;
	}
	public WebElement getPriceType() {
		return priceType;
	}
	public WebElement getFutureInstrument() {
		return futureInstrument;
	}
	public WebElement getFuturePrice() {
		return futurePrice;
	}
	public WebElement getFxInstoBasis() {
		return fxInstoBasis;
	}
	public WebElement getFxBasistoPay() {
		return fxBasistoPay;
	}
	public WebElement getPriceMonth() {
		return priceMonth;
	}
	public WebElement getBasisSelect() {
		return basisSelect;
	}
	public WebElement getBasisEnter() {
		return basisEnter;
	}
	public WebElement getPriceFixOption() {
		return priceFixOption;
	}
	public WebElement getPriceFixMethod() {
		return priceFixMethod;
	}
	public WebElement getContractPriceEnter() {
		return contractPriceEnter;
	}
	public WebElement getContractPriceSelect() {
		return contractPriceSelect;
	}
	public WebElement getBenchPriceEnter() {
		return benchPriceEnter;
	}
	public WebElement getBenchPriceSelect() {
		return benchPriceSelect;
	}
	public WebElement getPriceRemarks() {
		return priceRemarks;
	}
	public WebElement getAddDelete() {
		return addDelete;
	}
	public WebElement getAddDeleteName() {
		return addDeleteName;
	}
	public WebElement getRateType() {
		return rateType;
	}
	public WebElement getRateEnter() {
		return rateEnter;
	}
	public WebElement getRateSelect() {
		return rateSelect;
	}
	public WebElement getWeightBasis() {
		return weightBasis;
	}
	public WebElement getAddRemarks() {
		return addRemarks;
	}
	public WebElement getAddDedRowButton() {
		return addDedRowButton;
	}
	public WebElement getShippingPeriodFrom() {
		return shippingPeriodFrom;
	}
	public WebElement getShippingPeriodTo() {
		return shippingPeriodTo;
	}
	public WebElement getPaymentDueDate() {
		return paymentDueDate;
	}
	public WebElement getInvoiceDocPrice() {
		return invoiceDocPrice;
	}
	public WebElement getProinvPercentageEnter() {
		return proinvPercentageEnter;
	}
	public WebElement getLatePaymentInterestType() {
		return latePaymentInterestType;
	}
	public WebElement getLatePaymentInterestRate() {
		return latePaymentInterestRate;
	}
	public WebElement getTaxScheduleApplicableCountry() {
		return taxScheduleApplicableCountry;
	}
	public WebElement getTaxSchedule() {
		return taxSchedule;
	}
	public WebElement getTaxScheduleApplicableStates() {
		return taxScheduleApplicableStates;
	}
	public WebElement getAddItemButton() {
		return addItemButton;
	}
	public WebElement getApplicableLawContract() {
		return applicableLawContract;
	}
	public WebElement getArbitration() {
		return arbitration;
	}
	public WebElement getQualityFinalAt() {
		return qualityFinalAt;
	}
	public WebElement getWeightFinaliziedAt() {
		return weightFinaliziedAt;
	}
	public WebElement getNextButtonContract() {
		return nextButtonContract;
	}
	public WebElement getDestLocationType() {
		return destLocationType;
	}
	public WebElement getDischargeCountry() {
		return dischargeCountry;
	}
	public WebElement getDischargeCountrySelect() {
		return dischargeCountrySelect;
	}
	public WebElement getDischargePortSelect() {
		return dischargePortSelect;
	}
	public WebElement getDischargePortinput() {
		return dischargePortinput;
	}
	public WebElement getDischargePort() {
		return dischargePort;
	}
	public WebElement getOriginLabelClick() {
		return originLabelClick;
	}
	public WebElement getPackingLabelClick() {
		return packingLabelClick;
	}
	public WebElement getFilter() {
		return filter;
	}
	public WebElement getConRefNoSearch() {
		return conRefNoSearch;
	}
	public WebElement getConRefNoSearchGo() {
		return conRefNoSearchGo;
	}
	public WebElement getValuationIncoTerm() {
		return valuationIncoTerm;
	}
	public WebElement getValuationLocationTypeGroup() {
		return valuationLocationTypeGroup;
	}
	public WebElement getValuationLocationArrow() {
		return valuationLocationArrow;
	}
	public WebElement getValuationLocationSelect() {
		return valuationLocationSelect;
	}
	public WebElement getValuationLocationCityEnter() {
		return valuationLocationCityEnter;
	}
	public WebElement getValuationLocationCityArrow() {
		return valuationLocationCityArrow;
	}
	public WebElement getValuationLocationCitySelect() {
		return valuationLocationCitySelect;
	}
	public WebElement getPositionCurrency() {
		return positionCurrency;
	}
	public WebElement getFxPricetoPosition() {
		return fxPricetoPosition;
	}
	public WebElement getExpectedDeliveryLocation() {
		return expectedDeliveryLocation;
	}
	public WebElement getLocationCountry() {
		return locationCountry;
	}
	public WebElement getLocationCity() {
		return locationCity;
	}
	public WebElement getItemRefNo() {
		return itemRefNo;
	}
	public WebElement getCostComponentName() {
		return costComponentName;
	}
	public WebElement getIncomeExpence() {
		return incomeExpence;
	}
	public WebElement getEstimateFor() {
		return estimateFor;
	}
	public WebElement getRateTypeValuation() {
		return rateTypeValuation;
	}
	public WebElement getCostValue() {
		return costValue;
	}
	public WebElement getCostValueUnit() {
		return costValueUnit;
	}
	public WebElement getFxToBase() {
		return fxToBase;
	}
	public WebElement getCostAmount() {
		return costAmount;
	}
	public WebElement getFxToPosition() {
		return fxToPosition;
	}
	public WebElement getComments() {
		return comments;
	}
	public WebElement getAdd() {
		return add;
	}
	public WebElement getNext() {
		return next;
	}
	public WebElement getPrevious() {
		return previous;
	}
	public WebElement getCancel() {
		return cancel;
	}
	public WebElement getSaveAsDraft() {
		return saveAsDraft;
	}
	public WebElement getExpectedDestLocationType() {
		return expectedDestLocationType;
	}
	public WebElement getExpectedDischargeCountry() {
		return expectedDischargeCountry;
	}
	public WebElement getExpectedDischargeCountrySelect() {
		return expectedDischargeCountrySelect;
	}
	public WebElement getExpectedDischargePortSelect() {
		return expectedDischargePortSelect;
	}
	public WebElement getExpectedDischargePort() {
		return expectedDischargePort;
	}
	public WebElement getOk() {
		return ok;
	}
	public WebElement getCreate() {
		return create;
	}
	public WebElement getSave() {
		return save;
	}
	public WebElement getRefNo() {
		return refNo;
	}
	public WebElement getApprover() {
		return approver;
	}
	public WebElement getVerifyContract() {
		return verifyContract;
	}

	public WebElement getMainFilter() {
		return mainFilter;
	}
	public WebElement getFilterSearchInput() {
		return filterSearchInput;
	}
	public WebElement getFilterGo() {
		return filterGo;
	}
	public WebElement getFilterReset() {
		return filterReset;
	}
	public WebElement getContractCheckBox() {
		return contractCheckBox;
	}
	public WebElement getContractOperationsHeader() {
		return contractOperationsHeader;
	}
	public WebElement getNewPurchaseContractOperations() {
		return newPurchaseContractOperations;
	}
	public WebElement getNewSaleContractOperations() {
		return newSaleContractOperations;
	}
	public WebElement getAmendContractContractOperations() {
		return amendContractContractOperations;
	}
	public WebElement getReasonForAmend() {
		return reasonForAmend;
	}
	public WebElement getFirstRowCheckboxAddItem() {
		return firstRowCheckboxAddItem;
	}
	public WebElement getCopyItem() {
		return copyItem;
	}
	public WebElement getAmendCreateContract() {
		return amendCreateContract;
	}
	public WebElement getMainDefault() {
		return mainDefault;
	}
	public WebElement getModifyContractOperations() {
		return modifyContractOperations;
	}
	public WebElement getRemoveItem() {
		return removeItem;
	}
	public WebElement getModifyItem() {
		return modifyItem;
	}
	public WebElement getModifyContractButton() {
		return modifyContractButton;
	}
	public WebElement getUpdateItemButton() {
		return updateItemButton;
	}
	public WebElement getSaveDraftButtonContract() {
		return saveDraftButtonContract;
	}
	public WebElement getDraftRefNo() {
		return DraftRefNo;
	}
	public WebElement getDraftFilterSelect() {
		return draftFilterSelect;
	}
	public WebElement getDraftFilterEnter() {
		return draftFilterEnter;
	}
	public WebElement getCancelContractOperations() {
		return cancelContractOperations;
	}
	public WebElement getCancelReasonContract() {
		return cancelReasonContract;
	}
	public WebElement getOKcancelContract() {
		return OKcancelContract;
	}
	public WebElement getCancelContractStatus() {
		return cancelContractStatus;
	}
	public WebElement getTemplateName() {
		return templateName;
	}
	public WebElement getCreateTemplate() {
		return createTemplate;
	}
	public WebElement getTemplateRefNo() {
		return TemplateRefNo;
	}
	public WebElement getTemplateSearchEnter() {
		return templateSearchEnter;
	}
	public WebElement getTemplateTypeSelect() {
		return templateTypeSelect;
	}
	public WebElement getActivityTabOutputDoc() {
		return activityTabOutputDoc;
	}
	public WebElement getGenerateDocumentLink() {
		return generateDocumentLink;
	}
	public WebElement getGenerateDocExistingRadioBtn() {
		return generateDocExistingRadioBtn;
	}
	public WebElement getNewWinOutputNextBtn() {
		return newWinOutputNextBtn;
	}
	public WebElement getDefaultHeader() {
		return defaultHeader;
	}
	public WebElement getTemplateType() {
		return templateType;
	}
	public WebElement getTemplateTypeEnter() {
		return templateTypeEnter;
	}
	public WebElement getExpandAll() {
		return expandAll;
	}
	public WebElement getOutputDocParentWinRadioBtn() {
		return outputDocParentWinRadioBtn;
	}
	public WebElement getOutputDocDownloadImg() {
		return outputDocDownloadImg;
	}



}
