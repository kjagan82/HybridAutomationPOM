package com.qa.pages.Physicals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;
public class NewPrintableTemplatePage {

	@FindBy(xpath = "//input[contains(@name,'templateName')]")
	WebElement templateName;
	
	@FindBy(xpath = "//input[contains(@value,'Expand All')]")
	WebElement expandAllTemplate;
	
	/*@FindBy(xpath = "//input[contains(@name,'isPrintReqd') and @type='checkbox']")
	WebElement allCheckboxTemplate;*/
	
	//list of checkbox
	By allCheckboxTemplate=By.name("isPrintReqd");
	
	@FindBy(xpath = "//select[contains(@id,'customFieldId')]")
	WebElement customFieldSelect;
	
	@FindBy(xpath = "//td/textarea[contains(@name,'customText')]/following::img[@src='/private/images/search.gif']")
	WebElement customSearchImage;
	//new Window
	@FindBy(xpath = "//span[contains(text(),'Default')]")
	WebElement defaultHeader;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]")
	WebElement firstRowCheckBox;
	
	@FindBy(xpath = "//input[contains(@value,'Select')]")
	WebElement customSearchWinSelectBtn;
	
	//back to printable Template
	@FindBy(xpath = "//input[contains(@id,'addbutton')]")
	WebElement addFieldCustom;
	
	@FindBy(xpath = "//input[contains(@value,'Create Printable Template')]")
	WebElement createPrintableTemplate;
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement mainFilter;
	
	@FindBy(xpath = "//input[contains(@name,'templateName')]")
	WebElement templateTypeEnter;
	
	@FindBy(xpath = "//span[text()='Go']")
	WebElement filterGo;

	@FindBy(xpath = "//span[text()='Reset']")
	WebElement filterReset;

	@FindBy(xpath = "//select[@id='templateType']")
	WebElement templateType;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[2]")
	WebElement verifyPrintTemplate;
	
	
	// Initializing the Page Objects:
	public NewPrintableTemplatePage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	public WebElement getTemplateName() {
		return templateName;
	}

	public WebElement getExpandAllTemplate() {
		return expandAllTemplate;
	}

	/*public WebElement getAllCheckboxTemplate() {
		return allCheckboxTemplate;
	}
*/
	public WebElement getCustomFieldSelect() {
		return customFieldSelect;
	}

	public WebElement getCustomSearchImage() {
		return customSearchImage;
	}

	public WebElement getDefaultHeader() {
		return defaultHeader;
	}

	public WebElement getFirstRowCheckBox() {
		return firstRowCheckBox;
	}

	public WebElement getCustomSearchWinSelectBtn() {
		return customSearchWinSelectBtn;
	}

	public WebElement getAddFieldCustom() {
		return addFieldCustom;
	}

	public WebElement getCreatePrintableTemplate() {
		return createPrintableTemplate;
	}

	public By getAllCheckboxTemplate() {
		return allCheckboxTemplate;
	}

	public WebElement getMainFilter() {
		return mainFilter;
	}

	public WebElement getTemplateTypeEnter() {
		return templateTypeEnter;
	}

	public WebElement getFilterGo() {
		return filterGo;
	}

	public WebElement getFilterReset() {
		return filterReset;
	}

	public WebElement getTemplateType() {
		return templateType;
	}

	public WebElement getVerifyPrintTemplate() {
		return verifyPrintTemplate;
	} 
	
	
	
}