package com.qa.pages.Accounting;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.qa.base.TestBaseListener;

public class NewProvisionalInvoicePage {

	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	@CacheLookup
	WebElement mainFilter;

	@FindBy(xpath = "//select[contains(@id,'invoiceSearchCriteria' ) or contains(@id,'referenceNoType')]")
	@CacheLookup
	WebElement filterSearchSelect;

	@FindBy(xpath = "//input[contains(@id,'contractRefNo') or contains(@id,'searchTextBox') or contains(@name,'referenceNo')]")
	@CacheLookup
	WebElement filterSearchInput;

	@FindBy(xpath = "//span[text()='Go']")
	@CacheLookup
	WebElement filterGo;

	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]")
	@CacheLookup
	WebElement provisionalInvCheckBox;

	@FindBy(xpath = "//span[contains(text(),'Invoice') and contains(@id,'btnInnerEl')]")
	@CacheLookup
	WebElement invoiceHeader;

	@FindBy(xpath = "//span[text()='Provisional Invoice']")
	@CacheLookup
	WebElement provisionalInvLabel;

	@FindBy(xpath = "//input[contains(@name,'cpInvoiceRefNo')]")
	@CacheLookup
	WebElement CPInvRefNOENter;

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement issueDateProvisional; 

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[2]")
	@CacheLookup
	WebElement dueDateProvisional; 

	@FindBy(xpath = "//input[contains(@id,'accountingDateId')]/../following::td//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement accountingDatePrePayment; 

	@FindBy(xpath = "(//input[contains(@placeholder,'Select CP Name...')]/../following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement cpProvisionalInvArrow;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	@CacheLookup
	WebElement cpProvisionalInvSelect;

	/*Invoice Amount Details*/

	@FindBy(xpath = "//td/input[contains(@id,'perAmtToPayId')]")
	@CacheLookup
	WebElement amountToPayEnter;

	@FindBy(xpath = "//input[contains(@id,'adjustmentId')]")
	@CacheLookup
	WebElement roundAdjusEnter;

	/*Payment Instructions*/

	@FindBy(xpath = "//select[contains(@id,'CPbankProfileId')]")
	@CacheLookup
	WebElement bankNameProvisionalSelect; 

	@FindBy(xpath = "//select[contains(@id,'CPaccountId')]")
	@CacheLookup
	WebElement accountNameProvisionalSelect; 

	@FindBy(id = "cPAddButtonId")
	@CacheLookup
	WebElement addRowButton;

	@FindBy(xpath = "//input[@value='Save']")  
	@CacheLookup
	WebElement savePrePaymentInvoice;

	@FindBy(xpath = "(//th[contains(text(),'Invoice Ref. No.')]/../following::tr/td)[4]")  
	@CacheLookup
	WebElement refNoProvisionalInvoice;

	@FindBy(xpath = "//input[@value='OK']")  
	@CacheLookup
	WebElement refNoProvisionalInvoiceOK;

	// Initializing the Page Objects:

	public NewProvisionalInvoicePage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	/*Utilization*/

	public WebElement getMainFilter() {
		return mainFilter;
	}

	public WebElement getFilterSearchSelect() {
		return filterSearchSelect;
	}

	public WebElement getFilterSearchInput() {
		return filterSearchInput;
	}

	public WebElement getFilterGo() {
		return filterGo;
	}

	public WebElement getProvisionalInvCheckBox() {
		return provisionalInvCheckBox;
	}

	public WebElement getInvoiceHeader() {
		return invoiceHeader;
	}

	public WebElement getProvisionalInvLabel() {
		return provisionalInvLabel;
	}

	public WebElement getIssueDateProvisional() {
		return issueDateProvisional;
	}

	public WebElement getDueDateProvisional() {
		return dueDateProvisional;
	}

	public WebElement getAccountingDatePrePayment() {
		return accountingDatePrePayment;
	}

	public WebElement getCpProvisionalInvArrow() {
		return cpProvisionalInvArrow;
	}

	public WebElement getCpProvisionalInvSelect() {
		return cpProvisionalInvSelect;
	}

	public WebElement getAmountToPayEnter() {
		return amountToPayEnter;
	}

	public WebElement getRoundAdjusEnter() {
		return roundAdjusEnter;
	}

	public WebElement getBankNameProvisionalSelect() {
		return bankNameProvisionalSelect;
	}

	public WebElement getAccountNameProvisionalSelect() {
		return accountNameProvisionalSelect;
	}

	public WebElement getAddRowButton() {
		return addRowButton;
	}

	public WebElement getSavePrePaymentInvoice() {
		return savePrePaymentInvoice;
	}

	public WebElement getRefNoProvisionalInvoice() {
		return refNoProvisionalInvoice;
	}

	public WebElement getRefNoProvisionalInvoiceOK() {
		return refNoProvisionalInvoiceOK;
	}

	public WebElement getCPInvRefNOENter() {
		return CPInvRefNOENter;
	} 


}
