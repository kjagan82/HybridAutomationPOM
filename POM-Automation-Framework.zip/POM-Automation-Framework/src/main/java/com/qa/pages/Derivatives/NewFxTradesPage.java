/**
 * 
 */
package com.qa.pages.Derivatives;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;

/**
 * @author jaganmohan.k
 *
 */
public class NewFxTradesPage {

	/*Future Contract Details*/
	@FindBy(xpath = "//input[contains(@id,'treasuryRefNo')]")
	@CacheLookup
	WebElement  treasuryRefNo;
	
	@FindBy(xpath = "//input[contains(@id,'externalRefNo')]")
	@CacheLookup
	WebElement externalRefNo;

	@FindBy(xpath = "//td[contains(text(),'Trade Date')]/following-sibling::td/div[contains(@id,'tradeDatetradeDateDIVID')]/..//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement tradeDate; 
	

	@FindBy(id = "traderId")
	WebElement trader;
	
	@FindBy(xpath = "//td[contains(text(),'Value Date')]/following-sibling::td/div[contains(@id,'valueDatevalueDateDIVID')]/..//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement valueDate; 

	@FindBy(xpath = "//*[@id='exchangeInstrumentId']")
	WebElement currencyInstrument;
	
	@FindBy(xpath = "//td[contains(text(),'Settlement Date From')]/following-sibling::td/div[contains(@id,'settlementFromDatesettlementFromDateDIVID')]/..//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement settlementFromDate; 
	
	@FindBy(xpath = "//div[contains(@class,'trigger x-form-arrow-trigger x-form-trigger-first')]")
	WebElement counterPartyArrow;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	WebElement counterPartyUL;
	
	@FindBy(xpath = "//*[@id='masterContractId']")
	WebElement masterContractId;
	
	@FindBy(id = "paymentTermsId")
	WebElement paymentTermsId;
	
	@FindBy(xpath = "//td[contains(text(),'Payment Due Date')]/following-sibling::td/div[contains(@id,'paymentDueDatepaymentDueDateDIVID')]/..//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement paymentDueDate;
	
	//FX Trade 1 Details
	
	@FindBy(id = "fxTrade1Details.tradeType")
	WebElement fxTrade1Type;

	@FindBy(xpath = "//*[@id='fxTrade1Details.amount']")
	WebElement amount;
	
	@FindBy(xpath = "//input[@type='checkbox' and @name='exchRateChk']")
	WebElement exchangeRateComponentsChkBox;
	
	@FindBy(id = "exchangeRate")
	WebElement exchangeRate;
	
	//Exchange Rate Details if exchangeRateComponentsChkBox selected
		@FindBy(id = "spotRate")
		WebElement spotRate;
		
		@FindBy(id = "marginRate")
		WebElement marginRate;
		
		@FindBy(id = "premiumRate")
		WebElement premiumRate;
		
		@FindBy(id = "otherCharges")
		WebElement otherCharges;
		
		@FindBy(id = "slippageRate")
		WebElement slippageRate;
	
	//FX Trade 2 Details
	@FindBy(id = "bankId")
	WebElement bankId;
	
	@FindBy(id = "bankAccountId")
	WebElement bankAccountId;
	
	@FindBy(xpath = "//input[@name='fxTradeModel.bankCharges']")
	WebElement bankCharges;
	
	@FindBy(id = "bankChargesType")
	WebElement bankChargesType;
	
	@FindBy(id = "bankChargesCurId")
	WebElement bankChargesCurId;
	
	
	/*Internal Module*/
	@FindBy(id = "profitCenterId")
	WebElement profitCenterId;

	@FindBy(id = "strategyId")
	WebElement strategyId;
	
	
	@FindBy(id = "purposeId")
	WebElement purposeId;
	
	@FindBy(id = "nomineeProfileId")
	@CacheLookup
	WebElement nominee; 
	
	
	@FindBy(id = "create")
	WebElement createButton;

	@FindBy(xpath = "(//td[contains(text(),'Trade Ref. No.')]/parent::tr/following::td)[2]")
	WebElement createdTradeRefNo;

	@FindBy(xpath = "//input[@value='Ok' and @type='button']")
	WebElement ok_button;

	// Initializing the Page Objects:
	public NewFxTradesPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	public String validateLoginPageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}

	/**
	 * @return the treasuryRefNo
	 */
	public WebElement getTreasuryRefNo() {
		return treasuryRefNo;
	}

	/**
	 * @return the externalRefNo
	 */
	public WebElement getExternalRefNo() {
		return externalRefNo;
	}

	/**
	 * @return the tradeDate
	 */
	public WebElement getTradeDate() {
		return tradeDate;
	}

	/**
	 * @return the trader
	 */
	public WebElement getTrader() {
		return trader;
	}

	/**
	 * @return the valueDate
	 */
	public WebElement getValueDate() {
		return valueDate;
	}

	/**
	 * @return the currencyInstrument
	 */
	public WebElement getCurrencyInstrument() {
		return currencyInstrument;
	}

	/**
	 * @return the settlementFromDate
	 */
	public WebElement getSettlementFromDate() {
		return settlementFromDate;
	}

	/**
	 * @return the counterPartyArrow
	 */
	public WebElement getCounterPartyArrow() {
		return counterPartyArrow;
	}

	/**
	 * @return the counterPartyUL
	 */
	public WebElement getCounterPartyUL() {
		return counterPartyUL;
	}

	/**
	 * @return the masterContractId
	 */
	public WebElement getMasterContractId() {
		return masterContractId;
	}

	/**
	 * @return the paymentTermsId
	 */
	public WebElement getPaymentTermsId() {
		return paymentTermsId;
	}

	/**
	 * @return the paymentDueDate
	 */
	public WebElement getPaymentDueDate() {
		return paymentDueDate;
	}

	/**
	 * @return the fxTrade1Type
	 */
	public WebElement getFxTrade1Type() {
		return fxTrade1Type;
	}

	/**
	 * @return the amount
	 */
	public WebElement getAmount() {
		return amount;
	}

	/**
	 * @return the exchangeRateComponentsChkBox
	 */
	public WebElement getExchangeRateComponentsChkBox() {
		return exchangeRateComponentsChkBox;
	}

	/**
	 * @return the exchangeRate
	 */
	public WebElement getExchangeRate() {
		return exchangeRate;
	}

	/**
	 * @return the spotRate
	 */
	public WebElement getSpotRate() {
		return spotRate;
	}

	/**
	 * @return the marginRate
	 */
	public WebElement getMarginRate() {
		return marginRate;
	}

	/**
	 * @return the premiumRate
	 */
	public WebElement getPremiumRate() {
		return premiumRate;
	}

	/**
	 * @return the otherCharges
	 */
	public WebElement getOtherCharges() {
		return otherCharges;
	}

	/**
	 * @return the slippageRate
	 */
	public WebElement getSlippageRate() {
		return slippageRate;
	}

	/**
	 * @return the bankId
	 */
	public WebElement getBankId() {
		return bankId;
	}

	/**
	 * @return the bankAccountId
	 */
	public WebElement getBankAccountId() {
		return bankAccountId;
	}

	/**
	 * @return the bankCharges
	 */
	public WebElement getBankCharges() {
		return bankCharges;
	}

	/**
	 * @return the bankChargesType
	 */
	public WebElement getBankChargesType() {
		return bankChargesType;
	}

	/**
	 * @return the bankChargesCurId
	 */
	public WebElement getBankChargesCurId() {
		return bankChargesCurId;
	}

	/**
	 * @return the profitCenterId
	 */
	public WebElement getProfitCenterId() {
		return profitCenterId;
	}

	/**
	 * @return the strategyId
	 */
	public WebElement getStrategyId() {
		return strategyId;
	}

	/**
	 * @return the purposeId
	 */
	public WebElement getPurposeId() {
		return purposeId;
	}

	/**
	 * @return the createButton
	 */
	public WebElement getCreateButton() {
		return createButton;
	}

	/**
	 * @return the createdTradeRefNo
	 */
	public WebElement getCreatedTradeRefNo() {
		return createdTradeRefNo;
	}

	/**
	 * @return the ok_button
	 */
	public WebElement getOk_button() {
		return ok_button;
	}

	/**
	 * @return the selectnominee
	 */
	public WebElement getNominee() {
		return nominee;
	}

}
