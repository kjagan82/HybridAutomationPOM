package com.qa.pages.Logistics;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;

public class NewInvoicePage {

	/*Filtering to reach the Prepayment invoice page*/
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	@CacheLookup
	WebElement mainFilter;

	@FindBy(xpath = "//select[contains(@id,'searchCriteria' ) or contains(@id,'referenceNoType')or contains(@id,'invoiceSearchCriteria')]")
	@CacheLookup
	WebElement filterSearchSelect;

	@FindBy(xpath = "//input[contains(@id,'contractRefNo') or contains(@id,'searchTextBox') or contains(@name,'referenceNo')]")
	@CacheLookup
	WebElement filterSearchInput;

	@FindBy(xpath = "//span[text()='Go']")
	@CacheLookup
	WebElement filterGo;
	
	@FindBy(xpath = "//span[text()='Reset']")
	@CacheLookup
	WebElement filterReset;
	

	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]")
	@CacheLookup
	WebElement contractCheckBox;

	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[15]")
	@CacheLookup
	WebElement incomeExpenseText;


	@FindBy(xpath = "//span[contains(text(),'Invoice') and contains(@id,'btnInnerEl')]")
	@CacheLookup
	WebElement invoiceHeader;

	@FindBy(xpath = "//span[contains(text(),'Operations') and contains(@id,'btnInnerEl')]")
	@CacheLookup
	WebElement operationsHeader;


	@FindBy(xpath = "//span[contains(text(),'Prepayment Invoice')]")
	@CacheLookup
	WebElement prePaymentInvLabel;

	@FindBy(xpath = "//span[text()='Service Invoice Received']")
	@CacheLookup
	WebElement serviceInvoiceReceivedLabel;

	@FindBy(xpath = "//span[text()='Service Invoice Raised']")
	@CacheLookup
	WebElement serviceInvoiceRaisedLabel;

	@FindBy(xpath = "	//span[text()='Final Invoice']")
	@CacheLookup
	WebElement finalInvoiceLabel;


	/*Pre-Payment Invoice Details*/

	@FindBy(xpath = "//select[contains(@id,'serviceInvoiceAgainstId')]")
	@CacheLookup
	WebElement serviceInvAgainstSelect;

	@FindBy(xpath = "(//td[contains(@id,'vesselNameCombo')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement refNoArrow;

	@FindBy(xpath = "(//input[contains(@placeholder,'Select CP Name...')]/../following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement cpReceivedInvArrow;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	@CacheLookup
	WebElement cpReceivedInvSelect;



	@FindBy(xpath = "//select[contains(@id,'invoiceCurrencyId')]")
	@CacheLookup
	WebElement invoiceCurrencySelect;

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement issueDatePrePayment; 

	@FindBy(xpath = "(//td[contains(text(),'Issue Date')]/following::td//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement issueDateFinalInv; 
	
	@FindBy(xpath = "(//td[contains(text(),'Due Date')]/following::td//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement dueDateFinalInv; 
	
	@FindBy(xpath = "	(//td[contains(text(),'Accounting Date')]/following::td//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement accDateFinalInv;

	@FindBy(xpath = "//input[contains(@name,'cpInvoiceRefNo')]")
	@CacheLookup
	WebElement CPInvoiceRefENter;

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[2]")
	@CacheLookup
	WebElement dueDatePrePayment; 

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[3]")
	@CacheLookup
	WebElement accountingDatePrePayment; 

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[3]")
	@CacheLookup
	WebElement dueDatePrePaymentReceivedInv; 

	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[2]")
	@CacheLookup
	WebElement accDatePrePaymentReceivedInv; 

	@FindBy(xpath = "//select[contains(@id,'countryId')]")
	@CacheLookup
	WebElement taxSchedAppCountryReceivedInv; 

	@FindBy(xpath = "//select[contains(@id,'taxScheduleId')]")
	@CacheLookup
	WebElement taxSchedReceivedInv;

	@FindBy(xpath = "//select[contains(@id,'loadingLocationType')]")
	@CacheLookup
	WebElement loadingLocType;

	@FindBy(xpath = "//select[contains(@id,'destinationLocationType')]")
	@CacheLookup
	WebElement destinationLocType;

	@FindBy(xpath = "(//input[contains(@placeholder,'Select Product...')]/../following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement productGeneralInvArrow;	

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	@CacheLookup
	WebElement productGeneralInvSelect;


	@FindBy(xpath = "(//input[contains(@placeholder,'Select Origin...')]/../following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement originGeneralInvArrow;	

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[3])")
	@CacheLookup
	WebElement originGeneralInvSelect;

	@FindBy(xpath = "(//input[contains(@placeholder,'Select Crop Year...')]/../following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement cropYearGeneralInvArrow;	

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[4])")
	@CacheLookup
	WebElement cropYearGeneralInvSelect;


	@FindBy(xpath = "(//input[contains(@placeholder,'Select Quality...')]/../following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement qualityGeneralInvArrow;	

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[5])")
	@CacheLookup
	WebElement qualityGeneralInvSelect;


	/*Cost Details*/

	@FindBy(xpath = "//select[contains(@id,'costId')]")
	@CacheLookup
	WebElement costReceivedInvSelect;

	@FindBy(xpath = "//select[contains(@id,'monthId')]")
	@CacheLookup
	WebElement monthReceivedInvSelect;


	@FindBy(xpath = "//input[contains(@name,'costInputModel') and contains(@id,'enteredYear')]")
	@CacheLookup
	WebElement yearReceivedInvEnter;

	@FindBy(xpath = "//input[contains(@name,'costInputModel') and contains(@id,'enteredActualCost')]")
	@CacheLookup
	WebElement actualCostGeneralReceivedInvEnter;

	@FindBy(xpath = "//select[contains(@name,'costInputModel') and contains(@id,'profitCenter')]")
	@CacheLookup
	WebElement profitCenterGeneralReceivedInvEnter;


	@FindBy(xpath = "//input[@id=('actualAmtInTranCur1') and contains(@name,'invoiceAccrualCostList')]")
	@CacheLookup
	WebElement actualCostReceivedInvEnter;


	/*Payment Instructions*/

	@FindBy(xpath = "//select[contains(@id,'CPbankProfileId')]")
	@CacheLookup
	WebElement bankNamePrePaymentSelect; 

	@FindBy(xpath = "//select[contains(@id,'OURbankProfileId')]")
	@CacheLookup
	WebElement bankNameRaisedInvSelect; 


	@FindBy(xpath = "//select[contains(@id,'CPaccountId')]")
	@CacheLookup
	WebElement accountNamePrePaymentSelect; 

	@FindBy(xpath = "//select[contains(@id,'OURaccountId')]")
	@CacheLookup
	WebElement accountNameRaisedInvSelect; 

	@FindBy(id = "cPAddButtonId")
	@CacheLookup
	WebElement addRowButton;

	@FindBy(xpath = "//input[contains(@id,'submitActualCost') and @value='Add']")
	@CacheLookup
	WebElement addCPdetailsButton;
	
	@FindBy(xpath = "//input[@value='Save']")  
	@CacheLookup
	WebElement savePrePaymentInvoice;

	@FindBy(xpath = "(//th[contains(text(),'Invoice Ref. No.')]/../following::tr/td)[4]")  
	@CacheLookup
	WebElement refNoPrePaymentInvoice;

	@FindBy(xpath = "(//th[contains(text(),'Activity Ref. No.')]/../following::tr/td)[3]")  
	@CacheLookup
	WebElement refNoRecievedServiceInvoice;

	@FindBy(xpath = "//input[@value='OK']")  
	@CacheLookup
	WebElement refNoPrePaymentInvoiceOK;

	@FindBy(xpath = "//input[@value='Ok' or @value='OK']")  
	@CacheLookup
	WebElement refNoReceiveServInvoiceOK;

	@FindBy(xpath = "//input[@value='Add' and contains(@id,'cPAddButtonId')]")  
	@CacheLookup
	WebElement addCPserviceRecieved;
	
	/*Tax Details Final Invoice*/
	
	@FindBy(xpath = "//select[contains(@id,'ourVatId')]")
	@CacheLookup
	WebElement ourTaxNoFinalInv; 
	
	@FindBy(xpath = "//input[contains(@name,'ourVatDetails.vatCodeDesc')]")
	@CacheLookup
	WebElement taxDescFinalInv; 
	
	@FindBy(xpath = "//select[contains(@id,'cpVatId')]")
	@CacheLookup
	WebElement CPTaxNoFinalInv; 
	
	@FindBy(xpath = "//input[contains(@name,'cpVatDetails.vatCodeDesc')]")
	@CacheLookup
	WebElement CptaxDescFinalInv;
	
	


	// Initializing the Page Objects:
	public NewInvoicePage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	// Itilizations 
	public WebElement getMainFilter() {
		return mainFilter;
	}
	
	/*Utilization*/
	

	public WebElement getFilterSearchSelect() {
		return filterSearchSelect;
	}
	

	public WebElement getFilterReset() {
		return filterReset;
	}

	public WebElement getFilterSearchInput() {
		return filterSearchInput;
	}

	public WebElement getFilterGo() {
		return filterGo;
	}

	public WebElement getContractCheckBox() {
		return contractCheckBox;
	}

	public WebElement getIncomeExpenseText() {
		return incomeExpenseText;
	}

	public WebElement getInvoiceHeader() {
		return invoiceHeader;
	}

	public WebElement getOperationsHeader() {
		return operationsHeader;
	}

	public WebElement getServiceInvoiceReceivedLabel() {
		return serviceInvoiceReceivedLabel;
	}

	public WebElement getPrePaymentInvLabel() {
		return prePaymentInvLabel;
	}


	public WebElement getServiceInvAgainstSelect() {
		return serviceInvAgainstSelect;
	}

	public WebElement getIssueDatePrePayment() {
		return issueDatePrePayment;
	}

	public WebElement getCPInvoiceRefENter() {
		return CPInvoiceRefENter;
	}

	public WebElement getDueDatePrePayment() {
		return dueDatePrePayment;
	}

	public WebElement getAccountingDatePrePayment() {
		return accountingDatePrePayment;
	}

	public WebElement getTaxSchedAppCountryReceivedInv() {
		return taxSchedAppCountryReceivedInv;
	}

	public WebElement getTaxSchedReceivedInv() {
		return taxSchedReceivedInv;
	}

	public WebElement getDestinationLocType() {
		return destinationLocType;
	}

	public WebElement getLoadingLocType() {
		return loadingLocType;
	}

	public WebElement getProductGeneralInvArrow() {
		return productGeneralInvArrow;
	}

	public WebElement getProductGeneralInvSelect() {
		return productGeneralInvSelect;
	}


	public WebElement getOriginGeneralInvArrow() {
		return originGeneralInvArrow;
	}

	public WebElement getOriginGeneralInvSelect() {
		return originGeneralInvSelect;
	}

	public WebElement getCropYearGeneralInvArrow() {
		return cropYearGeneralInvArrow;
	}

	public WebElement getCropYearGeneralInvSelect() {
		return cropYearGeneralInvSelect;
	}

	public WebElement getQualityGeneralInvArrow() {
		return qualityGeneralInvArrow;
	}

	public WebElement getQualityGeneralInvSelect() {
		return qualityGeneralInvSelect;
	}

	public WebElement getDueDatePrePaymentReceivedInv() {
		return dueDatePrePaymentReceivedInv;
	}

	public WebElement getCostReceivedInvSelect() {
		return costReceivedInvSelect;
	}



	public WebElement getMonthReceivedInvSelect() {
		return monthReceivedInvSelect;
	}

	public WebElement getRefNoArrow() {
		return refNoArrow;
	}

	public WebElement getCpReceivedInvArrow() {
		return cpReceivedInvArrow;
	}

	public WebElement getCpReceivedInvSelect() {
		return cpReceivedInvSelect;
	}

	public WebElement getAccDatePrePaymentReceivedInv() {
		return accDatePrePaymentReceivedInv;
	}


	public WebElement getProfitCenterGeneralReceivedInvEnter() {
		return profitCenterGeneralReceivedInvEnter;
	}

	public WebElement getActualCostGeneralReceivedInvEnter() {
		return actualCostGeneralReceivedInvEnter;
	}

	public WebElement getInvoiceCurrencySelect() {
		return invoiceCurrencySelect;
	}

	public WebElement getYearReceivedInvEnter() {
		return yearReceivedInvEnter;
	}

	public WebElement getBankNamePrePaymentSelect() {
		return bankNamePrePaymentSelect;
	}

	public WebElement getAccountNamePrePaymentSelect() {
		return accountNamePrePaymentSelect;
	}

	public WebElement getAddRowButton() {
		return addRowButton;
	}

	public WebElement getSavePrePaymentInvoice() {
		return savePrePaymentInvoice;
	}

	public WebElement getRefNoPrePaymentInvoice() {
		return refNoPrePaymentInvoice;
	}

	public WebElement getRefNoPrePaymentInvoiceOK() {
		return refNoPrePaymentInvoiceOK;
	}

	public WebElement getRefNoRecievedServiceInvoice() {
		return refNoRecievedServiceInvoice;
	}

	public WebElement getActualCostReceivedInvEnter() {
		return actualCostReceivedInvEnter;
	}

	public WebElement getRefNoReceiveServInvoiceOK() {
		return refNoReceiveServInvoiceOK;
	}

	public WebElement getServiceInvoiceRaisedLabel() {
		return serviceInvoiceRaisedLabel;
	}

	public WebElement getBankNameRaisedInvSelect() {
		return bankNameRaisedInvSelect;
	}

	public WebElement getAccountNameRaisedInvSelect() {
		return accountNameRaisedInvSelect;
	}

	public WebElement getAddCPserviceRecieved() {
		return addCPserviceRecieved;
	}

	public WebElement getAddCPdetailsButton() {
		return addCPdetailsButton;
	}

	public WebElement getIssueDateFinalInv() {
		return issueDateFinalInv;
	}

	public WebElement getDueDateFinalInv() {
		return dueDateFinalInv;
	}

	public WebElement getAccDateFinalInv() {
		return accDateFinalInv;
	}

	public WebElement getOurTaxNoFinalInv() {
		return ourTaxNoFinalInv;
	}

	public WebElement getTaxDescFinalInv() {
		return taxDescFinalInv;
	}

	public WebElement getCPTaxNoFinalInv() {
		return CPTaxNoFinalInv;
	}

	public WebElement getCptaxDescFinalInv() {
		return CptaxDescFinalInv;
	}

	public WebElement getFinalInvoiceLabel() {
		return finalInvoiceLabel;
	}
	

}
