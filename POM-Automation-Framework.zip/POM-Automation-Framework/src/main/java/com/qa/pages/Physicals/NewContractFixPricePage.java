package com.qa.pages.Physicals;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;
public class NewContractFixPricePage {
	
	@FindBy(xpath = "//span[contains(text(),'Physicals')]/following::span[1]")
	WebElement physicalsLabel;
	
	
	@FindBy(xpath = "//span[contains(text(),'Filter')]")
	WebElement ContractMainFilter;
	
	@FindBy(xpath = "//select[contains(@id,'contractItemsearchCriteria' )]")
	WebElement filterSearchSelect;

	@FindBy(xpath = "//input[contains(@id,'contractRefNo') or contains(@id,'searchTextBox') or contains(@name,'referenceNo')]")
	WebElement filterSearchInput;
	
	@FindBy(xpath = "//span[text()='Go']")
	WebElement filterGo;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]")
	WebElement contractItemsCheckBox;
	
	@FindBy(xpath = "//span[contains(text(),'Contract Operations') and contains(@id,'btnInnerEl')]")
	WebElement contractOperationsHeader;

	@FindBy(xpath = "//span[text()='Fix Price']")
	WebElement fixPriceLabel;
	
	@FindBy(xpath = "(//td[contains(@class,'x-grid-cell-special x-grid-cell-row-checker')])[1]/following::td[19]")
	WebElement priceFixationText;
	
	/*New Price Fixation*/
	
	@FindBy(xpath = "//input[contains(@name,'qtyFixed')]")
	WebElement quantityFixedEnter;
	
	@FindBy(xpath = "//select[contains(@id,'pricablemonthslistId')]")
	WebElement futureMonth;
	
	
	@FindBy(xpath = "//input[@name='futuresPrice']")
	WebElement futurePriceEnter;
	
	@FindBy(xpath = "//input[@name='fxRateBasisToPayIn']")
	WebElement FXBasisToPayInEnter;
	
	
	@FindBy(xpath = "//input[@name='Save']")
	WebElement priceFixationSave;
	
	@FindBy(xpath = "(//th[contains(text(),'Price Fix Ref. No.')]/../following::tr/td)[5]")
	WebElement priceFixationRefNo;
	
	@FindBy(xpath = "//input[@name='ok']")
	WebElement priceFixationOk;
	
	@FindBy(xpath = "(//th[contains(text(),'Price Specifications')]/../following::tr/td)[4]")
	WebElement totalQuantityToFix;
	
	
	// Initializing the Page Objects:
	public NewContractFixPricePage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	/*Utilizations*/
	
	public WebElement getPhysicalsLabel() {
		return physicalsLabel;
	}


	public WebElement getContractMainFilter() {
		return ContractMainFilter;
	}

	public WebElement getFilterSearchSelect() {
		return filterSearchSelect;
	}


	public WebElement getFilterSearchInput() {
		return filterSearchInput;
	}


	public WebElement getFilterGo() {
		return filterGo;
	}


	public WebElement getContractItemsCheckBox() {
		return contractItemsCheckBox;
	}


	public WebElement getContractOperationsHeader() {
		return contractOperationsHeader;
	}


	public WebElement getFixPriceLabel() {
		return fixPriceLabel;
	}

	public WebElement getPriceFixationText() {
		return priceFixationText;
	} 
	
	/*New Price Fixation*/
	
	public WebElement getQuantityFixedEnter() {
		return quantityFixedEnter;
	}

	public WebElement getFuturePriceEnter() {
		return futurePriceEnter;
	}

	public WebElement getFXBasisToPayInEnter() {
		return FXBasisToPayInEnter;
	}

	public WebElement getPriceFixationSave() {
		return priceFixationSave;
	}

	public WebElement getPriceFixationRefNo() {
		return priceFixationRefNo;
	}

	public WebElement getPriceFixationOk() {
		return priceFixationOk;
	}

	public WebElement getTotalQuantityToFix() {
		return totalQuantityToFix;
	}

	public WebElement getFutureMonth() {
		return futureMonth;
	}

	
	
}
