package com.qa.pages.Logistics;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.qa.base.TestBaseListener;
public class NewPlannedContainerShipmentPage {
	/*Under Shipment planning page*/
	
	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement activityDate ; 
	
	@FindBy(xpath = "//span[text()='Today' and @unselectable='on']")
	@CacheLookup
	WebElement activityDateToday ; 
	
	
	
	
	@FindBy(xpath = "(//td[contains(@id,'productComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement productArrow;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	@CacheLookup
	WebElement productSelect;
	
	@FindBy(xpath = "(//td[contains(@id,'originComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement originArrow;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	@CacheLookup
	WebElement originSelect;
	
	
	@FindBy(xpath = "(//td[contains(@id,'cropyearComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement cropYearArrow;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[3])")
	@CacheLookup
	WebElement cropYearSelect;
	
	@FindBy(xpath = "(//td[contains(@id,'qualityComboId')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement qualityArrow;

	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[4])")
	@CacheLookup
	WebElement qualitySelect;
	
	
	@FindBy(xpath = "(//td[contains(text(),'CP Name')]/following-sibling::td//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement cpName;

	@FindBy(xpath = "(//div[contains(@class,'x-boundlist x-boundlist-floating x-layer x-boundlist-default x-border-box')]//div//ul)[5]")
	@CacheLookup
	WebElement cpNameSelect;
	
	@FindBy(xpath = "//input[contains(@id,'plannedQty')]")
	@CacheLookup
	WebElement plannedQtyEnter;
	
	@FindBy(xpath = "//select[contains(@id,'plannedQtyUnitId')]")
	@CacheLookup
	WebElement plannedQtySelect;
	
	/*Voyage Details*/
	
	@FindBy(xpath = "//input[contains(@id,'noOfPlannedContainers')]")
	@CacheLookup
	WebElement noOfContainerEnter;
	
	@FindBy(xpath = "//select[contains(@id,'shippingLineProfileId')]")
	@CacheLookup
	WebElement shippingLineSelect;
	
	@FindBy(xpath = "(//td[contains(@id,'loadingPortComboId')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement loadPortArrow;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[6])")
	@CacheLookup
	WebElement loadPortSelect;
	
	@FindBy(xpath = "(//td[contains(@id,'dischargePortComboId')]/following-sibling::td//div[contains(@class,' x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement dischargePortArrow;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[7])")
	@CacheLookup
	WebElement dischargePortSelect;
	
	@FindBy(xpath = "//input[@value='Save']")  
	WebElement shipmentPlanSave;
	
	/*Manage Allocations Page 2nd Page*/
	
	@FindBy(xpath = "//select[contains(@id,'containerStuffingTypeId')]")
	@CacheLookup
	WebElement containerStufftype;
	
	@FindBy(xpath = "(//td[contains(@id,'expectedSourceLocationComboId')]/following-sibling::td//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement expectSourceLocArrow;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	@CacheLookup
	WebElement expectSourceLocSelect;
	
	@FindBy(xpath = "(//div[contains(@class,'x-form-date-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement expDateOfPickUp ; 
	
	 /*adding sales call off no*/
	@FindBy(xpath = "(//td[contains(@id,'copdComboId')]/following-sibling::td//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement saleCallOffNoArrow ; 
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[2])")
	@CacheLookup
	WebElement saleCallOffNoSelect;
	
	@FindBy(id = "addCallOffDetailsId")
	@CacheLookup
	WebElement addCallOffDetailsId;
	
	@FindBy(xpath = "//div[contains(@id,'PanelContainerShipmentManageAllocationsButtonsContent')]//input[contains(@id,'saveBtnManageAllocationId')]")  
	@CacheLookup
	WebElement ContainerShipmentSave;
	
	
	/*Cost Estimates -shipment 3rd page*/
	
	@FindBy(xpath = "//select[@name='costComponentId']")
	@CacheLookup
	WebElement costCompName;
	
	
	@FindBy(xpath = "//select[contains(@id,'costIncExp')]")
	@CacheLookup
	WebElement incomeExpence;
	
	@FindBy(xpath = "(//td[contains(text(),'CP Name')]/following-sibling::td//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement cpNameCostEstimateArrow;

	@FindBy(xpath = "(//div[contains(@class,'x-boundlist x-boundlist-floating x-layer x-boundlist-default x-border-box')]//div//ul)[1]")
	@CacheLookup
	WebElement cpNameCostEstimateSelect;
	
	@FindBy(xpath = "//select[@name='rateType']")
	@CacheLookup
	WebElement rateTypeSelect;
	
	@FindBy(xpath = "//select[@name='costValueUnit']/preceding::input[contains(@id,'costValue')]")
	@CacheLookup
	WebElement costValueEnter;

	@FindBy(xpath = "//td[contains(text(),'Cost Value')]/following::td//select[@name='costValueUnit']")
	@CacheLookup
	WebElement costValueUnitSelect;
	
	@FindBy(xpath = "//input[contains(@name,'fxToBase')]")
	@CacheLookup
	WebElement fxToBase;

	@FindBy(xpath = "//select[@name='weightBasis']")
	@CacheLookup
	WebElement costApplicableSelect;
	
	@FindBy(xpath = "//input[@id='AddOnId']")
	@CacheLookup
	WebElement costEstimateAdd;
	
	
	@FindBy(xpath = "//input[contains(@id,'saveaccrualPLAN_TAB')]")  
	@CacheLookup
	WebElement costEstimateSave;
	
	/*Add additions/Deductions tab in container shipment*/
	
	@FindBy(xpath = "//select[contains(@id,'contractItemIdPLAN_TAB')]")  
	@CacheLookup
	WebElement contractItemSelect;
	
	
	@FindBy(xpath = "(//td[contains(text(),'Add/Ded Name')]/following-sibling::td//table//div[contains(@class,'x-form-arrow-trigger x-form-trigger-first')])[1]")
	@CacheLookup
	WebElement addDeleteNameArrow;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")  
	@CacheLookup
	WebElement addDeleteNameSelect;
	
	@FindBy(xpath = "//select[contains(@name,'addDedDTO.addDedType')]")
	@CacheLookup
	WebElement addDelete;
	
	@FindBy(xpath = "//select[contains(@name,'addDedDTO.rateType')]")
	@CacheLookup
	WebElement rateType;
	
	
	@FindBy(xpath = "(//td[contains(text(),'Rate')]/following::td/input[@name='addDedDTO.costValue'])")
	@CacheLookup
	WebElement rateEnter;

	@FindBy(xpath = "//select[contains(@name,'addDedDTO.costValueUnit')]")
	@CacheLookup
	WebElement rateSelect;
	

	@FindBy(xpath = "//select[contains(@name,'addDedDTO.wtBasisType')]")
	@CacheLookup
	WebElement weightBasis;

	@FindBy(xpath = "//textarea[contains(@name,'remarksId')]")
	@CacheLookup
	WebElement addRemarks;

	@FindBy(xpath = "//input[contains(@id,'addDedRow')]")
	@CacheLookup
	WebElement addDedRowButton;
	
	@FindBy(xpath = "//input[contains(@name,'saveAddDedId')]")  
	@CacheLookup
	WebElement addDedRowButtonSave;
	
	/*Summary Page*/
	
	
	@FindBy(xpath = "(//th[contains(text(),'PCS Ref. No.')]/../following::tr/td)[1]")  
	@CacheLookup
	WebElement PCFRefNo;
	
	@FindBy(xpath = "//input[contains(@value,'Ok')]")  
	@CacheLookup
	WebElement summaryOk;
	
	@FindBy(xpath = "//td[contains(text(),'Origin ')]")
	@CacheLookup
	WebElement originLabelClick;
	

	
	// Initializing the Page Objects:
	public NewPlannedContainerShipmentPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}
	
	//utilization

	public WebElement getActivityDate() {
		return activityDate;
	}

	public WebElement getProductArrow() {
		return productArrow;
	}

	public WebElement getProductSelect() {
		return productSelect;
	}

	public WebElement getOriginLabelClick() {
		return originLabelClick;
	}

	public WebElement getOriginArrow() {
		return originArrow;
	}

	public WebElement getOriginSelect() {
		return originSelect;
	}

	public WebElement getCropYearArrow() {
		return cropYearArrow;
	}

	public WebElement getCropYearSelect() {
		return cropYearSelect;
	}

	public WebElement getQualityArrow() {
		return qualityArrow;
	}

	public WebElement getQualitySelect() {
		return qualitySelect;
	}

	public WebElement getCpName() {
		return cpName;
	}

	public WebElement getCpNameSelect() {
		return cpNameSelect;
	}

	public WebElement getPlannedQtyEnter() {
		return plannedQtyEnter;
	}

	public WebElement getPlannedQtySelect() {
		return plannedQtySelect;
	}

	public WebElement getNoOfContainerEnter() {
		return noOfContainerEnter;
	}

	public WebElement getShippingLineSelect() {
		return shippingLineSelect;
	}

	public WebElement getLoadPortArrow() {
		return loadPortArrow;
	}

	public WebElement getLoadPortSelect() {
		return loadPortSelect;
	}

	public WebElement getDischargePortArrow() {
		return dischargePortArrow;
	}

	public WebElement getDischargePortSelect() {
		return dischargePortSelect;
	}

	public WebElement getShipmentPlanSave() {
		return shipmentPlanSave;
	}

	public WebElement getContainerStufftype() {
		return containerStufftype;
	}

	public WebElement getExpectSourceLocArrow() {
		return expectSourceLocArrow;
	}

	public WebElement getExpectSourceLocSelect() {
		return expectSourceLocSelect;
	}

	public WebElement getExpDateOfPickUp() {
		return expDateOfPickUp;
	}

	public WebElement getSaleCallOffNoArrow() {
		return saleCallOffNoArrow;
	}

	public WebElement getSaleCallOffNoSelect() {
		return saleCallOffNoSelect;
	}

	public WebElement getAddCallOffDetailsId() {
		return addCallOffDetailsId;
	}

	public WebElement getContainerShipmentSave() {
		return ContainerShipmentSave;
	}

	public WebElement getCostCompName() {
		return costCompName;
	}

	public WebElement getIncomeExpence() {
		return incomeExpence;
	}

	public WebElement getCpNameCostEstimateArrow() {
		return cpNameCostEstimateArrow;
	}

	public WebElement getCpNameCostEstimateSelect() {
		return cpNameCostEstimateSelect;
	}

	public WebElement getRateTypeSelect() {
		return rateTypeSelect;
	}

	public WebElement getCostValueEnter() {
		return costValueEnter;
	}

	public WebElement getCostValueUnitSelect() {
		return costValueUnitSelect;
	}

	public WebElement getFxToBase() {
		return fxToBase;
	}

	public WebElement getCostApplicableSelect() {
		return costApplicableSelect;
	}

	public WebElement getCostEstimateAdd() {
		return costEstimateAdd;
	}

	public WebElement getCostEstimateSave() {
		return costEstimateSave;
	}

	public WebElement getContractItemSelect() {
		return contractItemSelect;
	}

	public WebElement getAddDeleteNameArrow() {
		return addDeleteNameArrow;
	}

	public WebElement getAddDeleteNameSelect() {
		return addDeleteNameSelect;
	}

	public WebElement getAddDelete() {
		return addDelete;
	}

	public WebElement getRateType() {
		return rateType;
	}

	public WebElement getRateEnter() {
		return rateEnter;
	}

	public WebElement getRateSelect() {
		return rateSelect;
	}

	public WebElement getWeightBasis() {
		return weightBasis;
	}

	public WebElement getAddRemarks() {
		return addRemarks;
	}

	public WebElement getAddDedRowButton() {
		return addDedRowButton;
	}

	public WebElement getAddDedRowButtonSave() {
		return addDedRowButtonSave;
	}

	public WebElement getPCFRefNo() {
		return PCFRefNo;
	}

	public WebElement getSummaryOk() {
		return summaryOk;
	}

	public WebElement getActivityDateToday() {
		return activityDateToday;
	} 
	
	
}
