
package com.qa.pages.Derivatives;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBaseListener;

/**
 * @author jaganmohan.k
 *
 */
public class NewExchangeOptionPage {

	/*Option Contract Details*/
	@FindBy(xpath = "//input[contains(@id,'derivativeTradeDO_derivativeRefNo')]")
	@CacheLookup
	WebElement  tradeRefNo;
	
	@FindBy(xpath = "//input[contains(@name,'externalTradeRefNo')]")
	@CacheLookup
	WebElement externalTradeRefNo;

	@FindBy(xpath = "//td[contains(text(),'Trade Date')]/following-sibling::td/div[contains(@id,'tradeDateDIVID')]/..//div[contains(@class,'x-form-date-trigger x-form-trigger-first')]")
	@CacheLookup
	WebElement tradeDate; 
	
	@FindBy(id = "traderId")
	WebElement trader;
	
	@FindBy(id = "exchangeInstrument")
	WebElement exchangeInstrument;
	
	@FindBy(id ="deliveryManualPerType")
	WebElement promptDeliveryDetailsType;

	@FindBy(id = "deliveryManualPerName")
	WebElement promptDeliveryDetailsName;
	
	@FindBy(id = "tradeType")
	WebElement tradeType;

	@FindBy(id = "lotSizeId")
	WebElement lotSize;

	@FindBy(xpath = "//input[contains(@type,'text') and contains(@name,'derivativeTradeDO.lots')]")
	WebElement quantity_Input;

	@FindBy(id = "settlementCurrUnitId")
	WebElement settlementCurrency;
	
	@FindBy(xpath = "//input[contains(@type,'text') and contains(@name,'derivativeTradeDO.strikePrice')]")
	WebElement strikePrice;
	
	@FindBy(id = "strikePriceUnitId")
	WebElement strikePriceUnitId;
	
	@FindBy(id = "derivativeTradeDO.premiumDiscount")
	WebElement premiumDiscount;
	
	@FindBy(id = "premiumDiscountPriceUnitId")
	WebElement premiumDiscountPriceUnit;

	@FindBy(id = "clearerProfileId")
	WebElement clearerProfileId;

	@FindBy(id = "clearerAccountId")
	WebElement clearerAccountId;
	
	@FindBy(id = "clearerCommTypeId")
	WebElement clearerCommType;
	
	@FindBy(id = "//*[@id='brokerProfileId']")
	WebElement broker;
	
	@FindBy(id = "brokerCommTypeId")
	WebElement brokerCommType;

	/*Internal Module*/
	@FindBy(id = "profitCenterId")
	WebElement profitCenterId;

	@FindBy(id = "strategyId")
	WebElement strategyId;
	
	@FindBy(id = "purposeId")
	WebElement purposeId;
	
	@FindBy(xpath = "((//div[contains(@class,'boundlist-')]//div//ul)[1])")
	@CacheLookup
	WebElement selectnominee; 
	
	@FindBy(xpath = "//div[contains(@class,'trigger x-form-arrow-trigger x-form-trigger-first')]")
	WebElement nomineearrow;
	
	@FindBy(id = "create")
	WebElement createButton;

	@FindBy(xpath = "(//td[contains(text(),'Trade Ref. No.')]/following::td)[1]")
	WebElement createdTradeRefNo;

	@FindBy(xpath = "//input[@value='Ok' and @type='button']")
	WebElement ok_button;

	// Initializing the Page Objects:
	public NewExchangeOptionPage() {
		PageFactory.initElements(TestBaseListener.getDriver(), this);
	}

	public String validateLoginPageTitle(){
		return TestBaseListener.getDriver().getTitle();
	}

	/**
	 * @return the tradeRefNo
	 */
	public WebElement getTradeRefNo() {
		return tradeRefNo;
	}

	/**
	 * @return the externalTradeRefNo
	 */
	public WebElement getExternalTradeRefNo() {
		return externalTradeRefNo;
	}

	/**
	 * @return the tradeDate
	 */
	public WebElement getTradeDate() {
		return tradeDate;
	}

	/**
	 * @return the trader
	 */
	public WebElement getTrader() {
		return trader;
	}

	/**
	 * @return the exchangeInstrument
	 */
	public WebElement getExchangeInstrument() {
		return exchangeInstrument;
	}

	/**
	 * @return the promptDeliveryDetailsType
	 */
	public WebElement getPromptDeliveryDetailsType() {
		return promptDeliveryDetailsType;
	}

	/**
	 * @return the promptDeliveryDetailsName
	 */
	public WebElement getPromptDeliveryDetailsName() {
		return promptDeliveryDetailsName;
	}

	/**
	 * @return the tradeType
	 */
	public WebElement getTradeType() {
		return tradeType;
	}

	/**
	 * @return the lotSize
	 */
	public WebElement getLotSize() {
		return lotSize;
	}

	/**
	 * @return the quantity_Input
	 */
	public WebElement getQuantity_Input() {
		return quantity_Input;
	}

	/**
	 * @return the settlementCurrency
	 */
	public WebElement getSettlementCurrency() {
		return settlementCurrency;
	}

	/**
	 * @return the strikePrice
	 */
	public WebElement getStrikePrice() {
		return strikePrice;
	}

	/**
	 * @return the strikePriceUnitId
	 */
	public WebElement getStrikePriceUnitId() {
		return strikePriceUnitId;
	}

	/**
	 * @return the premiumDiscount
	 */
	public WebElement getPremiumDiscount() {
		return premiumDiscount;
	}

	/**
	 * @return the premiumDiscountPriceUnit
	 */
	public WebElement getPremiumDiscountPriceUnit() {
		return premiumDiscountPriceUnit;
	}

	/**
	 * @return the clearerProfileId
	 */
	public WebElement getClearerProfileId() {
		return clearerProfileId;
	}

	/**
	 * @return the clearerAccountId
	 */
	public WebElement getClearerAccountId() {
		return clearerAccountId;
	}

	/**
	 * @return the clearerCommType
	 */
	public WebElement getClearerCommType() {
		return clearerCommType;
	}

	/**
	 * @return the broker
	 */
	public WebElement getBroker() {
		return broker;
	}

	/**
	 * @return the brokerCommType
	 */
	public WebElement getBrokerCommType() {
		return brokerCommType;
	}

	/**
	 * @return the profitCenterId
	 */
	public WebElement getProfitCenterId() {
		return profitCenterId;
	}

	/**
	 * @return the strategyId
	 */
	public WebElement getStrategyId() {
		return strategyId;
	}

	/**
	 * @return the purposeId
	 */
	public WebElement getPurposeId() {
		return purposeId;
	}

	/**
	 * @return the selectnominee
	 */
	public WebElement getSelectnominee() {
		return selectnominee;
	}

	/**
	 * @return the nomineearrow
	 */
	public WebElement getNomineearrow() {
		return nomineearrow;
	}

	/**
	 * @return the createButton
	 */
	public WebElement getCreateButton() {
		return createButton;
	}

	/**
	 * @return the createdTradeRefNo
	 */
	public WebElement getCreatedTradeRefNo() {
		return createdTradeRefNo;
	}

	/**
	 * @return the ok_button
	 */
	public WebElement getOk_button() {
		return ok_button;
	}
}
