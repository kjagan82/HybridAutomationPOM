package com.qa.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.qa.base.TestBaseListener;

/**
 * @author jaganmohan.k
 *
 */
public class TestDataUtil {

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	//private static XSSFRow Row;
	static Workbook book;
	static Sheet sheet;


	//This method is to set the File path and to open the Excel file, Pass Excel Path and Sheetname as Arguments to this method

	public static void setExcelFile(String Path) throws Exception {

		try {
			// Open the Excel file
			FileInputStream ExcelFile = new FileInputStream(Path);
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			//ExcelWSheet = ExcelWBook.getSheet("Sheet1");
			ExcelWSheet = ExcelWBook.getSheetAt(0);
		} catch (Exception e){
			throw (e);
		}

	}

	public static Object[][] getTestData(String FileName,String SheetName,String testMethodName)throws Exception

	{   
		String[][] tabArray = null;
		String TESTDATA_FILE_PATH= System.getProperty("user.dir")+"\\src\\main\\java\\com\\qa\\testdata\\";
		if(FileName == null || FileName.trim().equals("") || SheetName == null || SheetName.trim().equals("") || testMethodName == null || testMethodName.trim().equals("")) {
			throw new IllegalArgumentException("File Name or SheetName or methodName should not be emtpty !!!");
		}
		try{
			
			TESTDATA_FILE_PATH=TESTDATA_FILE_PATH+FileName;
			FileInputStream ExcelFile = new FileInputStream(TESTDATA_FILE_PATH);
			// Access the required test data sheet
			ExcelWBook = new XSSFWorkbook(ExcelFile);
			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			//ExcelWSheet = ExcelWBook.getSheetAt(0);
			int iTestCaseRow=getRowContains(testMethodName,0);
			 int startCol = 1;
			   int ci=0,cj=0;
			   int totalRows = 1;
			   int totalCols = ExcelWSheet.getRow(totalRows).getLastCellNum()-1;
			   tabArray=new String[totalRows][totalCols];
				   for (int j=startCol;j<=totalCols;j++, cj++)
				   {
					   tabArray[ci][cj]=getCellData(iTestCaseRow,j);
					   //TestBaseListener.suite_logs.info(tabArray[ci][cj]);
				   }
			}
		catch (FileNotFoundException e)
		{
			TestBaseListener.suite_logs.info("Could not read the Excel sheet");
			TestBaseListener.suite_logs.error("ERROR : Could not read the Excel sheet. Following exception occurred: " + e.getMessage());
		}
		catch (IOException e)
		{
			TestBaseListener.suite_logs.info("Could not read the Excel sheet");
			TestBaseListener.suite_logs.error("ERROR : Could not read the Excel sheet. Following exception occurred: " + e.getMessage());
		}
		return(tabArray);

	}

	//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num

	/**
	 * @param RowNum
	 * @param ColNum
	 * @return
	 * @throws Exception
	 */
	public static String getCellData(int RowNum, int ColNum) throws Exception{
		try{
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			String CellData = Cell.getStringCellValue();
			return CellData;
		}catch (Exception e){
			TestBaseListener.suite_logs.info("Please change integer to string in data file");
			TestBaseListener.suite_logs.error("ERROR : Please change integer to string in data file. Following exception occurred: " + e.getMessage());
			return "";
		}

	}

	public static String getTestCaseName(String sTestCase)throws Exception{

		String value = sTestCase;

		try{
			int posi = value.indexOf("@");
			value = value.substring(0, posi);
			posi = value.lastIndexOf(".");	
			value = value.substring(posi + 1);
			return value;
		}catch (Exception e){
			throw (e);
		}

	}

	public static int getRowContains(String sTestCaseName, int colNum) throws Exception{

		int i;

		try {
			int rowCount = TestDataUtil.getRowUsed();
			for ( i=0 ; i<rowCount; i++){
				if  (TestDataUtil.getCellData(i,colNum).equalsIgnoreCase(sTestCaseName)){
					break;
				}
			}

			return i;
		}catch (Exception e){
			throw(e);
		}
	}

	/**
	 * @return
	 * @throws Exception
	 */
	public static int getRowUsed() throws Exception {

		try{
			int RowCount = ExcelWSheet.getLastRowNum();
			return RowCount;
		}catch (Exception e){
			TestBaseListener.suite_logs.info(e.getMessage());
			throw (e);
		}
	}
}
