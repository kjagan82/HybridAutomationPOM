package com.qa.util;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.qa.base.TestBaseListener;

import net.jmatrix.eproperties.EProperties;

/**
 * @author jaganmohan.k
 *
 */
public abstract class SeleniumLibs {


	WebElement e = null;
	public static final String FILE_UPLOAD_SCRIPT_PATH = System.getProperty("user.dir")+"\\Library\\Selenium\\FileUploadScript.exe";
	public static final String DATA_FILES_LOC = System.getProperty("user.dir")+ "\\src\\main\\java\\com\\qa\\testdata\\";
	public static final String RESULTFILEPATH=System.getProperty("user.dir")+ "\\\\src\\\\main\\\\java\\\\com\\\\qa\\\\config\\\\results.properties";
	/**
	 * @param element
	 */
	public static void clickUsingJavaScript(WebElement element) {
		try {
			TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			JavascriptExecutor js = (JavascriptExecutor)TestBaseListener.getDriver();
			highLightElement(element);
			js.executeScript("arguments[0].click();", element);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			TestBaseListener.suite_logs.error("ERROR : Couldn't click the specified field. Following exception occurred: " + e.getMessage());
		}
	}

	public static String selectDate(int days) {
		//0 for Today's date and positive(5) value for future date and Negative value for past date(-5)
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		SimpleDateFormat sdf = new SimpleDateFormat("dd");
		Calendar c = Calendar.getInstance();
		c.setTime(new Date()); // Now use today date.
		c.add(Calendar.DATE,days); 
		return sdf.format(c.getTime());
	}
	
	public static String selectDate(String dd_MMM_yyyy) throws ParseException {
		//Supports "20-Nov-2018" format 
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
		Date date1 = sdf.parse(dd_MMM_yyyy);
		Calendar c = Calendar.getInstance();
		c.setTime(date1); 
		return sdf.format(c.getTime());
	}

	public static void navigateTo(String url) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.getDriver().navigate().to(url);
	}
	
	public static void navigateToHomePage() {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.getDriver().navigate().to(TestBaseListener.url);
	}
	
	public static String getStoredResultsfromFile(String key) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		EProperties results = new EProperties();
		String res = null;
		FileReader reader=null;
		try {
			reader = new FileReader(RESULTFILEPATH);
			results.load(reader);
			res=results.getProperty(key);
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return res;
	}
	/**
	 * @param key
	 * @param value
	 */
	public static void storeResultsinFile(String key,String value) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		EProperties results = new EProperties();
		FileReader reader;
		try {
			reader = new FileReader(RESULTFILEPATH);
			results.load(reader);
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		results.setProperty(key,value);
		FileWriter writer;
		try {
			writer = new FileWriter(RESULTFILEPATH);
			results.store(writer, null);
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Element high lighter code
	public static void highLightElement(WebElement element){

		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		JavascriptExecutor js = (JavascriptExecutor)TestBaseListener.getDriver();
		js.executeScript("arguments[0].setAttribute('style', 'background: yellow; border: 2px solid red;');", element);
		try {
			Thread.sleep(500);
		} catch (Exception e) {
			TestBaseListener.suite_logs.error("ERROR : Couldn't highLightElement the field. Following exception occurred: " + e.getMessage());
		} 
		js.executeScript("arguments[0].setAttribute('style','border: solid 2px white');", element); 
	}


	public static void scrollUsingJavaScript(WebElement element) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			JavascriptExecutor js = (JavascriptExecutor)TestBaseListener.getDriver();
			js.executeScript("arguments[0].scrollIntoView();", element);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : Couldn't scrollUsingJavaScript. Following exception occurred: " + e.getMessage());
		}
	}

	public void staticWait(int time) {
		try {
			TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			//give time in seconds
			Thread.sleep(time*1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in staticWait. Following exception occurred: " + e.getMessage());
		}
	}

	/**
	 * @param element
	 * @param text
	 */
	public void selectDateFromDatePicker(WebElement element,String text){

		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			scrollUsingJavaScript(element);
			waitElementClickable(element);
			highLightElement(element);
			element.click();
			List<WebElement> allDates=TestBaseListener.getDriver().findElements(By.xpath("//table[@class='x-datepicker-inner']//td"));
			for(WebElement ele:allDates){
				String date=ele.getText();
				if(date.equalsIgnoreCase(text))	{
					waitElementClickable(ele);
					Thread.sleep(500);
					ele.click();
					break;
				}

			}
			staticWait(1);
			clickUsingJavaScript(element);
			//element.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in selectDateFromDatePicker. Following exception occurred: " + e.getMessage());
		}
		//element.click();
	} 

	public static void waitForAjax() {

		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			JavascriptExecutor jsDriver = (JavascriptExecutor) TestBaseListener.getDriver();
			for (int i = 0; i < TestBaseListener.AJAX_WAIT; i++) {
				boolean ajaxCallsInProgress = (boolean) jsDriver.executeScript("return Ext.Ajax.isLoading()");
				if (ajaxCallsInProgress) {
					Assert.assertTrue(true, "ajax calls are going on... can't proceed :( ---------");
					Thread.sleep(1000);
				}
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in waitForAjax. Following exception occurred: " + e.getMessage());
		}
	}



	/**
	 * @param element
	 * @param text
	 */
	public void enterText(WebElement element,String text) {

		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			scrollUsingJavaScript(element);
			waitElementClickable(element);
			element.clear();
			highLightElement(element);
			element.sendKeys(text);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in enterText. Following exception occurred: " + e.getMessage());
		}

	}

	/**
	 * @param element
	 */
	public  void doubleClick(WebElement element) {

		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			if (element == null) {
				Assert.fail("Element to be clicked is not specified");
			}
			scrollUsingJavaScript(element);
			waitElementClickable(element);
			highLightElement(element);
			TestBaseListener.actions.moveToElement(element).doubleClick().perform();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in doubleClick(). Following exception occurred: " + e.getMessage());
		}
	} 

	/**
	 * @param element
	 */
	public  void click(WebElement element) {

		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			if (element == null) {
				Assert.fail("Element to be clicked is not specified");
			}
			scrollUsingJavaScript(element);
			waitElementClickable(element);
			highLightElement(element);
			TestBaseListener.actions.moveToElement(element).click().build().perform();
			//element.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in click(). Following exception occurred: " + e.getMessage());
		}
	} 


	/**
	 * @param element
	 * @param index
	 */
	public void selectDropDownByIndex(WebElement element,int index){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			scrollUsingJavaScript(element);
			try {
				Select dropdown= new Select(element);
				dropdown.selectByIndex(index);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in selectDropDownByIndex(). Following exception occurred: " + e.getMessage());
		}
	} 
	public void selectDropDownByText(WebElement element,String text){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			scrollUsingJavaScript(element);
			try {
				waitElementClickable(element);
				Select dropdown= new Select(element);
				dropdown.selectByVisibleText(text);
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in selectDropDownByText(). Following exception occurred: " + e.getMessage());
		}
	}


	private static void waitElementClickable(WebElement element) {

		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.getDriver().manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			TestBaseListener.suite_logs.debug("*Internal call* Waiting till element is clickable");
			TestBaseListener.wait = new WebDriverWait(TestBaseListener.getDriver(), 30);
			TestBaseListener.wait.until(ExpectedConditions.elementToBeClickable(element));
			TestBaseListener.suite_logs.debug("*Internal call* Wait is over ! Click the element now !");
		}catch (NoSuchElementException | StaleElementReferenceException nsee) {
			TestBaseListener.suite_logs.error("*Internal call* Couldn't verify element's clickability. Element Not Present:");
		}catch (Exception e) {
			TestBaseListener.suite_logs.error("*Internal call* Couldn't verify element's clickability. Following exception occurred: "+e);
		} 
	}

	/**
	 * @param dd_arrow_trigger
	 * @param dd_ul_prop_name
	 * @param text
	 */
	public void selectSingleListAndItem(WebElement dd_arrow_trigger,WebElement dd_ul_prop_name,String text) {

		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			highLightElement(dd_arrow_trigger);
			scrollUsingJavaScript(dd_arrow_trigger);
			//Click Arrow first 
			waitElementClickable(dd_arrow_trigger);
			dd_arrow_trigger.click();
			staticWait(2);
			List<WebElement> countriesList=dd_ul_prop_name.findElements(By.tagName("li"));
			for (WebElement li : countriesList) {
				if (li.getText().equals(text)) {
					waitElementClickable(li);
					li.click();
					break;
				}
			}
			//dd_arrow_trigger.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in selectSingleListAndItem(). Following exception occurred: " + e.getMessage());
		}
	}

	/**
	 * @param dd_arrow_trigger
	 * @param dd_ul_prop_name
	 * @param index
	 */
	public void selectSingleListAndItemByIndex(WebElement dd_arrow_trigger,WebElement dd_ul_prop_name,String index) {

		try {
			TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			highLightElement(dd_arrow_trigger);
			scrollUsingJavaScript(dd_arrow_trigger);
			//Click Arrow first 
			waitElementClickable(dd_arrow_trigger);
			dd_arrow_trigger.click();
			staticWait(2);
			List<WebElement> countriesList=dd_ul_prop_name.findElements(By.tagName("li"));
			/*for (WebElement li : countriesList) {
				System.out.println("\n UL List::"+countriesList);
			}*/
			//converting String to primitive type
			int position = Integer.parseInt(index);
			WebElement li=countriesList.get(position);
			waitElementClickable(li);
			li.click();

			//dd_arrow_trigger.click();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in selectSingleListAndItemByIndex(). Following exception occurred: " + e.getMessage());
		}
	}

	public void mouseOver(WebElement element) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			TestBaseListener.suite_logs.debug("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			highLightElement(element);
			Actions action = new Actions(TestBaseListener.getDriver());
			action.moveToElement(element).build().perform();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in mouseOver(). Following exception occurred: " + e.getMessage());
		}
	}

	public void mouseHoverJScript(WebElement HoverElement) {
		try {
			TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			if (isElementPresent(HoverElement)) {

				String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover', true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
				((JavascriptExecutor)TestBaseListener.getDriver()).executeScript(mouseOverScript,HoverElement);
				Thread.sleep(200);
			} else {
				TestBaseListener.suite_logs.debug("Element was not visible to hover " + "\n");

			}
		} catch (StaleElementReferenceException e) {
			TestBaseListener.suite_logs.error("Element with " + HoverElement+ "is not attached to the page document"+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			TestBaseListener.suite_logs.error("Element " + HoverElement + " was not found in DOM"+ e.getStackTrace());
		} catch (Exception e) {
			e.printStackTrace();
			TestBaseListener.suite_logs.error("Error occurred while hovering"+ e.getStackTrace());
		}
	}
	
	public static boolean isElementPresent(WebElement element) {
		boolean flag = false;
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			if (element.isDisplayed()|| element.isEnabled())
				flag = true;
		} catch (NoSuchElementException e) {
			flag = false;
		} catch (StaleElementReferenceException e) {
			flag = false;
		}
		return flag;
	}

	public void clickMouseOverAndClick(WebElement ClickElement,WebElement mouseOver1,WebElement mouseOver2,WebElement mouseOver3,WebElement mouseOver4) {
		try {
			TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			click(ClickElement);
			if(mouseOver1!=null && mouseOver2!=null && mouseOver3!=null && mouseOver4!=null) {
				TestBaseListener.actions.moveToElement(mouseOver1).moveToElement(mouseOver2).moveToElement(mouseOver3).moveToElement(mouseOver4).build().perform();
				click(mouseOver4);
			}else if(mouseOver1!=null && mouseOver2!=null && mouseOver3!=null && mouseOver4==null) {
				TestBaseListener.actions.moveToElement(mouseOver1).moveToElement(mouseOver2).moveToElement(mouseOver3).build().perform();
				click(mouseOver3);
			}else if(mouseOver1!=null && mouseOver2!=null && mouseOver3==null) {
				TestBaseListener.actions.moveToElement(mouseOver1).moveToElement(mouseOver2).build().perform();
				click(mouseOver2);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in clickMouseOverAndClick(). Following exception occurred: " + e.getMessage());
		}
	}

	/**
	 * @param element
	 * @return
	 */
	public String getText(WebElement element){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		highLightElement(element);
		return element.getText();
	}

	/**
	 * @param enterText
	 * @param dd_arrow_trigger
	 * @param dd_ul_prop_name
	 * @param text
	 */
	public void selectSubSingleListAndItem(WebElement enterText,WebElement dd_arrow_trigger,WebElement dd_ul_prop_name,String text){
		try {
			TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
			enterText(enterText, text);
			selectSingleListAndItem( dd_arrow_trigger,dd_ul_prop_name,text);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			TestBaseListener.suite_logs.error("ERROR : in selectSubSingleListAndItem(). Following exception occurred: " + e.getMessage());
		}

	}

	/**
	 * @param LocatorFrom
	 * @param LocatorTo
	 */
	public void dragdrop(WebElement LocatorFrom, WebElement LocatorTo) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		String xto=Integer.toString(LocatorTo.getLocation().x);
		String yto=Integer.toString(LocatorTo.getLocation().y);
		((JavascriptExecutor)TestBaseListener.getDriver()).executeScript("function simulate(f,c,d,e){var b,a=null;for(b in eventMatchers)if(eventMatchers[b].test(c)){a=b;break}if(!a)return!1;document.createEvent?(b=document.createEvent(a),a==\"HTMLEvents\"?b.initEvent(c,!0,!0):b.initMouseEvent(c,!0,!0,document.defaultView,0,d,e,d,e,!1,!1,!1,!1,0,null),f.dispatchEvent(b)):(a=document.createEventObject(),a.detail=0,a.screenX=d,a.screenY=e,a.clientX=d,a.clientY=e,a.ctrlKey=!1,a.altKey=!1,a.shiftKey=!1,a.metaKey=!1,a.button=1,f.fireEvent(\"on\"+c,a));return!0} var eventMatchers={HTMLEvents:/^(?:load|unload|abort|error|select|change|submit|reset|focus|blur|resize|scroll)$/,MouseEvents:/^(?:click|dblclick|mouse(?:down|up|over|move|out))$/}; " +
				"simulate(arguments[0],\"mousedown\",0,0); simulate(arguments[0],\"mousemove\",arguments[2],arguments[3]); simulate(arguments[0],\"mouseup\",arguments[2],arguments[3]); ",
				LocatorFrom,"mousedown",xto,yto);
	}

	/**
	 * @param locator
	 * @param timeout
	 */
	public void isDisplayed(By locator, int timeout) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		e=findElement(locator, timeout);
		//		Assert.assertNotNull(e, "Could not find the WebElement " + locator);
		Assert.assertTrue(e.isDisplayed(), "Element " + locator + " is not visible");
	}

	/**
	 * @param locator
	 * @param timeout
	 */
	public void isNotDisplayed(By locator, int timeout) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			e=findElement(locator, timeout);
			Assert.assertFalse(e.isDisplayed(), "Element " + locator + " is not visible");
		} catch (Exception e) {
			Assert.assertTrue(true, "Element " + locator + " is not visible");
		}

		//		Assert.assertNotNull(e, "Could not find the WebElement " + locator);

	}

	/**
	 * @param locatorname
	 * @param timeout
	 * @return
	 */
	public WebElement findElement(By locatorname, int timeout) {

		TestBaseListener.suite_logs.info("Waiting for the element [" + locatorname.toString() + "], timeout = [" + timeout + "]");
		WebDriverWait wait = new WebDriverWait(TestBaseListener.getDriver(), timeout);
		//		return wait.until(getElement(locatorname));
		return wait.until(ExpectedConditions.visibilityOfElementLocated(locatorname));
	}
	/**
	 * @param locatorname
	 * @param timeout
	 * @return
	 */
	public List<WebElement> findElements(By locatorname, int timeout) {
		TestBaseListener.suite_logs.info("Waiting for the element [" + locatorname.toString() + "], timeout = [" + timeout + "]");
		WebDriverWait wait = new WebDriverWait(TestBaseListener.getDriver(), timeout);
		//		return wait.until(getElements(locatorname));
		return wait.until(ExpectedConditions.presenceOfAllElementsLocatedBy(locatorname));
	}

	/**
	 * @param locator
	 * @param timeout
	 * @return
	 */
	public boolean isElementVisible(By locator, int timeout){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			e=findElement(locator, timeout);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/**
	 * 
	 */
	public void CloseTab(){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		try {
			Robot robot = new Robot();

			// Simulate a key press
			robot.keyPress(KeyEvent.VK_CONTROL);
			robot.keyPress(KeyEvent.VK_W);
			robot.keyRelease(KeyEvent.VK_CONTROL);
			robot.keyRelease(KeyEvent.VK_W);
		} catch (AWTException e) {
			System.out.println("Failed to close the tab");
		}
	}

	/**
	 * @param framePath
	 */
	public void switchThroughFrames(String framePath) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.getDriver().switchTo().defaultContent();
		String[] framesList = framePath.split(">");

		for(int i=0; i < framesList.length; i++) {
			TestBaseListener.getDriver().switchTo().frame(framesList[i]);
		}
	}

	/**
	 * @param frame
	 */
	public void switchFrame(String frame) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.getDriver().switchTo().frame(frame);
	}

	/**
	 * @param frameIndex
	 */
	public void switchFrame(int frameIndex) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.suite_logs.info("Switching directly to frame [" + frameIndex + "]");
		TestBaseListener.getDriver().switchTo().frame(frameIndex);
	}

	/**
	 * @param element
	 */
	public void switchFrame(WebElement element) {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.suite_logs.info("Switching directly to WebElement [" + element + "]");
		TestBaseListener.getDriver().switchTo().frame(element);
	}

	/**
	 * @param className
	 */
	public void switchToDynamicFrame(String className){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.suite_logs.info("Switching directlt to dynamic frame with class name [" +className+ "]");		
		WebElement e = findElement(By.className("FB_UI_Dialog"), 10);
		String id = e.getAttribute("id");
		switchFrame(id);
	}

	/**
	 * 
	 */
	public void switchToDefault() {
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.getDriver().switchTo().defaultContent();
	}
	/**
	 * @param title
	 */
	public void switchToWindowByTitle(String title)	{

		boolean found = false;
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.suite_logs.info("Switching directly to window with title [" + title + "]");
		while(found == false)
		{     
			for (String handle : TestBaseListener.getDriver().getWindowHandles()) {
				String myTitle = TestBaseListener.getDriver().switchTo().window(handle).getTitle();
				if(myTitle.equalsIgnoreCase(title)){
					found = true;
					break;
				}
			}
			found = true;

		}

	}

	/**
	 * @param handle
	 */
	public void switchToWindow(String handle){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.suite_logs.info("Switching directly to window with handle [" + handle + "]");
		TestBaseListener.getDriver().switchTo().window(handle);
	}
	/**
	 * 
	 */
	public void closeTab(){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		TestBaseListener.getDriver().close();

	}
	/**
	 * @return
	 */
	public String getHandleOfWindow(){
		TestBaseListener.suite_logs.info("Executing Method : "+Thread.currentThread().getStackTrace()[1].getMethodName());
		return TestBaseListener.getDriver().getWindowHandle();
	}

	/**
	 * @param element
	 * @param fileName
	 */
	public static synchronized void uploadFile(WebElement element, String fileName) {

		TestBaseListener.suite_logs.info("Executing Keyword : "+ Thread.currentThread().getStackTrace()[1].getMethodName());

		if (element.equals("") || fileName.trim().equals("")) {
			TestBaseListener.suite_logs.error("Specify values of Object and Data");
		}

		try {
			TestBaseListener.actions.moveToElement(element).click().build().perform();
			Thread.sleep(10000);
			String scriptLoc = FILE_UPLOAD_SCRIPT_PATH;
			fileName=DATA_FILES_LOC+fileName;
			TestBaseListener.suite_logs.debug("ATA FILES LOCATION : "+fileName);
			Process fileUpload = new ProcessBuilder(scriptLoc,TestBaseListener.browserName,fileName).start();
			fileUpload.waitFor();

		} catch (Exception e) {
			TestBaseListener.suite_logs.error("Couldn't upload the file. Following exception occurred: "+ e.getMessage());
		}
	}

	public String getCurrentDateTime(String ddMMhhmmss) {
		
		SimpleDateFormat simpleDateFormat =	new SimpleDateFormat(ddMMhhmmss);
		String dateAsString = simpleDateFormat.format(new Date());
		return dateAsString;
	}
}
