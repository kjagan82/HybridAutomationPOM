package com.qa.flows.Physicals;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import com.qa.base.TestBaseListener;
import com.qa.pages.Physicals.NewPrintableTemplatePage;
import com.qa.util.SeleniumLibs;

public class NewPrintableTemplatePageFlow extends SeleniumLibs{

	NewPrintableTemplatePage newPrintableTemplatePage;
	SeleniumLibs newSeleniumUtils;
	String printableTemplateName="";

	public NewPrintableTemplatePageFlow(){
		newPrintableTemplatePage = new NewPrintableTemplatePage();
	}


	public void createTemplate(String saveToVariable,String templateType,String getCustomFieldSelect)throws Exception {

		waitForAjax();
		//appending date so that name can be generated dynamically
		String dateAsString=getCurrentDateTime("ddMMhhmmss");
		printableTemplateName=null;
		printableTemplateName=templateType+"Template"+dateAsString;
		storeResultsinFile(saveToVariable, printableTemplateName);
		enterText(newPrintableTemplatePage.getTemplateName(), printableTemplateName);
		
		click(newPrintableTemplatePage.getExpandAllTemplate());
		staticWait(2);
		List<WebElement> allcheckbox = findElements(newPrintableTemplatePage.getAllCheckboxTemplate(), 5);
		staticWait(2);
		for(WebElement checkbox:allcheckbox) {
			if(!checkbox.isSelected()) {
				waitForAjax();
				click(checkbox);
			}
		}
		selectDropDownByText(newPrintableTemplatePage.getCustomFieldSelect(), getCustomFieldSelect);
		staticWait(1);
		click(newPrintableTemplatePage.getCustomSearchImage());
		waitForAjax();

		//to switch to opened window to click on save Button
		String parentWindow = TestBaseListener.getDriver().getWindowHandle();
		Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle  : handles){
			if(!windowHandle.equals(parentWindow)){
				TestBaseListener.getDriver().switchTo().window(windowHandle);
				TestBaseListener.getDriver().manage().window().maximize();
				click(newPrintableTemplatePage.getFirstRowCheckBox());
				staticWait(2);
				click(newPrintableTemplatePage.getCustomSearchWinSelectBtn());
				TestBaseListener.getDriver().switchTo().window(parentWindow); //cntrl to parent window
			}
		}
		waitForAjax();
		click(newPrintableTemplatePage.getAddFieldCustom());
		waitForAjax();
		click(newPrintableTemplatePage.getCreatePrintableTemplate());
		waitForAjax();
	}
	
	public void verifyPrintableTemplate(String templateType)throws Exception{
		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newPrintableTemplatePage.getDefaultHeader());
		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newPrintableTemplatePage.getMainFilter());
		staticWait(1);
		click(newPrintableTemplatePage.getFilterReset());
		staticWait(1);
		selectDropDownByText(newPrintableTemplatePage.getTemplateType(), templateType);
		enterText(newPrintableTemplatePage.getTemplateTypeEnter(),printableTemplateName);
		staticWait(1);
		click(newPrintableTemplatePage.getFilterGo());
		staticWait(2);
		if(getText(newPrintableTemplatePage.getVerifyPrintTemplate()).equalsIgnoreCase(printableTemplateName)) {
			TestBaseListener.suite_logs.info("Succesfully Verified the Printable Template Presense !!!");
		}else {
			TestBaseListener.suite_logs.info("Couldn't  Verify the Printable Template Presense !!!");
			Assert.fail();
		}
	}
}

