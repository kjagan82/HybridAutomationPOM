package com.qa.flows.Logistics;
import com.qa.base.TestBaseListener;
import com.qa.pages.Logistics.NewPlannedContainerShipmentPage;
import com.qa.util.SeleniumLibs;

public class NewPlannedContainerShipmentPageFlow extends SeleniumLibs{


	NewPlannedContainerShipmentPage newPlannedContainerShipmentPage;

	public NewPlannedContainerShipmentPageFlow()throws Exception{
		newPlannedContainerShipmentPage = new NewPlannedContainerShipmentPage();
	}

	public void planned_Shipment_Details(String activityDate,String productSelect,String originSelect,String cropYearSelect,
			String qualitySelect,String CpNameSelect,String plannedQtyEnter,String plannedQtySelect)throws Exception{

		
		/*DateTimeFormatter dtf = DateTimeFormatter.ofPattern("d");  
		LocalDateTime now = LocalDateTime.now();  
		selectDateFromDatePicker(newPlannedContainerShipmentPage.getActivityDate(), dtf.format(now));*/
		//selectDateFromDatePicker(newPlannedContainerShipmentPage.getActivityDate(), activityDate);
		
		click(newPlannedContainerShipmentPage.getActivityDate());
		staticWait(1);
		click(newPlannedContainerShipmentPage.getActivityDateToday());
		selectSingleListAndItem(newPlannedContainerShipmentPage.getProductArrow(), newPlannedContainerShipmentPage.getProductSelect(), productSelect);
		click(newPlannedContainerShipmentPage.getOriginLabelClick());
		waitForAjax();
		staticWait(5);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getOriginArrow(), newPlannedContainerShipmentPage.getOriginSelect(), originSelect);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getCropYearArrow(), newPlannedContainerShipmentPage.getCropYearSelect(), cropYearSelect);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getQualityArrow(), newPlannedContainerShipmentPage.getQualitySelect(), qualitySelect);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getCpName(),newPlannedContainerShipmentPage.getCpNameSelect(),  CpNameSelect);
		enterText(newPlannedContainerShipmentPage.getPlannedQtyEnter(), plannedQtyEnter);
		selectDropDownByText(newPlannedContainerShipmentPage.getPlannedQtySelect(), plannedQtySelect);

	}

	public void voyage_Details(String shippingLineSelect,String noOfContainerEnter,String loadPortSelect,
			String dischargePortSelect)throws Exception{

		selectDropDownByText(newPlannedContainerShipmentPage.getShippingLineSelect(),shippingLineSelect);
		enterText(newPlannedContainerShipmentPage.getNoOfContainerEnter(), noOfContainerEnter);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getLoadPortArrow(), newPlannedContainerShipmentPage.getLoadPortSelect(), loadPortSelect);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getDischargePortArrow(), newPlannedContainerShipmentPage.getDischargePortSelect(), dischargePortSelect);
		click(newPlannedContainerShipmentPage.getShipmentPlanSave());

	}

	public void sourceLoading_Manage_Allocations(String containerStufftype,String expectSourceLocSelect,
			String expDateOfPickUp,String saleCallOffNo)throws Exception{
		waitForAjax();
		
		String PCFRefNo = getText(newPlannedContainerShipmentPage.getPCFRefNo());
		storeResultsinFile("PCSRefNo", PCFRefNo);
		TestBaseListener.suite_logs.info("*********PCFRefNo NUmber: "+PCFRefNo);
		
		selectDropDownByText(newPlannedContainerShipmentPage.getContainerStufftype(), containerStufftype);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getExpectSourceLocArrow(), newPlannedContainerShipmentPage.getExpectSourceLocSelect(), expectSourceLocSelect);
		selectDateFromDatePicker(newPlannedContainerShipmentPage.getExpDateOfPickUp(), expDateOfPickUp);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getSaleCallOffNoArrow(), newPlannedContainerShipmentPage.getSaleCallOffNoSelect(), saleCallOffNo);
		click(newPlannedContainerShipmentPage.getContainerShipmentSave());

	}

	public void transLoading_Manage_Allocations(String containerStufftype,String expectSourceLocSelect,
			String expDateOfPickUp,String saleCallOffNoSelect)throws Exception{
		waitForAjax();
		selectDropDownByText(newPlannedContainerShipmentPage.getContainerStufftype(), containerStufftype);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getExpectSourceLocArrow(), newPlannedContainerShipmentPage.getExpectSourceLocSelect(), expectSourceLocSelect);
		selectDateFromDatePicker(newPlannedContainerShipmentPage.getExpDateOfPickUp(), expDateOfPickUp);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getSaleCallOffNoArrow(), newPlannedContainerShipmentPage.getSaleCallOffNoSelect(), saleCallOffNoSelect);
		click(newPlannedContainerShipmentPage.getContainerShipmentSave());

	}

	public void cost_Estimate(String costCompName,String CpNameCostEstimateSelect,String rateType,
			String costValueEnter,String costValueUnitSelect,String FxToBase,String costApplicableSelect,String incomeExpence)throws Exception{
		waitForAjax();
		selectDropDownByText(newPlannedContainerShipmentPage.getCostCompName(), costCompName);
		selectDropDownByText(newPlannedContainerShipmentPage.getIncomeExpence(), incomeExpence);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getCpNameCostEstimateArrow(), newPlannedContainerShipmentPage.getCpNameCostEstimateSelect(), CpNameCostEstimateSelect);
		selectDropDownByText(newPlannedContainerShipmentPage.getRateType(), rateType);
		enterText(newPlannedContainerShipmentPage.getCostValueEnter(), costValueEnter);
		selectDropDownByText(newPlannedContainerShipmentPage.getCostValueUnitSelect(),costValueUnitSelect);
		//enterText(newPlannedContainerShipmentPage.getFxToBase(), FxToBase);
		selectDropDownByText(newPlannedContainerShipmentPage.getCostApplicableSelect(), costApplicableSelect);
		click(newPlannedContainerShipmentPage.getCostEstimateSave());

	}

	public void add_Deductions(String contractItemSelect,String addDeleteNameSelect,String rateType,
			String rateEnter,String rateSelect,String weightBasis,String addRemarks)throws Exception{
		waitForAjax();
		selectDropDownByText(newPlannedContainerShipmentPage.getContractItemSelect(),contractItemSelect);
		selectSingleListAndItem(newPlannedContainerShipmentPage.getAddDeleteNameArrow(), newPlannedContainerShipmentPage.getAddDeleteNameSelect(), addDeleteNameSelect);
		selectDropDownByText(newPlannedContainerShipmentPage.getRateType(), rateType);
		enterText(newPlannedContainerShipmentPage.getRateEnter(), rateEnter);
		selectDropDownByText(newPlannedContainerShipmentPage.getRateSelect(),rateSelect);
		selectDropDownByText(newPlannedContainerShipmentPage.getWeightBasis(), weightBasis);
		enterText(newPlannedContainerShipmentPage.getAddRemarks(), addRemarks);
		click(newPlannedContainerShipmentPage.getAddDedRowButton());

		/*To click on save Button in the footer*/
		click(newPlannedContainerShipmentPage.getAddDedRowButtonSave());

	}

}
