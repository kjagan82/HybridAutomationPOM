package com.qa.flows.Derivatives;

import org.testng.Assert;

import com.qa.pages.Derivatives.NewOTCOptionPage;
import com.qa.util.SeleniumLibs;
	
/**
 * @author jaganmohan.k
 *
 */
public class NewOTCOptionTradesFlow extends SeleniumLibs{

	String pageTitle = "New OTC Option";
	NewOTCOptionPage newOTCOptionPage;
	String createdBuyOTCOptionTradeRefNo="BuyOTCOptionTradeRefNo";
	String createdSellOTCOptionTradeRefNo="SellOTCOptionTradeRefNo";

	public NewOTCOptionTradesFlow(){
		newOTCOptionPage = new NewOTCOptionPage();
	}

	public void loginPageTitle(){
		staticWait(3);
		Assert.assertEquals(newOTCOptionPage.validateLoginPageTitle(), pageTitle);
	}

	public void fillNewOTCOptionDetails(String trader,String CounterParty,String MarketLocationCountry,String MarketLocationState,String MarketLocationCity,
			String Product,String Quality,String ExchangeInstrument,String PromptDeliveryDetailsType,String PromptDeliveryDetailsName,String TradeType,
			String Quantity,String QuantityUnit,String SettlementCurrency,String StrikePrice,String StrikePriceUnit,String PremiumDiscount,String PremiumDiscountPriceUnit,
			String PaymentTerms,String Broker,String BrokerCommType,String ProfitCenter,String Strategy,String Purpose,String Nominee) {

		//Option Contract Details
		selectDateFromDatePicker(newOTCOptionPage.getTradeDate(),selectDate(0));
		selectDropDownByText(newOTCOptionPage.getTrader(), trader);
		selectSingleListAndItem(newOTCOptionPage.getCounterPartyArrow(), newOTCOptionPage.getCounterPartyUL(), CounterParty);
		selectDropDownByText(newOTCOptionPage.getMarketLocationCountry(), MarketLocationCountry);
		selectDropDownByText(newOTCOptionPage.getMarketLocationState(), MarketLocationState);
		selectDropDownByText(newOTCOptionPage.getMarketLocationCity(), MarketLocationCity);
		selectDropDownByText(newOTCOptionPage.getProductId(), Product);
		selectDropDownByText(newOTCOptionPage.getQualityId(), Quality);
		selectDropDownByText(newOTCOptionPage.getExchangeInstrument(), ExchangeInstrument);
		staticWait(2);
		selectDropDownByText(newOTCOptionPage.getPromptDeliveryDetailsType(), PromptDeliveryDetailsType);
		selectDropDownByText(newOTCOptionPage.getPromptDeliveryDetailsName(), PromptDeliveryDetailsName);
		selectDropDownByText(newOTCOptionPage.getTradeType(), TradeType);
		enterText(newOTCOptionPage.getQuantity(), Quantity);
		selectDropDownByText(newOTCOptionPage.getQuantityUnitId(), QuantityUnit);
		selectDropDownByText(newOTCOptionPage.getSettlementCurrency(), SettlementCurrency);
		enterText(newOTCOptionPage.getStrikePrice(), StrikePrice);
		selectDropDownByText(newOTCOptionPage.getStrikePriceUnitId(), StrikePriceUnit);
		enterText(newOTCOptionPage.getPremiumDiscount(), PremiumDiscount);
		selectDropDownByText(newOTCOptionPage.getPremiumDiscountPriceUnit(), PremiumDiscountPriceUnit);
		selectDateFromDatePicker(newOTCOptionPage.getPremiumDueDate(),selectDate(5));
		selectDateFromDatePicker(newOTCOptionPage.getExpiryDate(),selectDate(2));
		selectDropDownByText(newOTCOptionPage.getPaymentTerms(), PaymentTerms);
		selectDateFromDatePicker(newOTCOptionPage.getPaymentDueDate(),selectDate(5));
		selectDropDownByText(newOTCOptionPage.getBroker(), Broker);
		selectDropDownByText(newOTCOptionPage.getBrokerCommType(), BrokerCommType);
		staticWait(1);
		/*Internal block*/
		selectDropDownByText(newOTCOptionPage.getProfitCenterId(), ProfitCenter);
		selectDropDownByText(newOTCOptionPage.getStrategyId(), Strategy);
		selectDropDownByText(newOTCOptionPage.getPurposeId(), Purpose);
		if(Purpose.equalsIgnoreCase("Hedging")) {
			staticWait(2);
			selectSingleListAndItem(newOTCOptionPage.getNomineearrow(), newOTCOptionPage.getSelectnomineeUL(), Nominee);
		}
		click(newOTCOptionPage.getCreateButton());
		staticWait(2);
		//Storing the createdFxTradeRefNo in the result file
		if(TradeType.equalsIgnoreCase("Buy")) {
			storeResultsinFile(createdBuyOTCOptionTradeRefNo, getText(newOTCOptionPage.getCreatedTradeRefNo()));
		}else if(TradeType.equalsIgnoreCase("Sell")) {
			storeResultsinFile(createdSellOTCOptionTradeRefNo, getText(newOTCOptionPage.getCreatedTradeRefNo()));
		}

		click(newOTCOptionPage.getOk_button());

	}


}
