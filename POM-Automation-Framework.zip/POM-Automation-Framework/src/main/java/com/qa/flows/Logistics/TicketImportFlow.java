package com.qa.flows.Logistics;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.qa.base.TestBaseListener;
import com.qa.pages.Logistics.TicketImportPage;
import com.qa.util.SeleniumLibs;

public class TicketImportFlow extends SeleniumLibs {

	String pageTitle = "Import";
	WebDriver driver;
	TicketImportPage ticketImportPage ;


	public TicketImportFlow(){
		//super();
		ticketImportPage = new TicketImportPage();
	}

	public void ticketImportPageTitle(){
		Assert.assertEquals(ticketImportPage.validateLoginPageTitle(), pageTitle);
	}	

	public void ticketImport() throws Exception{
		
		//to switch to opened window for Choose File
		waitForAjax();
				String parentWindow = TestBaseListener.getDriver().getWindowHandle();
				Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

				for(String windowHandle  : handles)
				{
					if(!windowHandle.equals(parentWindow))
					{
						TestBaseListener.getDriver().switchTo().window(windowHandle);
						staticWait(2);
						waitForAjax();
						uploadFile(ticketImportPage.chooseFile(), "Ticket ImportData.csv");
						Thread.sleep(2000);
						ticketImportPage.readFile();
						Thread.sleep(2000);
						ticketImportPage.ok();
						TestBaseListener.getDriver().switchTo().window(parentWindow); //control to parent window
					}
			}
		}
}
