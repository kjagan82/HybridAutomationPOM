package com.qa.flows.Physicals;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.qa.base.TestBaseListener;
import com.qa.pages.Physicals.NewContractPage;
import com.qa.util.SeleniumLibs;

public class NewContractPageFlow extends SeleniumLibs{

	String PurchasePageTitle = "New Purchase Contract";
	String SalePageTitle = "New Sales Contract";
	String ProductionPageTitle = "New Purchase Contract";

	NewContractPage newContractPage;
	SeleniumLibs newSeleniumUtils;
	public String templateName="Test";

	public NewContractPageFlow(){
		newContractPage = new NewContractPage();
	}



	public void purchaseloginPageTitle(){
		Assert.assertEquals(newContractPage.validateLoginPageTitle(), PurchasePageTitle);
	}
	public void saleloginPageTitle(){
		Assert.assertEquals(newContractPage.validateLoginPageTitle(), SalePageTitle);
	}
	public void productionloginPageTitle(){
		Assert.assertEquals(newContractPage.validateLoginPageTitle(), ProductionPageTitle);
	}

	public void production_contract_checKBox(){
		click(newContractPage.proContractCheckBox());
		staticWait(2);
		TestBaseListener.suite_logs.info("Contract check Box selected");
	}

	public void ContractTemplateName() {
		templateName=templateName+getCurrentDateTime("ddMMhhmmss");
		enterText(newContractPage.getTemplateName(), templateName);
	}

	public void contractDetails(String traderName,String ConIsDate,String masterContract,
			String dealType,String cpName,String brokerName,String brokerIncha,String brokerRefNo,
			String cpConRefNo,String INCOTerm,String brokertext,String brokerComSel,
			String paymentTerms,String freightTerms,String contQuaUnit,String operator,
			String personIncha,String personSecInCha) throws Exception{


		selectDropDownByText(newContractPage.traderNameDropDown(), traderName);
		selectDateFromDatePicker(newContractPage.contractIssueDate(), selectDate(0));

		//selectDropDownByText(newPurchaseContractPage.masterContract(), masterContract);
		selectDropDownByText(newContractPage.dealTypeDropDown(), dealType);
		selectSingleListAndItem(newContractPage.cpName(), newContractPage.cpNameSelect(), cpName);
		staticWait(1);
		selectDropDownByText(newContractPage.brokerName(),brokerName);
		//selectDropDownByText(newPurchaseContractPage.brokerIncharge(), brokerIncha);
		enterText(newContractPage.brokerRefNo(), brokerRefNo);
		enterText(newContractPage.cpContractRefNo(), cpConRefNo);
		selectDropDownByText(newContractPage.incoTerm(), INCOTerm);
		enterText(newContractPage.brokerComTextbox(), brokertext);
		selectDropDownByText(newContractPage.brokerComSelect(), brokerComSel);
		selectDropDownByText(newContractPage.paymentTerms(), paymentTerms);
		selectDropDownByText(newContractPage.freightTerms(), freightTerms);
		selectDropDownByText(newContractPage.contractqtyUnit(), contQuaUnit);
		selectDropDownByText(newContractPage.operator(), operator);
		selectDropDownByText(newContractPage.personInCharge(), personIncha);
		selectDropDownByText(newContractPage.personSecondCharge(), personSecInCha);
		TestBaseListener.suite_logs.info("Contract Details Filled !!!");
	}

	public void itemDetails(String product,String origin,String cropYear,String quality,
			String profitCenter,String strategy,String shortDesc,String longDesc) throws Exception{
		staticWait(1);
		//Scrolling 
		selectSingleListAndItem(newContractPage.productDetailsProduct(), newContractPage.productDetailsProductSelect(),product);
		click(newContractPage.originLabelClick());
		waitForAjax();
		staticWait(5);
		selectSingleListAndItem(newContractPage.originProductDetails(), newContractPage.originSelect(), origin);
		selectSingleListAndItem(newContractPage.cropYearProductDetails(), newContractPage.cropYearSelect(), cropYear);
		selectSingleListAndItem(newContractPage.qualityProductDetails(), newContractPage.qualityProductDetailsSelect(), quality);
		selectDropDownByText(newContractPage.profitCenter(), profitCenter);
		selectDropDownByText(newContractPage.strategy(), strategy);
		enterText(newContractPage.shortDescArea(), shortDesc);
		enterText(newContractPage.longDescArea(), longDesc);
		TestBaseListener.suite_logs.info("Contract itemDetails Filled !!!");

	}

	public void production_quantityDetails(String conAreaInput,String conAreaSelect,String expectedYieldInput,
			String qualityInput,String itemQuaSel,String packType,String packSize,String minTol,String MaxTol,
			String tolType,String tolLevel,String tolremark) throws Exception{
		staticWait(1);
		enterText(newContractPage.conAreainput(), conAreaInput);
		selectDropDownByText(newContractPage.conAreaSelect(), conAreaSelect);
		enterText(newContractPage.expectedYieldInput(), expectedYieldInput);
		selectDropDownByText(newContractPage.packingType(), packType);
		staticWait(2);
		click(newContractPage.packingLabelClick());
		staticWait(3);
		selectDropDownByText(newContractPage.packingSizeId(),packSize);//packing type second select
		enterText(newContractPage.toleranceMinenter(), minTol);
		enterText(newContractPage.toleranceMaxenter(), MaxTol);
		selectDropDownByText(newContractPage.toleranceType(), tolType);
		selectDropDownByText(newContractPage.toleranceLevel(), tolLevel);
		enterText(newContractPage.toleranceRemarks(), tolremark);
		TestBaseListener.suite_logs.info("Production_quantityDetails Filled !!!");
	}


	public void quantityDetails(String qualityInput,String itemQuaSel,String packType,
			String packSize,String minTol,String MaxTol,String tolType,
			String tolLevel,String tolremark) throws Exception{
		staticWait(1);
		//Scrolling 
		enterText(newContractPage.itemQtyinput(), qualityInput);
		selectDropDownByText(newContractPage.itemQtySelect(), itemQuaSel);
		selectDropDownByText(newContractPage.packingType(), packType);
		staticWait(2);
		click(newContractPage.packingLabelClick());
		staticWait(3);
		//	selectDropDownByText(newContractPage.packingSizeId(),packSize);//packing type second select
		enterText(newContractPage.toleranceMinenter(), minTol);
		enterText(newContractPage.toleranceMaxenter(), MaxTol);
		selectDropDownByText(newContractPage.toleranceType(), tolType);
		selectDropDownByText(newContractPage.toleranceLevel(), tolLevel);
		enterText(newContractPage.toleranceRemarks(), tolremark);
		TestBaseListener.suite_logs.info("quantityDetails Filled !!!");
	}

	public void addAdditionDeduction() throws Exception{
		staticWait(1);
		//Scrolling 
		selectSingleListAndItem(newContractPage.addDeleteName(), newContractPage.productDetailsProductSelect(), "");
		selectDropDownByText(newContractPage.addDelete(), "");
		selectDropDownByText(newContractPage.rateType(), "");
		enterText(newContractPage.rateEnter(), "");
		selectDropDownByText(newContractPage.rateSelect(), "");
		selectDropDownByText(newContractPage.weightBasis(), "");
		enterText(newContractPage.addRemarks(), "");
		click(newContractPage.addDedRowButton());
		waitForAjax();
		TestBaseListener.suite_logs.info("addAdditionDeduction Filled !!!");
	}

	public void deliveryPeriod(String shipFrom,String shipTo) throws Exception{
		staticWait(1);
		//Scrolling 
		selectDateFromDatePicker(newContractPage.shippingPeriodFrom(), selectDate(0));
		selectDateFromDatePicker(newContractPage.shippingPeriodTo(), selectDate(3));
		TestBaseListener.suite_logs.info("deliveryPeriod Filled !!!");
	}

	public void paymentTerms(String payDueDate,String invDocPrice,String taxScheduleApplicableCountry,String taxScheduleApplicableStates,String taxSchedule
			) throws Exception{
		staticWait(1);
		//Scrolling 
		selectDateFromDatePicker(newContractPage.paymentDueDate(),selectDate(6));
		//enterText(newPurchaseContractPage.proinvPercentageEnter(), "");
		selectDropDownByText(newContractPage.invoiceDocPrice(), invDocPrice);
		//		selectDropDownByText(newPurchaseContractPage.latePaymentInterest(), "");
		//		enterText(newPurchaseContractPage.latePaymentInterestRate(), "");
		selectDropDownByText(newContractPage.taxScheduleApplicableCountry(), taxScheduleApplicableCountry);
		selectDropDownByText(newContractPage.taxScheduleApplicableStates(), taxScheduleApplicableStates);
		selectDropDownByText(newContractPage.taxSchedule(),taxSchedule);
		click(newContractPage.addItemButton());
		TestBaseListener.suite_logs.info("paymentTerms Filled !!!");
	}

	public void deliveryDetails(String location,String country,String port) throws Exception{
		staticWait(1);
		//Scrolling 
		selectDropDownByText(newContractPage.destLocationType(), location);
		staticWait(2);
		selectSingleListAndItem(newContractPage.dischargeCountry(), newContractPage.dischargeCountrySelect(), country);
		staticWait(2);
		selectSubSingleListAndItem(newContractPage.dischargePortinput(), newContractPage.dischargePort(), newContractPage.dischargePortSelect(), port);
		TestBaseListener.suite_logs.info("deliveryDetails Filled !!!");
	}

	public void termsandCondition(String lawContract,String arbitration,String quaFinalAt,
			String weighFinalAt) throws Exception{
		staticWait(1);
		//Scrolling 
		selectDropDownByText(newContractPage.applicableLawContract(), lawContract);
		selectDropDownByText(newContractPage.arbitration(), arbitration);
		selectDropDownByText(newContractPage.qualityFinalAt(), quaFinalAt);
		selectDropDownByText(newContractPage.weightFinaliziedAt(), weighFinalAt);
		click(newContractPage.nextButtonContract());
		TestBaseListener.suite_logs.info("termsandCondition Filled !!!");
	}

	public void basisPrice(String pdSechedule,String priceType,String futInstru,String priceMon,
			String basisEnter,String basisSel,String prFixOpt,String prFixMethod ) throws Exception{
		staticWait(1);
		//Scrolling 
		selectDropDownByText(newContractPage.qualityPDSchedule(), pdSechedule);
		selectDropDownByText(newContractPage.priceType(), priceType);
		selectDropDownByText(newContractPage.futureInstrument(),futInstru);
		selectDropDownByText(newContractPage.priceMonth(), priceMon);
		enterText(newContractPage.basisEnter(), basisEnter);
		selectDropDownByText(newContractPage.basisSelect(), basisSel);
		selectDropDownByText(newContractPage.priceFixOption(), prFixOpt);
		selectDropDownByText(newContractPage.priceFixMethod(), prFixMethod);
		TestBaseListener.suite_logs.info("basisPrice Filled !!!");
	}

	public void fixedPrice() throws Exception{
		staticWait(3);
		//Scrolling 
		selectDropDownByText(newContractPage.qualityPDSchedule(), "");
		selectDropDownByText(newContractPage.priceType(), "");
		selectDropDownByText(newContractPage.futureInstrument(),"");
		selectDropDownByText(newContractPage.priceMonth(), "");
		selectDropDownByText(newContractPage.futurePrice(), "");
		enterText(newContractPage.basisEnter(), "");
		selectDropDownByText(newContractPage.basisSelect(), "");
		enterText(newContractPage.fxInstoBasis(), "");
		enterText(newContractPage.contractPriceEnter(), "");
		selectDropDownByText(newContractPage.contractPriceSelect(), "");
		enterText(newContractPage.fxBasistoPay(), "");
		TestBaseListener.suite_logs.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" Filled !!!");
	}

	public void flatPrice() throws Exception{
		staticWait(3);
		//Scrolling 
		selectDropDownByText(newContractPage.qualityPDSchedule(), "");
		selectDropDownByText(newContractPage.priceType(), "");
		enterText(newContractPage.contractPriceEnter(), "");
		selectDropDownByText(newContractPage.contractPriceSelect(), "");
		TestBaseListener.suite_logs.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" Filled !!!");

	}

	public void futuresFirstPrice() throws Exception{
		staticWait(3);
		//Scrolling 
		selectDropDownByText(newContractPage.qualityPDSchedule(), "");
		selectDropDownByText(newContractPage.priceType(), "");
		selectDropDownByText(newContractPage.futureInstrument(),"");
		selectDropDownByText(newContractPage.priceMonth(), "");
		selectDropDownByText(newContractPage.futurePrice(), "");
		enterText(newContractPage.basisEnter(), "");
		selectDropDownByText(newContractPage.basisSelect(), "");
		selectDropDownByText(newContractPage.priceFixOption(), "");
		selectDropDownByText(newContractPage.priceFixMethod(), "");
		TestBaseListener.suite_logs.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" Filled !!!");
	}

	public void TBDPrice() throws Exception{
		staticWait(3);
		//Scrolling 
		//Normal operations
		selectDropDownByText(newContractPage.qualityPDSchedule(), "");
		selectDropDownByText(newContractPage.priceType(), "");
		enterText(newContractPage.basisEnter(), "");
		selectDropDownByText(newContractPage.basisSelect(), "");
		selectDropDownByText(newContractPage.priceFixOption(), "");
		selectDropDownByText(newContractPage.priceFixMethod(), "");
		TestBaseListener.suite_logs.info(Thread.currentThread().getStackTrace()[1].getMethodName()+" Filled !!!");
	}

	public void costAccrualPageForm(String valuationIncoTerm,String valuationLocationTypeGroup,String valuationLocation,String valuationLocationType,String fXPricetoPosition,
			String expectedDeliveryLocation,String locationCountry,String locationCity,String itemRefNo,String costComponentName,String incomeExpence,String estimateFor,String cpName,
			String rateType,String costValue,String costValueUnit,String fxToBase,String costAmount,String comments) throws Exception{

		waitForAjax();
		selectDropDownByText(newContractPage.valuationIncoTerm(),valuationIncoTerm);
		selectDropDownByText(newContractPage.valuationLocationTypeGroup(),valuationLocationTypeGroup);


		selectSingleListAndItem(newContractPage.valuationLocationArrow(), newContractPage.valuationLocationSelect(), valuationLocation);
		staticWait(3);
		selectSingleListAndItem(newContractPage.valuationLocationCityArrow(), newContractPage.valuationLocationCitySelect(), valuationLocationType);
		//selectDropDownByText(newPurchaseContractPage.positionCurrency(),"");
		//enterText(newPurchaseContractPage.fXPricetoPosition(), fXPricetoPosition);

		selectDropDownByText(newContractPage.expectedDestLocationType(), expectedDeliveryLocation);
		staticWait(2);
		selectSingleListAndItem(newContractPage.expectedDischargeCountry(), newContractPage.expectedDischargeCountrySelect(), locationCountry);
		staticWait(2);
		enterText(newContractPage.valuationLocationCityEnter(), locationCity);
		selectSingleListAndItem(newContractPage.expectedDischargePort(), newContractPage.expectedDischargePortSelect(), locationCity);
		staticWait(2);
		selectDropDownByText(newContractPage.itemRefNo(),itemRefNo);
		selectDropDownByText(newContractPage.costComponentName(),costComponentName);
		selectDropDownByText(newContractPage.incomeExpence(),incomeExpence);
		selectDropDownByText(newContractPage.estimateFor(),estimateFor);
		selectSingleListAndItem(newContractPage.cpName(), newContractPage.cpNameSelect(), cpName);
		selectDropDownByText(newContractPage.rateTypeValuation(),rateType);
		enterText(newContractPage.costValue(),costValue);
		selectDropDownByText(newContractPage.costValueUnit(),costValueUnit);
		//enterText(newPurchaseContractPage.fxToBase(), fxToBase);
		//enterText(newPurchaseContractPage.costAmount(), costAmount);
		//enterText(newPurchaseContractPage.fxToPosition(), "");
		//enterText(newPurchaseContractPage.comments(), comments);
		click(newContractPage.add());
		//click(newPurchaseContractPage.previous());
		//click(newPurchaseContractPage.saveAsDraft());
		click(newContractPage.next());
		//click(newPurchaseContractPage.cancel());
		waitForAjax();
		staticWait(2);
		click(newContractPage.create());
		waitForAjax();

		//to switch to opened window to click on save Button
		String parentWindow = TestBaseListener.getDriver().getWindowHandle();
		Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle  : handles)
		{
			if(!windowHandle.equals(parentWindow))
			{
				TestBaseListener.getDriver().switchTo().window(windowHandle);
				TestBaseListener.getDriver().manage().window().maximize();
				List<WebElement> approves = TestBaseListener.getDriver().findElements(By.xpath("//input[contains(@name,'approvalManagementDO')and @type='checkbox']"));
				for(WebElement approver:approves) {
					approver.click();
					staticWait(1);
				}
				click(newContractPage.save());
				TestBaseListener.getDriver().switchTo().window(parentWindow); //cntrl to parent window
			}
		}
	}
	//getting refference no;
	public void store_purchaseContractNo() {

		String refNo = getText(newContractPage.refNo());
		storeResultsinFile("purchaseContractRefNo", refNo);
		staticWait(4);
		click(newContractPage.ok());
		TestBaseListener.suite_logs.info(Thread.currentThread().getStackTrace()[1].getMethodName());
	} 
	public void store_saleContractNo() {

		String refNo= getText(newContractPage.refNo());
		storeResultsinFile("saleContractRefNo", refNo);
		staticWait(4);
		click(newContractPage.ok());
		TestBaseListener.suite_logs.info(Thread.currentThread().getStackTrace()[1].getMethodName());
	} 
	public void store_ProductionRefNO() {

		String refNo= getText(newContractPage.refNo());
		storeResultsinFile("productionRefNO", refNo);
		staticWait(4);
		click(newContractPage.ok());
		TestBaseListener.suite_logs.info(Thread.currentThread().getStackTrace()[1].getMethodName());
	} 
	//verifying contract
	public void verifyContract(String Key) {
		waitForAjax();
		clickUsingJavaScript(newContractPage.Filter());
		staticWait(2);
		enterText(newContractPage.conRefNoSearch(), Key);
		staticWait(2);
		click(newContractPage.conRefNoSearchGo());
		waitForAjax();
		if(newContractPage.getVerifyContract().getText().equalsIgnoreCase(Key)) {
			TestBaseListener.suite_logs.info("Succesfully Verified the contract Presense");
		}
		else {
			TestBaseListener.suite_logs.info("Couldn't  Verify the contract Presense");
			Assert.fail();
		}
	}

	public void templateTermsandCondition(String lawContract,String arbitration,String quaFinalAt,
			String weighFinalAt) throws Exception{
		staticWait(1);
		//Scrolling 
		selectDropDownByText(newContractPage.applicableLawContract(), lawContract);
		selectDropDownByText(newContractPage.arbitration(), arbitration);
		selectDropDownByText(newContractPage.qualityFinalAt(), quaFinalAt);
		selectDropDownByText(newContractPage.weightFinaliziedAt(), weighFinalAt);
		click(newContractPage.getCreateTemplate());
		TestBaseListener.suite_logs.info("termsandCondition Filled !!!");
		waitForAjax();
		String templateNo=getText(newContractPage.getTemplateRefNo());
		SeleniumLibs.storeResultsinFile("purchaseContracttemplateRefNO", templateNo);
		staticWait(1);
		click(newContractPage.ok());
	}

	public void verifyTemplate(String key) {
		waitForAjax();
		clickUsingJavaScript(newContractPage.Filter());
		staticWait(2);
		enterText(newContractPage.getTemplateSearchEnter(), templateName);
		staticWait(2);
		click(newContractPage.conRefNoSearchGo());
		waitForAjax();
		if(newContractPage.getVerifyContract().getText().equalsIgnoreCase(key)) {
			TestBaseListener.suite_logs.info("Succesfully Verified the contract Template Presense");
		}
		else {
			TestBaseListener.suite_logs.info("Couldn't  Verify the contract Template Presense");
			Assert.fail();
		}
	}
	public void searchContract(String contractNO) {

		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newContractPage.getMainDefault());
		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newContractPage.getMainFilter());
		staticWait(1);
		click(newContractPage.getFilterReset());
		staticWait(1);
		enterText(newContractPage.getFilterSearchInput(),contractNO);
		staticWait(1);
		click(newContractPage.getFilterGo());
		waitForAjax();
		click(newContractPage.getContractCheckBox());
		staticWait(1);
		waitForAjax();
		click(newContractPage.getContractOperationsHeader());
		staticWait(1);

	}
	public void cloneContract(String ContractType,String saveVariableName) throws Exception {

		if(ContractType.equals("New Purchase")||ContractType.equals("New Production")) {
			click(newContractPage.getNewPurchaseContractOperations());
		}
		else if(ContractType.equals("New Sale")) {
			click(newContractPage.getNewSaleContractOperations());
		}
		waitForAjax();
		click(newContractPage.nextButtonContract());
		waitForAjax();
		staticWait(1);
		click(newContractPage.next());
		waitForAjax();
		staticWait(1);
		click(newContractPage.create());
		waitForAjax();
		staticWait(2);

		//to switch to opened window to click on save Button
		String parentWindow = TestBaseListener.getDriver().getWindowHandle();
		Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle  : handles){
			if(!windowHandle.equals(parentWindow)){
				TestBaseListener.getDriver().switchTo().window(windowHandle);
				TestBaseListener.getDriver().manage().window().maximize();
				List<WebElement> approves = TestBaseListener.getDriver().findElements(By.xpath("//input[contains(@name,'approvalManagementDO')and @type='checkbox']"));
				for(WebElement approver:approves) {
					approver.click();
					staticWait(1);
				}
				click(newContractPage.save());
				TestBaseListener.getDriver().switchTo().window(parentWindow); //cntrl to parent window
			}
		}
		waitForAjax();
		String refNo = getText(newContractPage.refNo());
		storeResultsinFile(saveVariableName, refNo);
		staticWait(4);
		click(newContractPage.ok());
		TestBaseListener.suite_logs.info(Thread.currentThread().getStackTrace()[1].getMethodName());
	}

	public void contractAmend() {
		waitForAjax();
		click(newContractPage.getAmendContractContractOperations());
		waitForAjax();
		enterText(newContractPage.getReasonForAmend(), "Testing Purpose");
		/*Twice the item is copied and added*/
		for(int i=1;i<=2;i++) {
			click(newContractPage.getFirstRowCheckboxAddItem());
			click(newContractPage.getCopyItem());
			waitForAjax();
			click(newContractPage.getAddItemButton());
			waitForAjax();
		}
		click(newContractPage.getNextButtonContract());
		waitForAjax();
		click(newContractPage.getNext());
		waitForAjax();
		click(newContractPage.getAmendCreateContract());
		waitForAjax();
		//to switch to opened window to click on save Button
		String parentWindow = TestBaseListener.getDriver().getWindowHandle();
		Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle  : handles){
			if(!windowHandle.equals(parentWindow)){
				TestBaseListener.getDriver().switchTo().window(windowHandle);
				TestBaseListener.getDriver().manage().window().maximize();
				List<WebElement> approves = TestBaseListener.getDriver().findElements(By.xpath("//input[contains(@name,'approvalManagementDO')and @type='checkbox']"));
				for(WebElement approver:approves) {
					approver.click();
					staticWait(1);
				}
				click(newContractPage.save());
				TestBaseListener.getDriver().switchTo().window(parentWindow); //cntrl to parent window
			}
		}
		click(newContractPage.ok());
	}

	public void removeItemModifyContract() {

		waitForAjax();
		click(newContractPage.getModifyContractOperations());
		waitForAjax();
		/*clicking on the last row to remove*/
		List<WebElement> elements = findElements(By.name("selectedItems"), 5);
		for(int i=0;i<elements.size();i++) {
			if(elements.size()>=1) {
				if(i==elements.size()-1) {
					WebElement element = elements.get(i);
					click(element);
					//element.click();
					break;

				}
			}
		}
		click(newContractPage.getRemoveItem());
		waitForAjax();
		enterText(newContractPage.getReasonForAmend(), "Testing Purpose-Automation");
		click(newContractPage.getNextButtonContract());
		waitForAjax();
		click(newContractPage.getNext());
		waitForAjax();
		click(newContractPage.getModifyContractButton());
		waitForAjax();
		//to switch to opened window to click on save Button
		String parentWindow = TestBaseListener.getDriver().getWindowHandle();
		Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle  : handles){
			if(!windowHandle.equals(parentWindow)){
				TestBaseListener.getDriver().switchTo().window(windowHandle);
				TestBaseListener.getDriver().manage().window().maximize();
				List<WebElement> approves = TestBaseListener.getDriver().findElements(By.xpath("//input[contains(@name,'approvalManagementDO')and @type='checkbox']"));
				for(WebElement approver:approves) {
					approver.click();
					staticWait(1);
				}
				click(newContractPage.save());
				TestBaseListener.getDriver().switchTo().window(parentWindow); //cntrl to parent window
			}
		}
		click(newContractPage.ok());

	}

	public void contractModifyItem() {
		waitForAjax();
		click(newContractPage.getModifyContractOperations());
		waitForAjax();
		click(newContractPage.getFirstRowCheckboxAddItem());
		staticWait(1);
		click(newContractPage.getModifyItem());
		waitForAjax();
		enterText(newContractPage.itemQtyinput(), "2000");
		click(newContractPage.getUpdateItemButton());
		waitForAjax();
		enterText(newContractPage.getReasonForAmend(), "Testing Purpose-Automation");
		click(newContractPage.getNextButtonContract());
		waitForAjax();
		click(newContractPage.getNext());
		waitForAjax();
		click(newContractPage.getModifyContractButton());
		waitForAjax();
		//to switch to opened window to click on save Button
		String parentWindow = TestBaseListener.getDriver().getWindowHandle();
		Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle  : handles){
			if(!windowHandle.equals(parentWindow)){
				TestBaseListener.getDriver().switchTo().window(windowHandle);
				TestBaseListener.getDriver().manage().window().maximize();
				List<WebElement> approves = TestBaseListener.getDriver().findElements(By.xpath("//input[contains(@name,'approvalManagementDO')and @type='checkbox']"));
				for(WebElement approver:approves) {
					approver.click();
					staticWait(1);
				}
				click(newContractPage.save());
				TestBaseListener.getDriver().switchTo().window(parentWindow); //cntrl to parent window
			}
		}
		click(newContractPage.ok());
	}

	public void contractDraft(String ContractType,String saveVariableName) {

		waitForAjax();
		if(ContractType.equals("New Purchase")||ContractType.equals("New Production")) {
			click(newContractPage.getNewPurchaseContractOperations());
		}
		else if(ContractType.equals("New Sale")) {
			click(newContractPage.getNewSaleContractOperations());
		}
		waitForAjax();
		click(newContractPage.getSaveDraftButtonContract());
		waitForAjax();
		String refNo = getText(newContractPage.getDraftRefNo());
		storeResultsinFile(saveVariableName, refNo);
		staticWait(4);
		click(newContractPage.ok());
	}

	public void draftFilter(String draftType,String contractNO) {
		waitForAjax();
		clickUsingJavaScript(newContractPage.getMainFilter());
		waitForAjax();
		click(newContractPage.getFilterReset());
		waitForAjax();
		selectDropDownByText(newContractPage.getDraftFilterSelect(), draftType);
		staticWait(1);
		enterText(newContractPage.getDraftFilterEnter(), contractNO);
		click(newContractPage.getFilterGo());
		waitForAjax();
	}

	public void verifyDraft(String draftType,String contractNO) {
		draftFilter(draftType,contractNO);
		staticWait(2);
		if(newContractPage.getVerifyContract().getText().equalsIgnoreCase(contractNO)) {
			TestBaseListener.suite_logs.info("Succesfully Verified  "+contractNO+"  Draft contract Presense");
		}
		else {
			TestBaseListener.suite_logs.info("Couldn't  Verify   "+contractNO+ "Draft contract Presense");
			Assert.fail();
		}

	}
	public void cancelContract() {
		click(newContractPage.getCancelContractOperations());
		waitForAjax();
		enterText(newContractPage.getCancelReasonContract(), "Testing Purpose");
		click(newContractPage.getOKcancelContract());
		waitForAjax();
		click(newContractPage.ok());
	}

	public void verifyCancelContract(String contractNO) {
		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newContractPage.getMainDefault());
		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newContractPage.getMainFilter());
		staticWait(1);
		click(newContractPage.getFilterReset());
		staticWait(1);
		enterText(newContractPage.getFilterSearchInput(),contractNO);
		staticWait(1);
		click(newContractPage.getFilterGo());
		waitForAjax();
		staticWait(1);
		if(newContractPage.getVerifyContract().getText().equalsIgnoreCase(contractNO)&&
				newContractPage.getCancelContractStatus().getText().equalsIgnoreCase("Cancelled")) {
			TestBaseListener.suite_logs.info("Succesfully Verified  "+contractNO+" presence and Status changed to cancelled");
		}
		else {
			TestBaseListener.suite_logs.info("Couldn't  Verify   "+contractNO+ "presence or Status not changed to cancelled");
			Assert.fail();
		}
	}

	public void createOutputDocument(String contractNO,String templateType,String filtertemplateName) throws Exception{

		//filters
		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newContractPage.getMainDefault());
		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newContractPage.getMainFilter());
		staticWait(1);
		click(newContractPage.getFilterReset());
		staticWait(1);
		enterText(newContractPage.getFilterSearchInput(),contractNO);
		staticWait(1);
		click(newContractPage.getFilterGo());
		waitForAjax();
		click(newContractPage.getContractCheckBox());
		staticWait(1);
		click(newContractPage.getVerifyContract());
		waitForAjax();
		//inside contract
		click(newContractPage.getActivityTabOutputDoc());
		staticWait(2);
		click(newContractPage.getGenerateDocumentLink());
		waitForAjax();
		//to switch to opened window to click on save Button
		String parentWindow = TestBaseListener.getDriver().getWindowHandle();
		Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle  : handles){
			if(!windowHandle.equals(parentWindow)){
				TestBaseListener.getDriver().switchTo().window(windowHandle);
				TestBaseListener.getDriver().manage().window().maximize();
				if(!newContractPage.getGenerateDocExistingRadioBtn().isSelected()) {
					click(newContractPage.getGenerateDocExistingRadioBtn());
				}
				click(newContractPage.getNewWinOutputNextBtn());
				TestBaseListener.getDriver().switchTo().window(parentWindow);
			}
		}

		//to switch to opened window to click on save Button
		staticWait(2);
		Set<String> handles2 =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle2  : handles2){
			if(!windowHandle2.equals(parentWindow)){
				TestBaseListener.getDriver().switchTo().window(windowHandle2);
				TestBaseListener.getDriver().manage().window().maximize();
				click(newContractPage.getDefaultHeader());
				click(newContractPage.getMainFilter());
				waitForAjax();
				click(newContractPage.getFilterReset());
				selectDropDownByText(newContractPage.getTemplateType(), templateType);
				enterText(newContractPage.getTemplateTypeEnter(), filtertemplateName);
				click(newContractPage.getFilterGo());
				waitForAjax();
				click(newContractPage.getContractCheckBox());
				staticWait(1);
				click(newContractPage.getNewWinOutputNextBtn());
				TestBaseListener.getDriver().switchTo().window(parentWindow);
			}
		}
		//back to parent window
		click(newContractPage.getExpandAll());
		staticWait(2);
		click(newContractPage.getSave());
		waitForAjax();
		staticWait(1);
		click(newContractPage.ok());
		waitForAjax();
		click(newContractPage.getOutputDocParentWinRadioBtn());
		click(newContractPage.getOutputDocDownloadImg());

		Set<String> handles3 =  TestBaseListener.getDriver().getWindowHandles();
		for(String windowHandle3  : handles3){
			if(!windowHandle3.equals(parentWindow)) {
				TestBaseListener.getDriver().switchTo().window(windowHandle3);
				staticWait(5);
				TestBaseListener.getDriver().close();
				TestBaseListener.getDriver().switchTo().window(parentWindow);
			}
		}

	}
}

