package com.qa.flows.Derivatives;

import org.testng.Assert;

import com.qa.pages.Derivatives.NewFutureTradesPage;
import com.qa.util.SeleniumLibs;
	
/**
 * @author jaganmohan.k
 *
 */
public class NewFutureTradesFlow extends SeleniumLibs{

	String pageTitle = "Future Trades";
	NewFutureTradesPage newFutureTradesPage;
	String createdBuyTradeRefNo="BuyFutureTradeRefNo";
	String createdSellTradeRefNo="SellFutureTradeRefNo";

	public NewFutureTradesFlow(){
		newFutureTradesPage = new NewFutureTradesPage();
	}

	public void loginPageTitle(){
		staticWait(3);
		Assert.assertEquals(newFutureTradesPage.validateLoginPageTitle(), pageTitle);
	}

	public void fillBuyNewFutureTradeDetails(String trader,String exchangeInstrument,
			String promptDeliveryDetailsType,String promptDeliveryDetailsName,String tradePrice,String tradePriceTypeUnitId,
			String lotSize,String quantity_Input,String settlementCurrency,String clearerProfileId,String clearerAccountId,
			String profitCenterId,String strategyId,String purposeId,String nominee) throws Exception{

		/*Future Contract Details*/
		//enterText(newFutureTradesPage.getExternalTradeRefNo(), ExternalTradeRefNo);
		//Todays Day in the month
		selectDateFromDatePicker(newFutureTradesPage.getTradeDate(), selectDate(0));
		selectDropDownByText(newFutureTradesPage.getTrader(), trader);
		selectDropDownByText(newFutureTradesPage.getExchangeInstrument(), exchangeInstrument);
		staticWait(1);
		selectDropDownByText(newFutureTradesPage.getPromptDeliveryDetailsType(), promptDeliveryDetailsType);
		selectDropDownByText(newFutureTradesPage.getPromptDeliveryDetailsName(), promptDeliveryDetailsName);
		selectDropDownByText(newFutureTradesPage.getTradeType(), "Buy");
		staticWait(2);
		enterText(newFutureTradesPage.getTradePrice(), tradePrice);
		selectDropDownByText(newFutureTradesPage.getTradePriceTypeUnitId(), tradePriceTypeUnitId);
		selectDropDownByText(newFutureTradesPage.getLotSize(), lotSize);
		enterText(newFutureTradesPage.getQuantity_Input(), quantity_Input);
		selectDropDownByText(newFutureTradesPage.getSettlementCurrency(), settlementCurrency);
		selectDropDownByText(newFutureTradesPage.getClearerProfileId(), clearerProfileId);
		selectDropDownByText(newFutureTradesPage.getClearerAccountId(), clearerAccountId);
		staticWait(2);

		/*Internal block*/
		selectDropDownByText(newFutureTradesPage.getProfitCenterId(), profitCenterId);
		selectDropDownByText(newFutureTradesPage.getStrategyId(), strategyId);
		selectDropDownByText(newFutureTradesPage.getPurposeId(), purposeId);
		if(purposeId.equalsIgnoreCase("Hedging")) {
			selectSingleListAndItem(newFutureTradesPage.getNomineearrow(), newFutureTradesPage.getSelectnominee(), nominee);
		}
		
		click(newFutureTradesPage.getCreateButton());
		staticWait(2);
		//Storing the createdBuyTradeRefNo in the result file
		storeResultsinFile(createdBuyTradeRefNo, getText(newFutureTradesPage.getCreatedTradeRefNo()));
		click(newFutureTradesPage.getOk_button());

	}

	public void fillSellNewFutureTradeDetails(String trader,String exchangeInstrument,
			String promptDeliveryDetailsType,String promptDeliveryDetailsName,String tradePrice,String tradePriceTypeUnitId,
			String lotSize,String quantity_Input,String settlementCurrency,String clearerProfileId,String clearerAccountId,
			String profitCenterId,String strategyId,String purposeId,String nominee) throws Exception{

		/*Future Contract Details*/
		//enterText(newFutureTradesPage.getExternalTradeRefNo(), ExternalTradeRefNo);
		//Todays Day in the month
		selectDateFromDatePicker(newFutureTradesPage.getTradeDate(), selectDate(0));
		selectDropDownByText(newFutureTradesPage.getTrader(), trader);
		selectDropDownByText(newFutureTradesPage.getExchangeInstrument(), exchangeInstrument);
		selectDropDownByText(newFutureTradesPage.getPromptDeliveryDetailsType(), promptDeliveryDetailsType);
		selectDropDownByText(newFutureTradesPage.getPromptDeliveryDetailsName(), promptDeliveryDetailsName);
		selectDropDownByText(newFutureTradesPage.getTradeType(), "Sell");
		staticWait(2);
		enterText(newFutureTradesPage.getTradePrice(), tradePrice);
		selectDropDownByText(newFutureTradesPage.getTradePriceTypeUnitId(), tradePriceTypeUnitId);
		selectDropDownByText(newFutureTradesPage.getLotSize(), lotSize);
		enterText(newFutureTradesPage.getQuantity_Input(), quantity_Input);
		selectDropDownByText(newFutureTradesPage.getSettlementCurrency(), settlementCurrency);
		selectDropDownByText(newFutureTradesPage.getClearerProfileId(), clearerProfileId);
		selectDropDownByText(newFutureTradesPage.getClearerAccountId(), clearerAccountId);
		staticWait(2);

		/*Internal block*/
		selectDropDownByText(newFutureTradesPage.getProfitCenterId(), profitCenterId);
		selectDropDownByText(newFutureTradesPage.getStrategyId(), strategyId);
		selectDropDownByText(newFutureTradesPage.getPurposeId(), purposeId);
		if(purposeId.equalsIgnoreCase("Hedging")) {
			selectSingleListAndItem(newFutureTradesPage.getNomineearrow(), newFutureTradesPage.getSelectnominee(), nominee);
		}
		click(newFutureTradesPage.getCreateButton());
		staticWait(2);
		//Storing the createdBuyTradeRefNo in the result file
		storeResultsinFile(createdSellTradeRefNo, getText(newFutureTradesPage.getCreatedTradeRefNo()));
		click(newFutureTradesPage.getOk_button());
	}
}
