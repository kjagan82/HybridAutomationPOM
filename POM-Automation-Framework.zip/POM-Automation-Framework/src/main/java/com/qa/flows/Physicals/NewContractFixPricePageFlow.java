package com.qa.flows.Physicals;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.testng.Assert;
import com.qa.pages.Physicals.NewContractFixPricePage;
import com.qa.util.SeleniumLibs;

public class NewContractFixPricePageFlow extends SeleniumLibs{


	NewContractFixPricePage newcontractFixPricePage;
	SeleniumLibs newSeleniumUtils;

	public NewContractFixPricePageFlow(){
		newcontractFixPricePage = new NewContractFixPricePage();
	}

	private String trimChar(String value) {

		Pattern regex = Pattern.compile("(\\d+(?:\\.\\d+)?)");
		Matcher matcher = regex.matcher(value);

		String qntyFixedFullPriceEnter="";
		while(matcher.find()){
			qntyFixedFullPriceEnter  =qntyFixedFullPriceEnter+ matcher.group(1);
		} 
		return qntyFixedFullPriceEnter;
	}

	public void search_Contract(String contractRefNo) throws Exception {
		waitForAjax();
		click(newcontractFixPricePage.getContractMainFilter());
		staticWait(1);
		selectDropDownByText(newcontractFixPricePage.getFilterSearchSelect(), "Contract Ref.No.");
		enterText(newcontractFixPricePage.getFilterSearchInput(), contractRefNo);
		click(newcontractFixPricePage.getFilterGo());
		waitForAjax();	
		click(newcontractFixPricePage.getContractItemsCheckBox());
		staticWait(1);
		//Checking the text whether it is fixed r unfixed
		String priceFixText=getText(newcontractFixPricePage.getPriceFixationText());
		if(priceFixText.equalsIgnoreCase("Fixed")||priceFixText.equalsIgnoreCase("Fully Fixed")) {
			Assert.fail("Price Fixation is already Done!!!!!!!!!!!!!");
		}
		click(newcontractFixPricePage.getContractOperationsHeader());
		staticWait(1);
		click(newcontractFixPricePage.getFixPriceLabel());
	}

	public void Purchase_Con_Basis_Price_Fixation(String quantityFixedEnter,String futurePriceEnter,String FXBasisToPayInEnter,String futureMonth
			)throws Exception {

		waitForAjax();
		// getting contract Unfixed quantity
		selectDropDownByText(newcontractFixPricePage.getFutureMonth(), futureMonth);
		String quantityFixedFullPrice=getText(newcontractFixPricePage.getTotalQuantityToFix());
		enterText(newcontractFixPricePage.getQuantityFixedEnter(), trimChar(quantityFixedFullPrice));/*Will get the full quantity price fix*/
		
		//enterText(newcontractFixPricePage.getQuantityFixedEnter(), quantityFixedEnter); /*Used for partial price fix*/
		staticWait(1);
		enterText(newcontractFixPricePage.getFuturePriceEnter(), futurePriceEnter);
		staticWait(1);
		//enterText(newcontractFixPricePage.getFXBasisToPayInEnter(), FXBasisToPayInEnter);
		click(newcontractFixPricePage.getPriceFixationSave());
		waitForAjax();
		String PFRefNo=getText(newcontractFixPricePage.getPriceFixationRefNo());
		storeResultsinFile("purchasePriceFixRefNo", PFRefNo);
		staticWait(1);
		click(newcontractFixPricePage.getPriceFixationOk());
	}

	public void sale_Con_Basis_Price_Fixation(String quantityFixedEnter,String futurePriceEnter,String FXBasisToPayInEnter
			)throws Exception {

		waitForAjax();
		// getting contract Unfixed quantity
		String quantityFixedFullPrice=getText(newcontractFixPricePage.getTotalQuantityToFix());
		enterText(newcontractFixPricePage.getQuantityFixedEnter(), trimChar(quantityFixedFullPrice)); /*Will get the full quantity price fix*/

		//enterText(newcontractFixPricePage.getQuantityFixedEnter(), quantityFixedEnter); /*Used for partial price fix*/
		staticWait(1);
		enterText(newcontractFixPricePage.getFuturePriceEnter(), futurePriceEnter);
		staticWait(1);
		//enterText(newcontractFixPricePage.getFXBasisToPayInEnter(), FXBasisToPayInEnter);
		click(newcontractFixPricePage.getPriceFixationSave());
		waitForAjax();
		String PFRefNo=getText(newcontractFixPricePage.getPriceFixationRefNo());
		storeResultsinFile("SalePriceFixRefNo", PFRefNo);
		staticWait(1);
		click(newcontractFixPricePage.getPriceFixationOk());
	}
	
	public void production_Con_Basis_Price_Fixation(String quantityFixedEnter,String futurePriceEnter,String FXBasisToPayInEnter
			)throws Exception {

		waitForAjax();
		// getting contract Unfixed quantity
		String quantityFixedFullPrice=getText(newcontractFixPricePage.getTotalQuantityToFix());
		enterText(newcontractFixPricePage.getQuantityFixedEnter(), trimChar(quantityFixedFullPrice)); /*Will get the full quantity price fix*/

		//enterText(newcontractFixPricePage.getQuantityFixedEnter(), quantityFixedEnter); /*Used for partial price fix*/
		staticWait(1);
		enterText(newcontractFixPricePage.getFuturePriceEnter(), futurePriceEnter);
		staticWait(1);
		//enterText(newcontractFixPricePage.getFXBasisToPayInEnter(), FXBasisToPayInEnter);
		click(newcontractFixPricePage.getPriceFixationSave());
		waitForAjax();
		String PFRefNo=getText(newcontractFixPricePage.getPriceFixationRefNo());
		storeResultsinFile("ProductionPriceFixRefNo", PFRefNo);
		staticWait(1);
		click(newcontractFixPricePage.getPriceFixationOk());
	}


}
	
