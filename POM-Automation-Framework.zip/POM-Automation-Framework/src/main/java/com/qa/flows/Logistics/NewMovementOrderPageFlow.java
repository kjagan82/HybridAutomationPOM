package com.qa.flows.Logistics;
import java.util.Set;
import org.testng.Assert;
import com.qa.base.TestBaseListener;
import com.qa.pages.Logistics.NewMovementOrderPage;
import com.qa.util.SeleniumLibs;

public class NewMovementOrderPageFlow extends SeleniumLibs{
	
	String purchaseMovementPageTitle = "Create/Modify Purchase Movement Order";
	String saleMovementPageTitle = "Create/Modify Sales Movement Order";
	String internalMovementPageTitle = "Create/Modify Internal Movement Order";
	 
	NewMovementOrderPage newMovementOrderPage;

	public NewMovementOrderPageFlow(){
		newMovementOrderPage = new NewMovementOrderPage();
	}
	
	public void purchaseMovementTitle(){
		Assert.assertEquals(newMovementOrderPage.validateLoginPageTitle(), purchaseMovementPageTitle);
	}
	public void saleMovementTitle(){
		Assert.assertEquals(newMovementOrderPage.validateLoginPageTitle(), saleMovementPageTitle);
	}
	public void internalMovementTitle(){
		Assert.assertEquals(newMovementOrderPage.validateLoginPageTitle(), internalMovementPageTitle);
	}
	
	
	//only applicable for internal movement order
	public void int__MoveAgainstDiscrete_Stock_DropDown(String InternalDiscreteDropDown,String InternalConcreteDropDown) throws Exception{
		selectDropDownByText(newMovementOrderPage.movAgainstDropDown(), InternalDiscreteDropDown);
		
	}
	
	public void int__MoveAgainstConcrete_Stock_DropDown(String InternalDiscreteDropDown,String InternalConcreteDropDown) throws Exception{
		selectDropDownByText(newMovementOrderPage.movAgainstDropDown(), InternalConcreteDropDown);
		
	}
	
	public void create_modify_MovementOrder(String NewWinSearchSelect,String newwindowenter) throws Exception{
		
		click(newMovementOrderPage.getMovAgainstSearch());
		waitForAjax();
		
		//to Switch to opened Window
		String parentWindow = TestBaseListener.getDriver().getWindowHandle();
		Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

		for(String windowHandle  : handles)
		{
			if(!windowHandle.equals(parentWindow))
			{
				//performing actions inside new opened window
				TestBaseListener.getDriver().switchTo().window(windowHandle);
				TestBaseListener.getDriver().manage().window().maximize();
				click(newMovementOrderPage.getFilter());
				selectDropDownByText(newMovementOrderPage.getNewWinSearchSelect(), "Call Off Ref. No.");
				enterText(newMovementOrderPage.getNewWinSearchEnter(), newwindowenter);
				click(newMovementOrderPage.getNewWindowGo());
				staticWait(1);
				click(newMovementOrderPage.getNewWindowCallOffCheckBox());
				staticWait(2);
				click(newMovementOrderPage.getNewWindowCallOffOk());
				TestBaseListener.getDriver().switchTo().window(parentWindow); //cntrl to parent window
			}
		}
		waitForAjax();
	}
	
	public void matched_callOff_Details(String issueDate,String transportModeSelect) throws Exception {
		
		//selectDateFromDatePicker(newMovementOrderPage.getIssueDate(), issueDate);
		selectDropDownByText(newMovementOrderPage.getTransportModeSelect(), transportModeSelect);
		
	}
	
	public void movement_schedule_Details(String fromLocationSelect,String toLocationSelect,String scheduleNoDays,String scheduleLoadsDays,
			String frequency) throws Exception {
		selectSingleListAndItem(newMovementOrderPage.getFromLocation(), newMovementOrderPage.getFromLocationSelect(), fromLocationSelect);
		selectSingleListAndItem(newMovementOrderPage.getToLocation(), newMovementOrderPage.getToLocationSelect(), toLocationSelect);
		staticWait(1);
		click(newMovementOrderPage.getGenerateSchedule());
		staticWait(2);
		enterText(newMovementOrderPage.getScheduleNoDays(), scheduleNoDays);
		enterText(newMovementOrderPage.getScheduleLoadsDays(), scheduleLoadsDays);
		selectDropDownByText(newMovementOrderPage.getFrequency(), frequency);
		click(newMovementOrderPage.getScheduleOK());
		staticWait(1);
		click(newMovementOrderPage.getSave());
	}
	
	public void addAdditionDeduction(String contractStorageItem,String addDeleteNameSelect,String addDelete,String rateType,
			String rateEnter,String rateSelect,String weightBasis,String addRemarks) throws Exception{
		
	    waitForAjax();
		/*selectDropDownByIndex(newMovementOrderPage.getContractStorageItem(), 1);// dynamically it changes,so going with index
		selectSingleListAndItem(newMovementOrderPage.getAddDeleteName(), newMovementOrderPage.getAddDeleteNameSelect(), addDeleteNameSelect);
		staticWait(1);
		selectDropDownByText(newMovementOrderPage.getAddDelete(), addDelete);
		selectDropDownByText(newMovementOrderPage.getRateType(), rateType);
		enterText(newMovementOrderPage.getRateEnter(), rateEnter);
		staticWait(1);
		selectDropDownByText(newMovementOrderPage.getRateSelect(), rateSelect);
		selectDropDownByText(newMovementOrderPage.getWeightBasis(), weightBasis);
		enterText(newMovementOrderPage.getAddRemarks(), addRemarks);
		click(newMovementOrderPage.getAddDedRowButton());*/
		staticWait(1);
		//click(newMovementOrderPage.getSave());
		click(newMovementOrderPage.footerSave());
	}
	
	public void costEstimate(String schNoarrowSelect,String getCostCompName,String incomeExpense,
			String rateType,String costValueEnter,String costValueSelect,String FXbase,String costApplicableOn,
			String costEstimateRemarks) throws Exception{
		
		waitForAjax();
		staticWait(2);
		selectSingleListAndItemByIndex(newMovementOrderPage.getSchNoarrow(), newMovementOrderPage.getSchNoarrowSelect(), schNoarrowSelect);
		selectDropDownByText(newMovementOrderPage.getCostCompName(), getCostCompName);
		selectDropDownByText(newMovementOrderPage.getIncomeExpense(),incomeExpense);
		selectDropDownByText(newMovementOrderPage.getRateType(), rateType);
		enterText(newMovementOrderPage.getCostValueEnter(), costValueEnter);
		selectDropDownByText(newMovementOrderPage.getCostValueSelect(), costValueSelect);
		enterText(newMovementOrderPage.getFXbase(), FXbase);
		selectDropDownByText(newMovementOrderPage.getCostApplicableOn(),costApplicableOn);
		enterText(newMovementOrderPage.getCostEstimateRemarks(),costEstimateRemarks);
		staticWait(2);
		click(newMovementOrderPage.getAddCostEstimate());
		staticWait(1);
		click(newMovementOrderPage.getSaveCostEstimate());
		
	}
	
	public void purchaseMovementOrderNo() {
		waitForAjax();
		 String movementOrderNo = getText(newMovementOrderPage.getMovementOrderNo());
		 storeResultsinFile("purchaseMovementOrderNo", movementOrderNo);
		staticWait(1);
		//click(newMovementOrderPage.getNewWindowCallOffOk());
		click(newMovementOrderPage.movementOrderOk());
	}
	
	public void saleMovementOrderNo() {
		waitForAjax();
		 String movementOrderNo = getText(newMovementOrderPage.getMovementOrderNo());
		 storeResultsinFile("saleMovementOrderNo", movementOrderNo);
		staticWait(1);
		//click(newMovementOrderPage.getNewWindowCallOffOk());
		click(newMovementOrderPage.movementOrderOk());
	}
	
	public void internalMovementOrderNo() {
		waitForAjax();
		 String movementOrderNo = getText(newMovementOrderPage.getMovementOrderNo());
		 storeResultsinFile("internalMovementOrderNo", movementOrderNo);
		staticWait(1);
		//click(newMovementOrderPage.getNewWindowCallOffOk());
		click(newMovementOrderPage.movementOrderOk());
	}
	
	//verifying contract
	public void verifyMovementOrderListAllPage(String movementOrderNo) {
		waitForAjax();
		clickUsingJavaScript(newMovementOrderPage.getFilter());
		staticWait(1);
		selectDropDownByText(newMovementOrderPage.listPafeFilterSearch(), "Movement Request No."/*"Movement Order Ref. No."*/);
		enterText(newMovementOrderPage.listPafeFilterSearchEnter(),movementOrderNo);
		staticWait(2);
		click(newMovementOrderPage.moveOrderNoSearchGo());
		waitForAjax();
		if(getText(newMovementOrderPage.getVerifyMovOrderListAll()).equalsIgnoreCase(movementOrderNo)){
			TestBaseListener.suite_logs.info("Succesfully Verified  "+movementOrderNo+" presence !!! ");
		}
		else{
			TestBaseListener.suite_logs.info("Couldn't Verify  "+movementOrderNo+" presence !!!");	
			Assert.fail();
		}
	}
	
	
}
