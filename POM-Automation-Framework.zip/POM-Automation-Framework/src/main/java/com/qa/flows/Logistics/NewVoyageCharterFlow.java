package com.qa.flows.Logistics;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.qa.pages.Logistics.NewVoyageCharterPage;


public class NewVoyageCharterFlow {
	
	String pageTitle = "Voyage Charter";
	WebDriver driver;
	NewVoyageCharterPage newVoyageCharterPage;


	public NewVoyageCharterFlow(){
		//super();
		newVoyageCharterPage = new NewVoyageCharterPage();

	}


	public void loginPageTitle(){
		Assert.assertEquals(newVoyageCharterPage.validateLoginPageTitle(), pageTitle);
	}	

	public void newVoyageCharterform(String ExternalTradeRefNo) throws Exception{
		//Todays Day in the month
		//DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd");  
		//	LocalDateTime now = LocalDateTime.now();  
		//futureTradesPage.selectDateFromDatePicker(dtf.format(now));
		newVoyageCharterPage.selectDateFromDatePicker("01");
		newVoyageCharterPage.selectDropDownByText(newVoyageCharterPage.voyageQuantityUnit(),"Acres");
		newVoyageCharterPage.capacityBookedTextField("10");
		Thread.sleep(2000);
		newVoyageCharterPage.selectDropDownByText(newVoyageCharterPage.capacityBookedSelect(),"Acres");
		newVoyageCharterPage.loadingPort();
		newVoyageCharterPage.loadingPortSelect();
		newVoyageCharterPage.dischargePort();
		Thread.sleep(2000);
		newVoyageCharterPage.dischargeSelect();
		newVoyageCharterPage.save();
	}



}
