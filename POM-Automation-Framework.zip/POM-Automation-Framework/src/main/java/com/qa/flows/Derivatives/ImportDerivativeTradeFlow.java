package com.qa.flows.Derivatives;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.qa.base.TestBaseListener;
import com.qa.pages.Derivatives.ImportDerivativeTradePage;
import com.qa.util.SeleniumLibs;

public class ImportDerivativeTradeFlow extends SeleniumLibs {

	String pageTitle = "Import";
	WebDriver driver;
	ImportDerivativeTradePage importDerivativeTradePage ;
	String derivativeImportTradeRefNo = "DerivativeImportTradeRefNo";


	public ImportDerivativeTradeFlow(){
		//super();
		importDerivativeTradePage = new ImportDerivativeTradePage();
		
	}


	public void importDerivativeTicket() throws Exception{
		waitForAjax();
		
		click(importDerivativeTradePage.operations());
		click(importDerivativeTradePage.importDerivaticeTrade());
		//to switch to opened window for Choose File
		waitForAjax();
				String parentWindow = TestBaseListener.getDriver().getWindowHandle();
				Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

				for(String windowHandle  : handles)
				{
					if(!windowHandle.equals(parentWindow) )
					{
						TestBaseListener.getDriver().switchTo().window(windowHandle);
						String newPageTitle=TestBaseListener.getDriver().getTitle();
						if(pageTitle.equalsIgnoreCase(newPageTitle)) {
						staticWait(2);
						waitForAjax(); 
						uploadFile(importDerivativeTradePage.chooseFile(), "Future ImportData.csv");   // Date Format : DD-MMM-YYYY or MMM-YYYY
						Thread.sleep(2000);
						click(importDerivativeTradePage.readFile());
						Thread.sleep(2000);
						click(importDerivativeTradePage.ok());
						TestBaseListener.getDriver().switchTo().window(parentWindow); //control to parent window
						}
						else {
							Assert.fail("Page Title Mismatch");
						}
					}	
			}
				storeResultsinFile(derivativeImportTradeRefNo, getText(importDerivativeTradePage.tradeRefNo()));
				click(importDerivativeTradePage.ok());
				click(importDerivativeTradePage.filter());
				staticWait(1);
				click(importDerivativeTradePage.reset());
				enterText(importDerivativeTradePage.searchTradeRefNo(),getStoredResultsfromFile(derivativeImportTradeRefNo));
				click(importDerivativeTradePage.go());
		}
}
