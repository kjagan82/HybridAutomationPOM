package com.qa.flows.Logistics;

import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.ClickAction;

import com.qa.base.TestBaseListener;
import com.qa.pages.Logistics.NewCallOffPage;
import com.qa.util.SeleniumLibs;

public class NewCallOffPageFlow extends SeleniumLibs{

	String createdAllocation="Allocationrefno";

	NewCallOffPage newCallOffPage;

	public NewCallOffPageFlow(){ 
		newCallOffPage = new NewCallOffPage();
	}

	public void search_Contract(String contractRefNo)throws Exception{
		waitForAjax();
		clickUsingJavaScript(newCallOffPage.getSearchFilter());
		staticWait(1);
		click(newCallOffPage.getButtonReset());
		selectDropDownByText(newCallOffPage.getSearchCriteria(),"Contract Ref.No.");
		enterText(newCallOffPage.getSearchText(),contractRefNo);
		click(newCallOffPage.getButtonGo());
		waitForAjax();
		click(newCallOffPage.getCheckAll());

	}

	public void purchaseCallofflink()throws Exception{
		waitForAjax();
		click(newCallOffPage.getButtonPurchaseOperation());
		click(newCallOffPage.getLinkPurchaseCallOff());	

	}

	public void salesCallofflink()throws Exception{
		waitForAjax();
		click(newCallOffPage.getButtonSalesOperation());
		click(newCallOffPage.getLinkSalesCallOff());	

	}

	public void ProductionCallofflink()throws Exception{
		waitForAjax();
		click(newCallOffPage.getButtonPurchaseOperation());
		click(newCallOffPage.getLinkPurchaseCallOff());		

	}

	public void allCalloff(String ExternalcalloffRefNo,String CalloffType,String calloffBy,String personIncharge,
			String secondIncharge,String qualityProductDetailsSelect,String packingType,String calloffQty,String transportMode,String unloadrefno,String transportCompany,
			String transportAgent,String dropoffTime,String expectedPickUpLocationSelect,String locationSelect,String address,String remarks,String newQuantityEntry,
			String callOffType)throws Exception{
		waitForAjax();



		//Details//
		waitForAjax();
		selectDateFromDatePicker(newCallOffPage.getContractIssueDate(),selectDate(0));
		click(newCallOffPage.getContractIssueDate());
		enterText(newCallOffPage.getExternalcalloffRefNo(),ExternalcalloffRefNo);
		selectDropDownByText(newCallOffPage.getCalloffType(),CalloffType);
		selectDropDownByText(newCallOffPage.getCalloffBy(),calloffBy);
		selectDropDownByText(newCallOffPage.getPersonIncharge(),personIncharge);
		selectDropDownByText(newCallOffPage.getSecondIncharge(),secondIncharge);


		//ProductDetails//
		waitForAjax();
		selectSingleListAndItem(newCallOffPage.getQualityProductDetails(),newCallOffPage.getQualityProductDetailsSelect(),qualityProductDetailsSelect);
		//selectDropDownByText(newCallOffPage.getBrand(),brand);
		//selectSingleListAndItem(newCallOffPage.getProductionFacility(),newCallOffPage.getProductionFacilitySelect(),productionFacilitySelect);
		selectDropDownByText(newCallOffPage.getPackingType(),packingType);
		//selectDropDownByText(newCallOffPage.getPackingSize(),packngSize);
		enterText(newCallOffPage.getCalloffQty(),calloffQty);


		//TransportDetails//
		waitForAjax();
		selectDropDownByText(newCallOffPage.getTransportMode(),transportMode);
		enterText(newCallOffPage.getUnloadrefno(),unloadrefno);
		selectDropDownByText(newCallOffPage.getTransportCompany(),transportCompany);
		selectDropDownByText(newCallOffPage.getTransportAgent(),transportAgent);
		selectDateFromDatePicker(newCallOffPage.getDropOffDateFrom(),selectDate(2));
		click(newCallOffPage.getDropOffDateFrom());
		selectDateFromDatePicker(newCallOffPage.getDropOffDateTo(),selectDate(2));
		click(newCallOffPage.getDropOffDateTo());
		enterText(newCallOffPage.getDropoffTime(),dropoffTime);
		//selectSingleListAndItem(newCallOffPage.getExpectedPickUpLocation(),newCallOffPage.getExpectedPickUpLocationSelect(),expectedPickUpLocationSelect);
		selectDateFromDatePicker(newCallOffPage.getExpectedPickUpDate(),selectDate(2));	
		selectSingleListAndItem(newCallOffPage.getLocation(),newCallOffPage.getLocationSelect(),locationSelect);
		enterText(newCallOffPage.getAddress(),address);
		enterText(newCallOffPage.getRemarks(),remarks);
		click(newCallOffPage.getSaveButton());
		//click(newCallOffPage.getCancelButton());


		//contractApplicationandView//
		waitForAjax();
		storeCallOffRefNo(callOffType);/* Storing CallOff */
		doubleClick(newCallOffPage.getNewQuantity());
		enterText(newCallOffPage.getNewQuantityEntry(),newQuantityEntry);
		click(newCallOffPage.getSaveConApp());
		//click(newCallOffPage.getCancelConApp());
		click(newCallOffPage.getBackview());
	}		



	private void storeCallOffRefNo(String callOffType) {
		String callOffRefNo = getText(newCallOffPage.getCallOffRefNo());
		storeResultsinFile(callOffType, callOffRefNo);
		staticWait(1);
	}

	public void matchCallOff(String Purchasecalloffqty,String QtytoallocateT1,String SaleCallOff,String Purchasecalloff)throws Exception{
		waitForAjax();

		//Filtercontractinlistofcalloff//
		waitForAjax();
		click(newCallOffPage.getSearchFilterLOCO());
		click(newCallOffPage.getButtonResetLOCO());
		selectDropDownByText(newCallOffPage.getSearchTypeLOCO(),"Call Off Ref. No.");
		enterText(newCallOffPage.getSearchTextLOCO(),SaleCallOff);
		click(newCallOffPage.getButtonGoLOCO());
		waitForAjax();
		click(newCallOffPage.getCelllinkCalloffrefno());
		waitForAjax();
		click(newCallOffPage.getSchedule());
		click(newCallOffPage.getMatchCallOffbtn());

		//MatchCallOff//

		selectDateFromDatePicker(newCallOffPage.getAllocationDate(),selectDate(0));
		waitForAjax();
		/*enterText(newCallOffPage.getTypeSalesCalloff(),SaleCallOff);
		click(newCallOffPage.getSalesCalloffGo());*/
		waitForAjax();
		selectDropDownByText(newCallOffPage.getSelectSource(),"Purchase Call Off");
		enterText(newCallOffPage.getTypeSource(),Purchasecalloff);
		click(newCallOffPage.getSourceGo());
		waitForAjax();
		enterText(newCallOffPage.getQuanityToAllocate(),Purchasecalloffqty);
		click(newCallOffPage.getAddAllocation());
		waitForAjax();
		enterText(newCallOffPage.getQtyToAllocate1InTable(),QtytoallocateT1);
		click(newCallOffPage.getAllocationBtnSave());
		waitForAjax();
		click(newCallOffPage.getAllocationBtnOk());
		waitForAjax();

		//ListofMatchCalloff//

		click(newCallOffPage.getSearchFilterLOMC());
		click(newCallOffPage.getButtonResetLOMC());
		selectDropDownByText(newCallOffPage.getSearchTypeLOMC(),"Call Off Ref. No.");
		enterText(newCallOffPage.getSearchTextLOMC(),SaleCallOff);
		click(newCallOffPage.getButtonGoLOMC());
		//Storing the createdAllocationrefno in the result file
		storeResultsinFile(createdAllocation, getText(newCallOffPage.getallocationrefno()));
	}

	public void AlltypeofStocks(String Purchasecalloffrefno,String Discretestockrefno,
			String Consolidatedstockrefno,String Dstkqty,String cstkqty,String Purchasecalloffqty,String QtytoallocateT1,String QtytoallocateT2,String QtytoallocateT3)throws Exception{
		waitForAjax();

		for(int i=1;i<=3;i++) {

			staticWait(2);
			if(i==1) {
				selectDropDownByIndex(newCallOffPage.getSelectSource(), i);
				enterText(newCallOffPage.getTypeSource(),Purchasecalloffrefno);
				click(newCallOffPage.getSourceGo());
				enterText(newCallOffPage.getQuanityToAllocate(),Purchasecalloffqty);
			}
			else if(i==2) {
				selectDropDownByIndex(newCallOffPage.getSelectSource(), i);
				enterText(newCallOffPage.getTypeSource(),Discretestockrefno);
				click(newCallOffPage.getSourceGo());
				enterText(newCallOffPage.getQuanityToAllocate(),Dstkqty);
			}
			else if(i==3) {
				selectDropDownByIndex(newCallOffPage.getSelectSource(), i);
				enterText(newCallOffPage.getTypeSource(),Consolidatedstockrefno);
				click(newCallOffPage.getSourceGo());
				enterText(newCallOffPage.getQuanityToAllocate(),cstkqty);
			}

			click(newCallOffPage.getAddAllocation());
			enterText(newCallOffPage.getQtyToAllocate1InTable(),QtytoallocateT1);
			enterText(newCallOffPage.getQtyToAllocate1InTable(),QtytoallocateT2);
			enterText(newCallOffPage.getQtyToAllocate1InTable(),QtytoallocateT3);
			click(newCallOffPage.getAllocationBtnSave());
			click(newCallOffPage.getAllocationBtnOk());


		}

	}


	public void OutputDocument(String Calloffrefno)throws Exception{
		waitForAjax();
		//Filtercontractinlistofcalloff//
		waitForAjax();
		click(newCallOffPage.getSearchFilterLOCO());
		click(newCallOffPage.getButtonResetLOCO());
		selectDropDownByText(newCallOffPage.getSearchTypeLOCO(),"Call Off Ref. No.");
		enterText(newCallOffPage.getSearchTextLOCO(),Calloffrefno);
		click(newCallOffPage.getButtonGoLOCO());
		waitForAjax();
		click(newCallOffPage.getCelllinkCalloffrefno());
		waitForAjax();
        click(newCallOffPage.getLinkDocument());
		click(newCallOffPage.getBtnGenerateandPrint());
		
		//to switch to opened window to download outputdoc
				String parentWindow = TestBaseListener.getDriver().getWindowHandle();
				Set<String> handles =  TestBaseListener.getDriver().getWindowHandles();

				for(String windowHandle  : handles)
				{
					if(!windowHandle.equals(parentWindow))
					{
						TestBaseListener.getDriver().switchTo().window(windowHandle);
						TestBaseListener.getDriver().switchTo().window(windowHandle).close();;
						TestBaseListener.getDriver().switchTo().window(parentWindow); //cntrl to parent window
						
					}
				}
			}

}











