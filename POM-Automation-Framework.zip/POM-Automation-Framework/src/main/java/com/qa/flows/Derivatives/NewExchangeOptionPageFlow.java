package com.qa.flows.Derivatives;

import org.testng.Assert;

import com.qa.pages.Derivatives.NewExchangeOptionPage;
import com.qa.util.SeleniumLibs;

public class NewExchangeOptionPageFlow extends SeleniumLibs{

	String pageTitle = "Exchange Option";
	NewExchangeOptionPage newExchangeOptionPage;

	String createdOptionTradeRefNo="BuyExchangeOptionTradeRefNo";
	String createdSellOptionTradeRefNo="SellExchangeOptionTradeRefNo";

	public NewExchangeOptionPageFlow(){
		newExchangeOptionPage = new NewExchangeOptionPage();
	}

	public void loginPageTitle(){
		waitForAjax();
		Assert.assertEquals(newExchangeOptionPage.validateLoginPageTitle(), pageTitle);
	}


	public void fillNewExchangeOptionDetails(String tradeRefNo,String externalTradeRefNo,String trader,
			String exchangeInstrument,String promptDeliveryDetailsType,String getPromptDeliveryDetailsName,
			String tradeType,String lotSize,String quantity_Input,String settlementCurrency,String strikePrice,
			String strikePriceUnit,String premiumDiscount,String premiumDiscountPriceUnit,String clearerProfile,
			String clearerAccount,String broker,String brokerCommType,String profitCenter,String strategy,
			String purpose,String selectnominee) {

		waitForAjax();
		//enterText(newExchangeOptionPage.getTradeRefNo(), tradeRefNo);
		enterText(newExchangeOptionPage.getExternalTradeRefNo(), externalTradeRefNo);
		selectDateFromDatePicker(newExchangeOptionPage.getTradeDate(), selectDate(0));
		selectDropDownByText(newExchangeOptionPage.getTrader(), trader);
		selectDropDownByText(newExchangeOptionPage.getExchangeInstrument(), exchangeInstrument);
		selectDropDownByText(newExchangeOptionPage.getPromptDeliveryDetailsType(), promptDeliveryDetailsType);
		selectDropDownByText(newExchangeOptionPage.getPromptDeliveryDetailsName(), getPromptDeliveryDetailsName);
		selectDropDownByText(newExchangeOptionPage.getTradeType(), tradeType);
		selectDropDownByText(newExchangeOptionPage.getLotSize(), lotSize);
		enterText(newExchangeOptionPage.getQuantity_Input(), quantity_Input);
		selectDropDownByText(newExchangeOptionPage.getSettlementCurrency(), settlementCurrency);
		enterText(newExchangeOptionPage.getStrikePrice(), strikePrice);
		selectDropDownByText(newExchangeOptionPage.getStrikePriceUnitId(), strikePriceUnit);
		enterText(newExchangeOptionPage.getPremiumDiscount(), premiumDiscount);
		selectDropDownByText(newExchangeOptionPage.getPremiumDiscountPriceUnit(), premiumDiscountPriceUnit);
		selectDropDownByText(newExchangeOptionPage.getClearerProfileId(), clearerProfile);
		selectDropDownByText(newExchangeOptionPage.getClearerAccountId(), clearerAccount);
		selectDropDownByText(newExchangeOptionPage.getBroker(), broker);
		selectDropDownByText(newExchangeOptionPage.getBrokerCommType(), brokerCommType);


		/*Internal*/
		selectDropDownByText(newExchangeOptionPage.getProfitCenterId(), profitCenter);
		selectDropDownByText(newExchangeOptionPage.getStrategyId(), strategy);
		selectDropDownByText(newExchangeOptionPage.getPurposeId(), purpose);

		if(purpose.equalsIgnoreCase("Hedging")) {
			selectSingleListAndItem(newExchangeOptionPage.getNomineearrow(), newExchangeOptionPage.getSelectnominee(), selectnominee);
		}
		click(newExchangeOptionPage.getCreateButton());
		staticWait(2);
		//Storing the createdFxTradeRefNo in the result file
		if(tradeType.equalsIgnoreCase("Buy")) {
			storeResultsinFile(createdOptionTradeRefNo, getText(newExchangeOptionPage.getCreatedTradeRefNo()));
		}else if(tradeType.equalsIgnoreCase("Sell")) {
			storeResultsinFile(createdSellOptionTradeRefNo, getText(newExchangeOptionPage.getCreatedTradeRefNo()));
		}

		click(newExchangeOptionPage.getOk_button());

	}


}
