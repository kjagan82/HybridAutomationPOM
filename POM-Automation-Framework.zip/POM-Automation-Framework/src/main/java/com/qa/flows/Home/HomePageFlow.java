/**
 * 
 */
package com.qa.flows.Home;

import org.testng.Assert;

import com.qa.pages.Home.HomePage;
import com.qa.pages.Physicals.NewContractPage;
import com.qa.util.SeleniumLibs;

/**
 * @author jaganmohan.k
 *
 */
public class HomePageFlow extends SeleniumLibs{

	String pageTitle = "Home";

	HomePage homePage;

	public HomePageFlow(){
		//super();
		homePage = new HomePage();
	}

	public void homePageTitle(){
		staticWait(3);
		Assert.assertEquals(homePage.verifyHomePageTitle(), pageTitle);
	}
	public void verifyCorrectUserName(String user){
		Assert.assertTrue(homePage.verifyCorrectUserName(user));
	}

	public void clickOnNewFuture() {
		navigateToHomePage();
		staticWait(3);
		click(homePage.getDerivativesLabel());
		mouseHoverJScript(homePage.getTradesLabel());
		mouseHoverJScript(homePage.getFuturesLabel());
		mouseHoverJScript(homePage.getNewFutureLabel());
		click(homePage.getNewFutureLabel());

	}

	public void clickOnNewExchangeOption() {
		navigateToHomePage();
		staticWait(3);
		click(homePage.getDerivativesLabel());
		mouseHoverJScript(homePage.getTradesLabel());
		mouseHoverJScript(homePage.getExchangeOptionsLabel());
		mouseHoverJScript(homePage.getNewExchangeLabel());
		click(homePage.getNewExchangeLabel());
	}

	public void clickOnNewOTCOption() {
		navigateToHomePage();
		staticWait(3);
		click(homePage.getDerivativesLabel());
		mouseHoverJScript(homePage.getTradesLabel());
		mouseHoverJScript(homePage.getOtcOptionsLabel());
		mouseHoverJScript(homePage.getNewOtcOptionLabel());
		click(homePage.getNewOtcOptionLabel());
	}

	public void clickOnNewFxTrade() {
		navigateToHomePage();
		staticWait(3);
		click(homePage.getDerivativesLabel());
		mouseHoverJScript(homePage.getFxTradesLabel());
		mouseHoverJScript(homePage.getFxForwardLabel());
		mouseHoverJScript(homePage.getNewFxTradesLabel());
		click(homePage.getNewFxTradesLabel());
	}

	public void newVoyageCharter() {
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getPlanningLabel());
		mouseHoverJScript(homePage.getOceanTransportBookingLabel());
		mouseHoverJScript(homePage.getVoyageBookingLabel());
		mouseHoverJScript(homePage.getNewVoyageCharterLabel());
		click(homePage.getNewVoyageCharterLabel());
	}

	public void newPurchaseContract(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getContractLabel());
		mouseHoverJScript(homePage.getNewPurchaseLabel());
		click(homePage.getNewPurchaseLabel());
	}

	public void newSaleContract(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getContractLabel());
		mouseHoverJScript(homePage.getNewSaleLabel());
		click(homePage.getNewSaleLabel());
	}
	public void newProductionContract(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getContractLabel());
		mouseHoverJScript(homePage.getNewPurchaseLabel());
		click(homePage.getNewPurchaseLabel());
	}

	public void newPurchaseMovementOrder(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getPlanningLabel());
		mouseHoverJScript(homePage.getLandTransportBookingLabel());
		mouseHoverJScript(homePage.getCreatePurchaseMovementOrderLabel());
		click(homePage.getCreatePurchaseMovementOrderLabel());
	}

	public void newSaleMovementOrder(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getPlanningLabel());
		mouseHoverJScript(homePage.getLandTransportBookingLabel());
		mouseHoverJScript(homePage.getCreateSalesMovementOrderLabel());
		click(homePage.getCreateSalesMovementOrderLabel());
	}

	public void newInternalMovementOrder(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getPlanningLabel());
		mouseHoverJScript(homePage.getLandTransportBookingLabel());
		mouseHoverJScript(homePage.getCreateInternalMovementOrderLabel());
		click(homePage.getCreateInternalMovementOrderLabel());
	}

	public void newPlannedContainerShipment(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getPlanningLabel());
		mouseHoverJScript(homePage.getOceanTransportBookingLabel());
		mouseHoverJScript(homePage.getPlannedContainerShipmentLabel());
		mouseHoverJScript(homePage.getNewPlannedContainerShipmentLabel());
		click(homePage.getNewPlannedContainerShipmentLabel());
	}

	public void newImportTicket(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getTickets());
		mouseHoverJScript(homePage.getInboundOutbound());
		mouseHoverJScript(homePage.getTicketImport());
		click(homePage.getTicketImport());
	}

	public void newPrePaymentInvoice(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getContractLabel());
		mouseHoverJScript(homePage.getOpenContractItemLabel());
		click(homePage.getOpenContractItemLabel());
	}

	public void newServiceInvoice(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getAccountingLabel());
		mouseHoverJScript(homePage.getSecondaryCostsLabel());
		mouseHoverJScript(homePage.getAccrualsecondaryCostsLabel());
		click(homePage.getAccrualsecondaryCostsLabel());

	}

	public void newGeneralServiceInvoiceReceived(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getAccountingLabel());
		mouseHoverJScript(homePage.getMonthlyCostsLabel());
		mouseHoverJScript(homePage.getServiceInvReceivedLabel());
		click(homePage.getServiceInvReceivedLabel());

	}

	public void newGeneralServiceInvoiceRaised(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getAccountingLabel());
		mouseHoverJScript(homePage.getMonthlyCostsLabel());
		mouseHoverJScript(homePage.getServiceInvRaisedLabel());
		click(homePage.getServiceInvRaisedLabel());

	}

	public void OpenContractItems(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getLogisticContractLabel());
		mouseHoverJScript(homePage.getOpenContractItemLabel());
		click(homePage.getOpenContractItemLabel());
	}

	public void newProvisionalInvoice(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getAccountingLabel());
		mouseHoverJScript(homePage.getInvoicableItemsLabel());
		click(homePage.getInvoicableItemsLabel());
	}
	public void physicalContractItems(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getContractItemsLabel());
		click(homePage.getContractItemsLabel());

	}
	public void derivaticeImportTicket(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getDerivativesLabel());
		mouseHoverJScript(homePage.getTradesLabel());
		mouseHoverJScript(homePage.getFuturesLabel());
		mouseHoverJScript(homePage.getListAll());
		click(homePage.getListAll());
	}

	public void ContractItemListAll(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getContractItemsLabel());
		mouseHoverJScript(homePage.getListAll());
		click(homePage.getListAll());
	}

	public NewContractPage ContractsListAll(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getContractLabel());
		mouseHoverJScript(homePage.getListAll());
		click(homePage.getListAll());
		return new NewContractPage();
	}

	public void ContractsDrafts(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getContractDraftsLabel());
		click(homePage.getContractDraftsLabel());
	}
	
	public void newContractTemplate(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getContractTemplatesLabel());
		mouseHoverJScript(homePage.getNewcontractTemplatesLabel());
		click(homePage.getNewcontractTemplatesLabel());
	}
	
	public void allMovementsNew(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getAllMovementsLabel());
		mouseHoverJScript(homePage.getListAllMovements());
		click(homePage.getListAllMovements());
	}
	
	public void newPurchasePrintableTemplate(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getPrintableTemplateLabel());
		mouseHoverJScript(homePage.getNewPurchasePrintTemplatesLabel());
		click(homePage.getNewPurchasePrintTemplatesLabel());
	}
	
	public void newsalePrintableTemplate(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getPrintableTemplateLabel());
		mouseHoverJScript(homePage.getNewSalePrintTemplatesLabel());
		click(homePage.getNewSalePrintTemplatesLabel());
	}
	
	public void listAllPrintableTemplate(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getPhysicalsLabel());
		mouseHoverJScript(homePage.getPrintableTemplateLabel());
		mouseHoverJScript(homePage.getListAllPrintableTemplates());
		click(homePage.getListAllPrintableTemplates());
	}
	
	public void ListOfCallOff(){
		navigateToHomePage();
		staticWait(3);
		click(homePage.getLogisticsLabel());
		mouseHoverJScript(homePage.getPlanningLabel());
		mouseHoverJScript(homePage.getCallOffLabel());
		mouseHoverJScript(homePage.getListAll());
		click(homePage.getListAll());
	}
	
}


