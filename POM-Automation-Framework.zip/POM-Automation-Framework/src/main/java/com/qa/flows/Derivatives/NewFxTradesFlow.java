package com.qa.flows.Derivatives;

import org.testng.Assert;

import com.qa.pages.Derivatives.NewFxTradesPage;
import com.qa.util.SeleniumLibs;
	
/**
 * @author jaganmohan.k
 *
 */
public class NewFxTradesFlow extends SeleniumLibs{

	String pageTitle = "New FX Trade";
	NewFxTradesPage newFxTradesPage;
	String createdBuyFxTradeRefNo="BuyFxTradeRefNo";
	String createdSellFxTradeRefNo="SellFxTradeRefNo";

	public NewFxTradesFlow(){
		newFxTradesPage = new NewFxTradesPage();
	}

	public void loginPageTitle(){
		staticWait(3);
		Assert.assertEquals(newFxTradesPage.validateLoginPageTitle(), pageTitle);
	}


	/**
	 * @param trader
	 * @param exchangeInstrument
	 * @param CounterParty
	 * @param PaymentTerms
	 * @param TradeType
	 * @param Amount
	 * @param ExchangeRate
	 * @param BankName
	 * @param BankAccount
	 * @param BankCharges
	 * @param BankChargesType
	 * @param bankChargesCurrency
	 * @param ProfitCenter
	 * @param Strategy
	 * @param Purpose
	 * @param Nominee
	 */
	public void fillNewFxTradesDetails(String trader,String exchangeInstrument,String CounterParty,
			String PaymentTerms,String TradeType,String Amount,String ExchangeRate,String BankName,String BankAccount,
			String BankCharges,String BankChargesType,String bankChargesCurrency,String ProfitCenter,
			String Strategy,String Purpose,String Nominee) {
		
		//FX Forward Contract Detail
		
		selectDateFromDatePicker(newFxTradesPage.getTradeDate(),selectDate(-1));
		selectDropDownByText(newFxTradesPage.getTrader(), trader);
		selectDateFromDatePicker(newFxTradesPage.getValueDate(),selectDate(-1));
		selectDropDownByText(newFxTradesPage.getCurrencyInstrument(), exchangeInstrument);
		selectDateFromDatePicker(newFxTradesPage.getSettlementFromDate(),selectDate(-1));
		selectSingleListAndItem(newFxTradesPage.getCounterPartyArrow(), newFxTradesPage.getCounterPartyUL(), CounterParty);
		selectDropDownByText(newFxTradesPage.getPaymentTermsId(), PaymentTerms);
		//selectDateFromDatePicker(newFxTradesPage.getPaymentDueDate(),selectDate(0));
		staticWait(1);
		//FX Trade 1 Details
		selectDropDownByText(newFxTradesPage.getFxTrade1Type(), TradeType);
		enterText(newFxTradesPage.getAmount(), Amount);
		enterText(newFxTradesPage.getExchangeRate(), ExchangeRate);
		staticWait(1);
		//FX Trade 2 Details
		selectDropDownByText(newFxTradesPage.getBankId(), BankName);
		enterText(newFxTradesPage.getBankCharges(), BankCharges);
		selectDropDownByText(newFxTradesPage.getBankAccountId(), BankAccount);
		selectDropDownByText(newFxTradesPage.getBankChargesType(), BankChargesType);
		if(BankChargesType.equalsIgnoreCase("Absolute")) {
			selectDropDownByText(newFxTradesPage.getBankChargesCurId(), bankChargesCurrency);
		}
		staticWait(1);
		/*Internal block*/
		selectDropDownByText(newFxTradesPage.getProfitCenterId(), ProfitCenter);
		selectDropDownByText(newFxTradesPage.getStrategyId(), Strategy);
		selectDropDownByText(newFxTradesPage.getPurposeId(), Purpose);
		if(Purpose.equalsIgnoreCase("Hedging")) {
			selectDropDownByText(newFxTradesPage.getNominee(), Nominee);
		}
		click(newFxTradesPage.getCreateButton());
		staticWait(2);
		//Storing the createdFxTradeRefNo in the result file
		if(TradeType.equalsIgnoreCase("Buy")) {
			storeResultsinFile(createdBuyFxTradeRefNo, getText(newFxTradesPage.getCreatedTradeRefNo()));
		}else if(TradeType.equalsIgnoreCase("Sell")) {
			storeResultsinFile(createdSellFxTradeRefNo, getText(newFxTradesPage.getCreatedTradeRefNo()));
		}
		
		click(newFxTradesPage.getOk_button());
	}


}
