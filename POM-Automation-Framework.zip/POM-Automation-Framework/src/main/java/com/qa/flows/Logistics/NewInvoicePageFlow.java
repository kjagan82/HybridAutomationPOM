package com.qa.flows.Logistics;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import com.qa.base.TestBaseListener;
import com.qa.pages.Accounting.NewProvisionalInvoicePage;
import com.qa.pages.Logistics.NewInvoicePage;
import com.qa.util.SeleniumLibs;

public class NewInvoicePageFlow extends SeleniumLibs{

	//String purchaseMovementPageTitle = "Create/Modify Purchase Movement Order";

	NewInvoicePage newInvoicePage;
	NewProvisionalInvoicePage newProvisionalInvoicePage;
	Actions a;

	public NewInvoicePageFlow(){
		newInvoicePage = new NewInvoicePage();

		newProvisionalInvoicePage=new NewProvisionalInvoicePage();
	}

	//to filter the particular Prepayment invoice type
	public void select_PrePayment_Invoice(String contractNo,String filterSearchSelect) throws Exception{
		waitForAjax();
		staticWait(3);
		clickUsingJavaScript(newInvoicePage.getMainFilter());
		//click(newInvoicePage.getMainFilter());
		staticWait(1);
		selectDropDownByText(newInvoicePage.getFilterSearchSelect(), filterSearchSelect);
		staticWait(1);
		//getting data from config
		enterText(newInvoicePage.getFilterSearchInput(), contractNo);
		staticWait(1);
		click(newInvoicePage.getFilterGo());
		waitForAjax();
		click(newInvoicePage.getContractCheckBox());
		staticWait(1);

	}


	public void prePayment_Invoice(String CPInvoiceRefENter,String dueDatePrePayment,String accountingDatePrePayment)
			throws Exception{

		click(newInvoicePage.getInvoiceHeader());
		staticWait(1);
		click(newInvoicePage.getPrePaymentInvLabel());
		waitForAjax();
		
		Alert alert=TestBaseListener.getDriver().switchTo().alert();
		alert.accept();
		
		selectDateFromDatePicker(newInvoicePage.getIssueDatePrePayment(),selectDate(0));
		enterText(newInvoicePage.getCPInvoiceRefENter(), CPInvoiceRefENter);
		selectDateFromDatePicker(newInvoicePage.getDueDatePrePayment(), selectDate(2));
		selectDateFromDatePicker(newInvoicePage.getAccountingDatePrePayment(), selectDate(0));
	}

	public void prePayment_PayMent_Instruction(String bankNamePrePaymentSelect,String accountNamePrePaymentSelect) 
			throws Exception{
		selectDropDownByText(newInvoicePage.getBankNamePrePaymentSelect(), bankNamePrePaymentSelect);
		selectDropDownByText(newInvoicePage.getAccountNamePrePaymentSelect(), accountNamePrePaymentSelect);
		click(newInvoicePage.getAddRowButton());
		staticWait(2);
		click(newInvoicePage.getSavePrePaymentInvoice());

	}
	public void getPrePaymentInvoiceNo() throws Exception{
		waitForAjax();
		String InvoiceRefNo = getText(newInvoicePage.getRefNoPrePaymentInvoice());
		storeResultsinFile("Pre_Payment_InvoiceNo", InvoiceRefNo);
		click(newInvoicePage.getRefNoPrePaymentInvoiceOK());

	}

	//to filter the particular service invoice type
	public void select_Service_Invoice(String GMRRefNo,String filterSearchSelect) throws Exception{

		waitForAjax();
		staticWait(2);
		clickUsingJavaScript(newInvoicePage.getMainFilter());
		//click(newInvoicePage.getMainFilter());
		staticWait(1);
		selectDropDownByText(newInvoicePage.getFilterSearchSelect(), filterSearchSelect);
		staticWait(1);
		//getting data from config
		enterText(newInvoicePage.getFilterSearchInput(), GMRRefNo);
		staticWait(1);
		click(newInvoicePage.getFilterGo());
		waitForAjax();
		click(newInvoicePage.getContractCheckBox());
		staticWait(1);

	}
	//will get the text to decide Invoice or Expense
	public void create_Income_Expense(String CPInvoiceRefENter,String CpReceivedInvSelect,String CpRaisedInvSelect,String invoiceCurrencySelect,
			String taxSchedAppCountryReceivedInv,String taxSchedReceivedInv,String costReceivedInvSelect,
			String actualCostReceivedInvEnter,String bankNamePrePaymentSelect,String accountNamePrePaymentSelect)throws Exception {
		staticWait(1);
		String option=getText(newInvoicePage.getIncomeExpenseText());

		try {
			if(option.equalsIgnoreCase("Expense")/*will create Service Invoice Received*/) {

				service_Received_invoice(CPInvoiceRefENter,CpReceivedInvSelect,invoiceCurrencySelect,taxSchedAppCountryReceivedInv,taxSchedReceivedInv,
						costReceivedInvSelect,actualCostReceivedInvEnter,bankNamePrePaymentSelect,accountNamePrePaymentSelect);
				Assert.assertTrue(true, "Service Invoice Received generated successfully and stored");
			}
			else if(option.equalsIgnoreCase("Income")/*will create Service Invoice Raised*/){

				service_Raised_invoice(CPInvoiceRefENter,CpRaisedInvSelect,invoiceCurrencySelect,taxSchedAppCountryReceivedInv,taxSchedReceivedInv,
						costReceivedInvSelect,actualCostReceivedInvEnter,bankNamePrePaymentSelect,accountNamePrePaymentSelect);
				Assert.assertTrue(true, "Service Invoice Raised generated successfully and stored");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private void service_Received_invoice(String CPInvoiceRefENter,String CpReceivedInvSelect,String invoiceCurrencySelect,
			String taxSchedAppCountryReceivedInv,String taxSchedReceivedInv,String costReceivedInvSelect,
			String actualCostReceivedInvEnter,String bankNamePrePaymentSelect,String accountNamePrePaymentSelect) {

		Assert.assertTrue(true, "Executing Service Invoice Receieved!!!");
		click(newInvoicePage.getOperationsHeader());
		click(newInvoicePage.getServiceInvoiceReceivedLabel());
		//invoice Details
		staticWait(2);
		enterText(newInvoicePage.getCPInvoiceRefENter(), CPInvoiceRefENter);
		//selectDropDownByText(newInvoicePage.getServiceInvAgainstSelect(), "");

		selectDateFromDatePicker(newInvoicePage.getIssueDatePrePayment(), selectDate(0)); /*O represents today's date & +ve no rep no of future date*/
		selectDateFromDatePicker(newInvoicePage.getAccDatePrePaymentReceivedInv(), selectDate(0));
		selectSingleListAndItem(newInvoicePage.getCpReceivedInvArrow(), newInvoicePage.getCpReceivedInvSelect()	, CpReceivedInvSelect);
		selectDropDownByText(newInvoicePage.getInvoiceCurrencySelect(),invoiceCurrencySelect);
		selectDateFromDatePicker(newInvoicePage.getDueDatePrePaymentReceivedInv(), selectDate(2));
		selectDropDownByText(newInvoicePage.getTaxSchedAppCountryReceivedInv(), taxSchedAppCountryReceivedInv);
		selectDropDownByText(newInvoicePage.getTaxSchedReceivedInv(), taxSchedReceivedInv);
		//Cost Details
		/*selectDropDownByText(newInvoicePage.getCostReceivedInvSelect(), costReceivedInvSelect);*//* Not required as it has the default cost*/
		staticWait(1);

		a =new Actions(TestBaseListener.getDriver());
		a.click(newInvoicePage.getActualCostReceivedInvEnter()).sendKeys(Keys.CONTROL+"a").build().perform();
		a.sendKeys(Keys.DELETE).build().perform();
		staticWait(2);
		TestBaseListener.getDriver().findElement(By.xpath("//input[@id=('actualAmtInTranCur1') and contains(@name,'invoiceAccrualCostList')]")).sendKeys(actualCostReceivedInvEnter);
		enterText(newInvoicePage.getActualCostReceivedInvEnter(), actualCostReceivedInvEnter);
		staticWait(1);

		//Payment Instructions
		selectDropDownByText(newInvoicePage.getBankNamePrePaymentSelect(), bankNamePrePaymentSelect);
		selectDropDownByText(newInvoicePage.getAccountNamePrePaymentSelect(), accountNamePrePaymentSelect);
		click(newInvoicePage.getAddCPserviceRecieved());
		click(newInvoicePage.getSavePrePaymentInvoice());
		waitForAjax();
		/*Storing the invoice num*/
		String InvoiceRefNo = getText(newInvoicePage.getRefNoRecievedServiceInvoice());
		storeResultsinFile("recievedServiceInvoiceRefNo", InvoiceRefNo);
		click(newInvoicePage.getRefNoReceiveServInvoiceOK());

	}

	private void service_Raised_invoice(String CPInvoiceRefENter,String CpRaisedInvSelect,String invoiceCurrencySelect,
			String taxSchedAppCountryReceivedInv,String taxSchedReceivedInv,String costReceivedInvSelect,
			String actualCostReceivedInvEnter,String bankNamePrePaymentSelect,String accountNamePrePaymentSelect) {

		Assert.assertTrue(true, "Executing Service Invoice Raised!!!");

		click(newInvoicePage.getOperationsHeader());
		click(newInvoicePage.getServiceInvoiceRaisedLabel());
		//invoice Details
		enterText(newInvoicePage.getCPInvoiceRefENter(), CPInvoiceRefENter);
		selectDateFromDatePicker(newInvoicePage.getIssueDatePrePayment(), selectDate(0));
		selectDateFromDatePicker(newInvoicePage.getAccDatePrePaymentReceivedInv(), selectDate(0));
		selectSingleListAndItem(newInvoicePage.getCpReceivedInvArrow(), newInvoicePage.getCpReceivedInvSelect()	, CpRaisedInvSelect);
		selectDropDownByText(newInvoicePage.getInvoiceCurrencySelect(), invoiceCurrencySelect);
		selectDateFromDatePicker(newInvoicePage.getDueDatePrePaymentReceivedInv(),selectDate(2));
		selectDropDownByText(newInvoicePage.getTaxSchedAppCountryReceivedInv(), taxSchedAppCountryReceivedInv);
		selectDropDownByText(newInvoicePage.getTaxSchedReceivedInv(), taxSchedReceivedInv);
		//Cost Details
		/*selectDropDownByText(newInvoicePage.getCostReceivedInvSelect(), costReceivedInvSelect);*//* Not required as it has the default cost*/

		/*Special clearance field using actions class*/
		a =new Actions(TestBaseListener.getDriver());
		a.click(newInvoicePage.getActualCostReceivedInvEnter()).sendKeys(Keys.CONTROL+"a").build().perform();
		a.sendKeys(Keys.DELETE).build().perform();
		staticWait(2);
		TestBaseListener.getDriver().findElement(By.xpath("//input[@id=('actualAmtInTranCur1') and contains(@name,'invoiceAccrualCostList')]")).sendKeys(actualCostReceivedInvEnter);
		enterText(newInvoicePage.getActualCostReceivedInvEnter(), actualCostReceivedInvEnter);
		staticWait(1);

		//Payment Instructions
		selectDropDownByText(newInvoicePage.getBankNameRaisedInvSelect(), bankNamePrePaymentSelect);
		selectDropDownByText(newInvoicePage.getAccountNameRaisedInvSelect(), accountNamePrePaymentSelect);
		click(newInvoicePage.getAddCPserviceRecieved());
		click(newInvoicePage.getSavePrePaymentInvoice());
		waitForAjax();
		/*Storing the invoice num*/
		String InvoiceRefNo = getText(newInvoicePage.getRefNoRecievedServiceInvoice());
		storeResultsinFile("raisedServiceInvoiceRefNo", InvoiceRefNo);
		click(newInvoicePage.getRefNoReceiveServInvoiceOK());
	}


	public void general_Service_Inv_Received(String CPInvoiceRefENter,String CpReceivedInvSelect,String invoiceCurrencySelect,String taxSchedAppCountryReceivedInv,
			String taxSchedReceivedInv,String productGeneralInvSelect,String originGeneralInvSelect,String cropYearGeneralInvSelect,
			String qualityGeneralInvSelect,String costReceivedInvSelect,String monthReceivedInvSelect,String yearReceivedInvEnter,
			String actualCostGeneralReceivedInvEnter,String profitCenterGeneralReceivedInvEnter,String bankNamePrePaymentSelect,
			String accountNamePrePaymentSelect)throws Exception{

		/*Invoice details*/
		waitForAjax();
		enterText(newInvoicePage.getCPInvoiceRefENter(), CPInvoiceRefENter);
		selectDateFromDatePicker(newInvoicePage.getIssueDatePrePayment(), selectDate(0));
		selectDateFromDatePicker(newInvoicePage.getAccDatePrePaymentReceivedInv(), selectDate(0));
		selectSingleListAndItem(newInvoicePage.getCpReceivedInvArrow(), newInvoicePage.getCpReceivedInvSelect(), CpReceivedInvSelect);
		selectDropDownByText(newInvoicePage.getInvoiceCurrencySelect(), invoiceCurrencySelect);
		selectDateFromDatePicker(newInvoicePage.getDueDatePrePaymentReceivedInv(), selectDate(2));
		selectDropDownByText(newInvoicePage.getTaxSchedAppCountryReceivedInv(), taxSchedAppCountryReceivedInv);
		selectDropDownByText(newInvoicePage.getTaxSchedReceivedInv(), taxSchedReceivedInv);
		//selectDropDownByText(newInvoicePage.getLoadingLocType(), "");
		// selectDropDownByText(newInvoicePage.getDestinationLocType(), "");
		selectSingleListAndItem(newInvoicePage.getProductGeneralInvArrow(), newInvoicePage.getProductGeneralInvSelect(), productGeneralInvSelect);
		selectSingleListAndItem(newInvoicePage.getOriginGeneralInvArrow(), newInvoicePage.getOriginGeneralInvSelect(), originGeneralInvSelect);
		selectSingleListAndItem(newInvoicePage.getCropYearGeneralInvArrow(), newInvoicePage.getCropYearGeneralInvSelect(), cropYearGeneralInvSelect);
		selectSingleListAndItem(newInvoicePage.getQualityGeneralInvArrow(), newInvoicePage.getQualityGeneralInvSelect(), qualityGeneralInvSelect);

		/*Cost Details*/
		selectDropDownByText(newInvoicePage.getCostReceivedInvSelect(), costReceivedInvSelect);
		selectDropDownByText(newInvoicePage.getMonthReceivedInvSelect(), monthReceivedInvSelect);
		enterText(newInvoicePage.getYearReceivedInvEnter(), yearReceivedInvEnter);
		enterText(newInvoicePage.getActualCostGeneralReceivedInvEnter(), actualCostGeneralReceivedInvEnter);
		selectDropDownByText(newInvoicePage.getProfitCenterGeneralReceivedInvEnter(), profitCenterGeneralReceivedInvEnter);
		staticWait(2);
		click(newInvoicePage.getAddCPdetailsButton());

		/*Payment Instructions*/

		selectDropDownByText(newInvoicePage.getBankNamePrePaymentSelect(),bankNamePrePaymentSelect);
		selectDropDownByText(newInvoicePage.getAccountNamePrePaymentSelect(),accountNamePrePaymentSelect);
		//click(newInvoicePage.getAddCPserviceRecieved());
		click(newInvoicePage.getSavePrePaymentInvoice());
		waitForAjax();
		/*Storing the invoice num*/
		String InvoiceRefNo = getText(newInvoicePage.getRefNoRecievedServiceInvoice());
		storeResultsinFile("generalReceivedServiceInvoiceRefNo", InvoiceRefNo);
		click(newInvoicePage.getRefNoReceiveServInvoiceOK());
	}

	public void general_Service_Inv_Raised(String CPInvoiceRefENter,String CpReceivedInvSelect,String invoiceCurrencySelect,String taxSchedAppCountryReceivedInv,
			String taxSchedReceivedInv,String productGeneralInvSelect,String originGeneralInvSelect,String cropYearGeneralInvSelect,
			String qualityGeneralInvSelect,String costReceivedInvSelect,String monthReceivedInvSelect,String yearReceivedInvEnter,
			String actualCostGeneralReceivedInvEnter,String profitCenterGeneralReceivedInvEnter,String bankNamePrePaymentSelect,
			String accountNamePrePaymentSelect)throws Exception{

		/*Invoice details*/
		waitForAjax();
		enterText(newInvoicePage.getCPInvoiceRefENter(), CPInvoiceRefENter);
		selectDateFromDatePicker(newInvoicePage.getIssueDatePrePayment(), selectDate(0));
		selectDateFromDatePicker(newInvoicePage.getAccDatePrePaymentReceivedInv(), selectDate(0));
		selectSingleListAndItem(newInvoicePage.getCpReceivedInvArrow(), newInvoicePage.getCpReceivedInvSelect(), CpReceivedInvSelect);
		selectDropDownByText(newInvoicePage.getInvoiceCurrencySelect(), invoiceCurrencySelect);
		selectDateFromDatePicker(newInvoicePage.getDueDatePrePaymentReceivedInv(), selectDate(2));
		selectDropDownByText(newInvoicePage.getTaxSchedAppCountryReceivedInv(), taxSchedAppCountryReceivedInv);
		selectDropDownByText(newInvoicePage.getTaxSchedReceivedInv(), taxSchedReceivedInv);
		//selectDropDownByText(newInvoicePage.getLoadingLocType(), "");
		// selectDropDownByText(newInvoicePage.getDestinationLocType(), "");

		selectSingleListAndItem(newInvoicePage.getProductGeneralInvArrow(), newInvoicePage.getProductGeneralInvSelect(), productGeneralInvSelect);
		selectSingleListAndItem(newInvoicePage.getOriginGeneralInvArrow(), newInvoicePage.getOriginGeneralInvSelect(), originGeneralInvSelect);
		selectSingleListAndItem(newInvoicePage.getCropYearGeneralInvArrow(), newInvoicePage.getCropYearGeneralInvSelect(), cropYearGeneralInvSelect);
		selectSingleListAndItem(newInvoicePage.getQualityGeneralInvArrow(), newInvoicePage.getQualityGeneralInvSelect(), qualityGeneralInvSelect);

		/*Cost Details*/
		selectDropDownByText(newInvoicePage.getCostReceivedInvSelect(), costReceivedInvSelect);
		selectDropDownByText(newInvoicePage.getMonthReceivedInvSelect(), monthReceivedInvSelect);
		enterText(newInvoicePage.getYearReceivedInvEnter(), yearReceivedInvEnter);
		enterText(newInvoicePage.getActualCostGeneralReceivedInvEnter(), actualCostGeneralReceivedInvEnter);
		selectDropDownByText(newInvoicePage.getProfitCenterGeneralReceivedInvEnter(), profitCenterGeneralReceivedInvEnter);
		staticWait(2);
		click(newInvoicePage.getAddCPdetailsButton());

		/*Payment Instructions*/

		selectDropDownByText(newInvoicePage.getBankNameRaisedInvSelect(),bankNamePrePaymentSelect);
		selectDropDownByText(newInvoicePage.getAccountNameRaisedInvSelect(),accountNamePrePaymentSelect);
		//click(newInvoicePage.getAddCPserviceRecieved());
		click(newInvoicePage.getSavePrePaymentInvoice());
		waitForAjax();
		/*Storing the invoice num*/
		String InvoiceRefNo = getText(newInvoicePage.getRefNoRecievedServiceInvoice());
		storeResultsinFile("generalRaisedServiceInvoiceRefNo", InvoiceRefNo);
		click(newInvoicePage.getRefNoReceiveServInvoiceOK());
	}

	public void select_provisional_Invoice(String GMRRefNo)throws Exception{
		waitForAjax();
		staticWait(5);
		click(newProvisionalInvoicePage.getMainFilter());
		selectDropDownByText(newProvisionalInvoicePage.getFilterSearchSelect(), "GMR Ref. No.");
		enterText(newProvisionalInvoicePage.getFilterSearchInput(), GMRRefNo);
		click(newProvisionalInvoicePage.getFilterGo());
	}

	public void provisional_Invoice_Details(String CPInvRefNOENter,String CpProvisionalInvSelect,String amountToPayEnter,
			String roundAdjusEnter,String bankNameProvisionalSelect,String accountNameProvisionalSelect)
					throws Exception{

		waitForAjax();
		click(newProvisionalInvoicePage.getProvisionalInvCheckBox());
		staticWait(1);
		click(newProvisionalInvoicePage.getInvoiceHeader());
		staticWait(1);
		click(newProvisionalInvoicePage.getProvisionalInvLabel());

		/*Inside Provisional Invoice Page*/
		waitForAjax();
		enterText(newProvisionalInvoicePage.getCPInvRefNOENter(), CPInvRefNOENter);
		selectDateFromDatePicker(newProvisionalInvoicePage.getIssueDateProvisional(), selectDate(0));
		selectDateFromDatePicker(newProvisionalInvoicePage.getDueDateProvisional(),  selectDate(3));
		selectDateFromDatePicker(newProvisionalInvoicePage.getAccountingDatePrePayment(),  selectDate(0));
		selectSingleListAndItem(newProvisionalInvoicePage.getCpProvisionalInvArrow(), newProvisionalInvoicePage.getCpProvisionalInvSelect(), CpProvisionalInvSelect);

		/*Invoice Amount Details*/

		enterText(newProvisionalInvoicePage.getAmountToPayEnter(), amountToPayEnter);
		enterText(newProvisionalInvoicePage.getRoundAdjusEnter(), roundAdjusEnter);

		/*Payment Instructions*/

		selectDropDownByText(newProvisionalInvoicePage.getBankNameProvisionalSelect(), bankNameProvisionalSelect);
		selectDropDownByText(newProvisionalInvoicePage.getAccountNameProvisionalSelect(), accountNameProvisionalSelect);
		click(newProvisionalInvoicePage.getAddRowButton());
		staticWait(1);
		click(newProvisionalInvoicePage.getSavePrePaymentInvoice());
		waitForAjax();
		String proInvNo=getText(newProvisionalInvoicePage.getRefNoProvisionalInvoice());
		storeResultsinFile("provisionalInvNo", proInvNo);
		staticWait(1);
		click(newProvisionalInvoicePage.getRefNoProvisionalInvoiceOK());
	}
	public void search_Con_Final_Inv(String contractRefNo)throws Exception {
		waitForAjax();
		staticWait(1);
		clickUsingJavaScript(newInvoicePage.getMainFilter());
		staticWait(1);
		click(newInvoicePage.getFilterReset());
		waitForAjax();
		selectDropDownByText(newInvoicePage.getFilterSearchSelect(), "Contract Ref. No.");
		staticWait(1);
		enterText(newInvoicePage.getFilterSearchInput(), contractRefNo);
		staticWait(1);
		click(newInvoicePage.getFilterGo());
		waitForAjax();
		click(newInvoicePage.getContractCheckBox());
		staticWait(1);
	}

	public void Final_Invoice(String CPInvoiceRefENter,String bankNamePrePaymentSelect,
			String accountNamePrePaymentSelect,String finalInvoiceType
			) {

		click(newInvoicePage.getInvoiceHeader());
		click(newInvoicePage.getFinalInvoiceLabel());
		waitForAjax();
		enterText(newInvoicePage.getCPInvoiceRefENter(), CPInvoiceRefENter);
		selectDateFromDatePicker(newInvoicePage.getIssueDateFinalInv(), selectDate(0));
		selectDateFromDatePicker(newInvoicePage.getDueDateFinalInv(), selectDate(2));
		selectDateFromDatePicker(newInvoicePage.getAccDateFinalInv(), selectDate(5));

		/*Future Build Implementation*/
		/*selectDropDownByText(newInvoicePage.getOurTaxNoFinalInv(), "");
		enterText(newInvoicePage.getTaxDescFinalInv(), "");
		selectDropDownByText(newInvoicePage.getCPTaxNoFinalInv(), "");
		enterText(newInvoicePage.getCptaxDescFinalInv(), "");*/ 

		/*Payment instructions*/
		selectDropDownByText(newInvoicePage.getBankNamePrePaymentSelect(),bankNamePrePaymentSelect);
		selectDropDownByText(newInvoicePage.getAccountNamePrePaymentSelect(), accountNamePrePaymentSelect);
		click(newInvoicePage.getAddRowButton());

		click(newInvoicePage.getSavePrePaymentInvoice());
		waitForAjax();
		/*Getting Final Invoice Number*/
		String finalInvNo = getText(newInvoicePage.getRefNoPrePaymentInvoice());
		storeResultsinFile(finalInvoiceType, finalInvNo);
		staticWait(1);
		click(newInvoicePage.getRefNoReceiveServInvoiceOK());

	}

}
