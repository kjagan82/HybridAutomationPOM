package com.qa.flows.Physicals;
import com.qa.pages.Physicals.UnderfillAndOverfillPage;
import com.qa.util.SeleniumLibs;

public class UnderfillAndOverfillPageFlow extends SeleniumLibs{


	UnderfillAndOverfillPage underfillAndOverfillPage;
	SeleniumLibs newSeleniumLibs;

	public UnderfillAndOverfillPageFlow(){
		underfillAndOverfillPage = new UnderfillAndOverfillPage();
	}

	//FiltercontractforOverfillUnderfill//
	public void search_Contract(String contractRefNo)throws Exception{
		waitForAjax();
		clickUsingJavaScript(underfillAndOverfillPage.getContractMainFilter());
		staticWait(1);
		click(underfillAndOverfillPage.getFilterReset());
		selectDropDownByText(underfillAndOverfillPage.getFilterSearchSelect(),"Contract Ref.No.");
		enterText(underfillAndOverfillPage.getFilterSearchInput(),contractRefNo);
		click(underfillAndOverfillPage.getFilterGo());
		waitForAjax();
		click(underfillAndOverfillPage.getContractItemsCheckBox());
	}

	//LinkOverfillUnderfill//
	public void linkOverfillUnderfill()throws Exception{
		click(underfillAndOverfillPage.getLinkContractOperations());
		click(underfillAndOverfillPage.getLinkOverfillUnderfillLabel());
	}

	//LinkrollOver//
	public void linkRollOver()throws Exception{
		click(underfillAndOverfillPage.getLinkContractOperations());
		click(underfillAndOverfillPage.getLinkRollOverPriceMonthLabel());
	}

	//PricefixforOverfillUnderfill//
	public void underfillOverfill_Activity(String overfillUnderfillReason,String overfillUnderfillShipment,String futuresmonth,
			String futurePrice,String basisPrice,String OverfillorUnderfillType,String contractRefNo)throws Exception{
		waitForAjax();
		selectDateFromDatePicker(underfillAndOverfillPage.getContractIssueDate(),selectDate(0));
		enterText(underfillAndOverfillPage.getOverfillUnderfillReason(),overfillUnderfillReason);
		selectDropDownByText(underfillAndOverfillPage.getOverfillUnderfillShipment(),overfillUnderfillShipment);
		selectDropDownByText(underfillAndOverfillPage.getFuturesmonth(),futuresmonth);
		enterText(underfillAndOverfillPage.getFuturePrice(),futurePrice);
		enterText(underfillAndOverfillPage.getBasisPrice(),basisPrice);
		click(underfillAndOverfillPage.getSavebutton());

		//ListofOverfill/UnderfillandCaptureRefno/
		click(underfillAndOverfillPage.getOverfillUnderfillFilter());
		click(underfillAndOverfillPage.getOverfillUnderfillReset());
		enterText(underfillAndOverfillPage.getOverfillUnderfillSearchInput(),contractRefNo);
		click(underfillAndOverfillPage.getOverfillUnderfillGo());
		storeUnderfillOverfillrefno(OverfillorUnderfillType); /*storingOverfill/underfillrefno*/
	}
	private void storeUnderfillOverfillrefno(String OverfillorUnderfillType) {
		String underfillOverfillrefno = getText(underfillAndOverfillPage.getUnderfillOverfillrefno());
		storeResultsinFile(OverfillorUnderfillType,underfillOverfillrefno);
		staticWait(1);
	}

	public void rolloverPriceMonth_activity(String RolloverFromMonth,String RolloverToMonth,String qtytoRollOver,String rolloverSpread,
			String personInCharge,String contractRefNo,String RolloverrefnoType)throws Exception{
		waitForAjax();

		selectDateFromDatePicker(underfillAndOverfillPage.getRolloverIssueDate(),selectDate(0));
		selectDateFromDatePicker(underfillAndOverfillPage.getRolloverDate(),selectDate(2));
		selectDropDownByText(underfillAndOverfillPage.getRolloverFromMonth(),RolloverFromMonth);
		selectDropDownByText(underfillAndOverfillPage.getRolloverToMonth(),RolloverToMonth);
		enterText(underfillAndOverfillPage.getQtytoRollOver(),qtytoRollOver);
		enterText(underfillAndOverfillPage.getRolloverSpread(),rolloverSpread);
		selectDropDownByText(underfillAndOverfillPage.getPersonInCharge(),personInCharge);
		click(underfillAndOverfillPage.getBtnRolloverSave());
		/*click(underfillAndOverfillPage.getBtnRolloverCancel());*/


		//Filtercontract//

		click(underfillAndOverfillPage.getRolloverFilter());
		click(underfillAndOverfillPage.getRolloverReset());
		enterText(underfillAndOverfillPage.getRolloverSearchInput(),contractRefNo);
		click(underfillAndOverfillPage.getRolloverGo());
		storeRolloverrefno(RolloverrefnoType); /*storingrolloverrefno*/


	}

	private void storeRolloverrefno(String RolloverrefnoType) {
		String Rolloverrefno = getText(underfillAndOverfillPage.getRolloverrefno());
		storeResultsinFile(RolloverrefnoType,Rolloverrefno);
		staticWait(1);
	}









}






















